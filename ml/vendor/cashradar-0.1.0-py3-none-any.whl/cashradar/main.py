"""FastAPI application.

    uv run uvicorn cashradar.main:app --port 8000

Serves the REST API under /api and, if frontend/dist exists, the built web UI at /.
"""
import os
import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from cashradar.core.config import REPO_ROOT
from cashradar.core.logging import get_logger
from cashradar.core.security import User, UserStore, create_token, decode_token
from cashradar.datasets import MAX_UPLOAD_BYTES, DatasetManager, UploadError
from cashradar.service import ForecastError, ForecastService
from cashradar.storage.events import EventValidationError

log = get_logger("api")
FRONTEND_DIST = Path(os.environ.get("CASHRADAR_FRONTEND_DIST", REPO_ROOT / "frontend" / "dist"))
DATE_RE = r"^\d{4}-\d{2}-\d{2}$"


@asynccontextmanager
async def lifespan(app: FastAPI):
    if not hasattr(app.state, "service"):
        t = time.time()
        app.state.service = ForecastService()
        log.info("forecast service ready in %.1fs", time.time() - t)
    if not hasattr(app.state, "users"):
        app.state.users = UserStore()
    if not hasattr(app.state, "datasets"):
        app.state.datasets = DatasetManager(app.state.service)
    yield


app = FastAPI(title="Кассовый радар", version="0.3.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
                   allow_methods=["*"], allow_headers=["*"])


@app.middleware("http")
async def access_log(request: Request, call_next):
    t = time.time()
    response = await call_next(request)
    # path only: query strings and bodies are never logged
    log.info("%s %s -> %d (%.0f ms)", request.method, request.url.path, response.status_code, (time.time() - t) * 1000)
    return response


bearer = HTTPBearer(auto_error=False)


def current_user(request: Request, creds: HTTPAuthorizationCredentials | None = Depends(bearer)) -> User:
    username = decode_token(creds.credentials) if creds else None
    user = request.app.state.users.get(username) if username else None
    if user is None:
        raise HTTPException(401, "Требуется вход", headers={"WWW-Authenticate": "Bearer"})
    return user


def service(request: Request) -> ForecastService:
    return request.app.state.service


class LoginRequest(BaseModel):
    username: str
    password: str


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.post("/api/auth/login")
def login(body: LoginRequest, request: Request):
    user = request.app.state.users.authenticate(body.username, body.password)
    if user is None:
        raise HTTPException(401, "Неверный логин или пароль")
    return {"access_token": create_token(user), "token_type": "bearer",
            "user": {"username": user.username, "role": user.role, "display_name": user.display_name}}


@app.get("/api/me")
def me(user: User = Depends(current_user)):
    return {"username": user.username, "role": user.role, "display_name": user.display_name,
            "companies": list(user.companies) if user.companies else "*"}


@app.get("/api/companies")
def companies(user: User = Depends(current_user), svc: ForecastService = Depends(service)):
    return svc.list_companies(user.can_access)


@app.get("/api/companies/{company_id}/forecast")
def forecast(company_id: str,
             as_of: str | None = Query(None, pattern=DATE_RE, description="дата прогноза (машина времени)"),
             horizon: int = Query(30, ge=7, le=90),
             threshold: float = Query(0.0, ge=0, description="неснижаемый остаток, ₽"),
             user: User = Depends(current_user), svc: ForecastService = Depends(service)):
    _guard(user, company_id)
    return _call(svc.forecast, company_id, as_of, horizon, threshold)


def _guard(user: User, company_id: str) -> None:
    if not user.can_access(company_id):
        raise HTTPException(404, "Компания не найдена")  # do not reveal existence of others' companies


def _call(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except KeyError:
        raise HTTPException(404, "Компания не найдена")
    except (ForecastError, EventValidationError) as e:
        raise HTTPException(422, str(e))



@app.get("/api/scenario-presets")
def scenario_presets(user: User = Depends(current_user), svc: ForecastService = Depends(service)):
    return svc.presets()


@app.get("/api/companies/{company_id}/clients")
def clients(company_id: str, as_of: str | None = Query(None, pattern=DATE_RE),
            user: User = Depends(current_user), svc: ForecastService = Depends(service)):
    _guard(user, company_id)
    return _call(svc.clients, company_id, as_of)


@app.get("/api/companies/{company_id}/scenario")
def scenario(company_id: str,
             as_of: str | None = Query(None, pattern=DATE_RE),
             horizon: int = Query(30, ge=7, le=90),
             threshold: float = Query(0.0, ge=0),
             revenue_change_pct: float = Query(0, ge=-90, le=50, description="изменение новых продаж, %"),
             fixed_cost_change_pct: float = Query(0, ge=-50, le=100, description="аренда, коммунальные, услуги, %"),
             purchase_change_pct: float = Query(0, ge=-50, le=100, description="закупки и прочие расходы, %"),
             client_delay_days: int = Query(0, ge=0, le=90),
             client: str | None = Query(None, max_length=120, description="ключ клиента, «top» или пусто = все"),
             one_off_amount: float = Query(0, ge=0, le=1e10, description="внеплановый расход, ₽"),
             one_off_in_days: int = Query(10, ge=1, le=90),
             user: User = Depends(current_user), svc: ForecastService = Depends(service)):
    _guard(user, company_id)
    return _call(svc.scenario, company_id, as_of, horizon, threshold,
                 revenue_change_pct=revenue_change_pct, fixed_cost_change_pct=fixed_cost_change_pct,
                 purchase_change_pct=purchase_change_pct, client_delay_days=client_delay_days, client=client,
                 one_off_amount=one_off_amount, one_off_in_days=one_off_in_days)


@app.get("/api/companies/{company_id}/planfact")
def planfact(company_id: str, as_of: str | None = Query(None, pattern=DATE_RE),
             plan_days: int = Query(14, ge=7, le=30), threshold: float = Query(0.0, ge=0),
             user: User = Depends(current_user), svc: ForecastService = Depends(service)):
    _guard(user, company_id)
    return _call(svc.planfact, company_id, as_of, plan_days, threshold)


class EventIn(BaseModel):
    date: str = Field(pattern=DATE_RE)
    amount: float = Field(description="поступление > 0, списание < 0")
    label: str = Field(min_length=1, max_length=200)


@app.get("/api/companies/{company_id}/events")
def list_events(company_id: str, user: User = Depends(current_user), svc: ForecastService = Depends(service)):
    _guard(user, company_id)
    return _call(svc.list_events, company_id)


@app.post("/api/companies/{company_id}/events", status_code=201)
def add_event(company_id: str, body: EventIn, user: User = Depends(current_user),
              svc: ForecastService = Depends(service)):
    _guard(user, company_id)
    return _call(svc.add_event, company_id, body.date, body.amount, body.label, user.username)


@app.delete("/api/companies/{company_id}/events/{event_id}", status_code=204)
def delete_event(company_id: str, event_id: int, user: User = Depends(current_user),
                 svc: ForecastService = Depends(service)):
    _guard(user, company_id)
    if not _call(svc.delete_event, company_id, event_id):
        raise HTTPException(404, "Событие не найдено")
    return Response(status_code=204)


# -- datasets: upload the organizers' control data and evaluate it ------------------------------

def analyst(user: User = Depends(current_user)) -> User:
    if user.role != "analyst":
        raise HTTPException(403, "Загружать датасеты может только аналитик")
    return user


@app.post("/api/datasets", status_code=202)
async def upload_dataset(request: Request, name: str = Query(..., max_length=200), quick: bool = Query(True),
                         as_of: str | None = Query(None, pattern=DATE_RE,
                                                   description="прогноз от этой даты и сверка с данными после неё"),
                         user: User = Depends(analyst)):
    """Raw file in the body (CSV or ZIP). Processing runs in the background: poll /api/datasets/current."""
    size = int(request.headers.get("content-length") or 0)
    if size > MAX_UPLOAD_BYTES:
        raise HTTPException(413, "Файл слишком большой")
    data = await request.body()
    try:
        job = request.app.state.datasets.start(name, data, quick=quick, as_of=as_of)
    except UploadError as e:
        raise HTTPException(422 if "обрабатывается" not in str(e) else 409, str(e))
    log.info("dataset upload accepted: job %s, %d bytes", job.id, len(data))
    return job.public()


@app.get("/api/datasets/current")
def current_dataset(request: Request, user: User = Depends(current_user)):
    job = request.app.state.datasets.current
    svc = request.app.state.service
    base = {"dataset": svc.dataset_name, "companies": len(svc.companies), "no_balance": svc.no_balance}
    return base | (job.public() if job else {"status": "none"})


@app.get("/api/datasets/current/report")
def current_report(request: Request, user: User = Depends(analyst)):
    job = request.app.state.datasets.current
    if not job or not job.report_path or not Path(job.report_path).exists():
        raise HTTPException(404, "Отчёта ещё нет")
    return FileResponse(job.report_path, media_type="text/markdown; charset=utf-8",
                        filename=f"report_{Path(job.name).stem}.md")


if FRONTEND_DIST.exists():
    app.mount("/assets", StaticFiles(directory=FRONTEND_DIST / "assets"), name="assets")

    @app.get("/{path:path}", include_in_schema=False)
    def spa(path: str):
        if path.startswith("api/"):
            raise HTTPException(404, "Not found")
        root = FRONTEND_DIST.resolve()
        target = (root / path).resolve()
        if path and target.is_file() and target.is_relative_to(root):
            return FileResponse(target)
        return FileResponse(root / "index.html")
