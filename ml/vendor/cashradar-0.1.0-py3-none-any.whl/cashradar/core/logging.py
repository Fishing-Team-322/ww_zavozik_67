"""Logging with masking of sensitive data (INN, amounts, counterparty names).

Rule of thumb for the codebase: log operation ids and aggregates, never raw rows.
The filter is a safety net for the cases when something slips through.
"""
import logging
import re

_PATTERNS = [
    # INN: 10 or 12 digits
    (re.compile(r"(?<!\d)\d{10}(?:\d{2})?(?!\d)"), "<INN>"),
    # amounts like 12 345.67 / 12345,67 / 1234-56, but not ISO dates 2026-10-01
    (re.compile(r"(?<![\w.\-])\d[\d\s]{0,15}[.,\-]\d{2}(?![\d\-])"), "<AMT>"),
    # quoted legal names: ООО «Ромашка-123»
    (re.compile(r"(ООО|АО|ПАО|ИП|ЗАО)\s*«[^»]*»"), r"\1 «***»"),
]


def mask(text: str) -> str:
    for pattern, repl in _PATTERNS:
        text = pattern.sub(repl, text)
    return text


class MaskingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = mask(record.getMessage())
        record.args = None
        return True


def get_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
        handler.addFilter(MaskingFilter())
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
        logger.propagate = False
    return logger
