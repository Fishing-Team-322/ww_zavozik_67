"""Authentication: PBKDF2 password hashes, HS256 JWT, per-company access control.

Users come from a JSON file (CASHRADAR_USERS_FILE, default cashradar/core/demo_users.json) holding
only salted hashes. Roles:
    owner    — sees only the companies listed for them
    analyst  — sees all companies (bank employee / demo jury mode)
"""
import hashlib
import hmac
import json
import os
import secrets
import time
from dataclasses import dataclass
from pathlib import Path

import jwt

from cashradar.core.logging import get_logger

log = get_logger(__name__)

USERS_FILE = Path(os.environ.get("CASHRADAR_USERS_FILE", Path(__file__).with_name("demo_users.json")))
TOKEN_TTL_SECONDS = int(os.environ.get("CASHRADAR_TOKEN_TTL", 8 * 3600))
PBKDF2_ITERATIONS = 200_000
ALGORITHM = "HS256"

_secret = os.environ.get("CASHRADAR_JWT_SECRET")
if not _secret:
    _secret = secrets.token_urlsafe(48)
    log.warning("CASHRADAR_JWT_SECRET is not set: using a random secret, tokens expire on restart")
JWT_SECRET = _secret


@dataclass(frozen=True)
class User:
    username: str
    role: str
    companies: tuple[str, ...] | None   # None = all companies
    display_name: str = ""

    def can_access(self, company_id: str) -> bool:
        return self.companies is None or company_id in self.companies


def hash_password(password: str, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), PBKDF2_ITERATIONS).hex()
    return f"pbkdf2_sha256${PBKDF2_ITERATIONS}${salt}${digest}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _, iterations, salt, digest = stored.split("$")
    except ValueError:
        return False
    candidate = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), int(iterations)).hex()
    return hmac.compare_digest(candidate, digest)


class UserStore:
    def __init__(self, path: Path = USERS_FILE):
        raw = json.loads(Path(path).read_text(encoding="utf-8")) if Path(path).exists() else []
        self._users = {u["username"]: u for u in raw}

    def authenticate(self, username: str, password: str) -> User | None:
        rec = self._users.get(username)
        # verify even for unknown users to keep timing similar
        ok = verify_password(password, rec["password_hash"] if rec else hash_password("x"))
        return self._to_user(rec) if rec and ok else None

    def get(self, username: str) -> User | None:
        rec = self._users.get(username)
        return self._to_user(rec) if rec else None

    @staticmethod
    def _to_user(rec: dict) -> User:
        companies = None if rec.get("companies") == "*" else tuple(rec.get("companies", []))
        return User(rec["username"], rec["role"], companies, rec.get("display_name", ""))


def create_token(user: User) -> str:
    now = int(time.time())
    return jwt.encode({"sub": user.username, "role": user.role, "iat": now, "exp": now + TOKEN_TTL_SECONDS},
                      JWT_SECRET, algorithm=ALGORITHM)


def decode_token(token: str) -> str | None:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[ALGORITHM])["sub"]
    except jwt.PyJWTError:
        return None
