"""Generate demo users: hashes go to cashradar/core/demo_users.json, plaintext passwords
to backend/.demo_credentials (git-ignored, for the demo only).

    uv run python -m cashradar.core.make_demo_users
"""
import json
import secrets
from pathlib import Path

from cashradar.core.security import hash_password

DEMO = [
    dict(username="analyst", role="analyst", companies="*", display_name="Аналитик банка"),
    dict(username="c026", role="owner", companies=["C026"], display_name="Владелец C026 (опт)"),
    dict(username="c080", role="owner", companies=["C080"], display_name="Владелец C080 (IT)"),
    dict(username="c134", role="owner", companies=["C134"], display_name="Владелец C134 (стройка)"),
    dict(username="c001", role="owner", companies=["C001"], display_name="Владелец C001 (грузоперевозки)"),
]


def main() -> None:
    users, creds = [], []
    for u in DEMO:
        password = secrets.token_urlsafe(9)
        users.append(u | {"password_hash": hash_password(password)})
        creds.append(f"{u['username']}\t{password}\t{u['display_name']}")
    core = Path(__file__).parent
    (core / "demo_users.json").write_text(json.dumps(users, ensure_ascii=False, indent=2), encoding="utf-8")
    (core.parents[1] / ".demo_credentials").write_text("\n".join(creds) + "\n", encoding="utf-8")
    print("demo users written; passwords in backend/.demo_credentials")


if __name__ == "__main__":
    main()
