"""Paths and global settings. Override via environment variables."""
import os
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[3]
DATA_DIR = Path(os.environ.get("CASHRADAR_DATA_DIR", REPO_ROOT / "data" / "raw"))
REPORTS_DIR = Path(os.environ.get("CASHRADAR_REPORTS_DIR", REPO_ROOT / "reports"))

# Balance reconciliation tolerance, rubles.
BALANCE_TOL = 0.05
