"""Forecast service: the API-facing layer over M5 + risk engine.

Holds the prepared dataset in memory and caches results per request parameters.
`as_of` < last statement date is the «time machine»: forecast as it would have been made that
day, plus what actually happened, for demos and plan-vs-fact.
"""
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from cashradar.core.config import DATA_DIR, REPORTS_DIR
from cashradar.core.logging import get_logger
from cashradar.domain.scenario import BASE, Scenario
from cashradar.embed import load_gbm
from cashradar.forecast.hybrid import HybridForecaster
from cashradar.forecast.structural import Simulation, StructuralWithInvoices
from cashradar.pipeline import Dataset, prepare
from cashradar.planfact.engine import plan_fact
from cashradar.risk.engine import ProbabilityCalibrator, RiskAssessment, assess, rub
from cashradar.scenarios.engine import PRESETS, build_scenario, top_clients
from cashradar.storage.events import EventStore

log = get_logger(__name__)

# packaged with the model (refreshed from reports/backtest by `run_backtest`): available on any machine
ARTIFACTS = Path(__file__).resolve().parent / "artifacts"
CALIBRATOR_PATH = ARTIFACTS / "calibrator_M6.json"
# at the last date the invoice registry knows only what the statement shows: M6 «statement only» calibration
LIVE_CALIBRATOR_PATH = ARTIFACTS / "calibrator_M6_statement.json"
FALLBACK_CALIBRATOR_PATH = ARTIFACTS / "calibrator_M5.json"
MIN_HISTORY_DAYS = 14
HISTORY_DAYS_SHOWN = 90
MAX_HORIZON = 90
CACHE_SIZE = 256

EVENT_SOURCE = {
    "recurring": "Регулярный платёж (по выписке)",
    "invoice": "Счёт (учётная система)",
    "estimate": "Оценка по истории: счета, которых ещё нет в реестре",
    "manual": "Добавлено вами",
    "scenario": "Сценарий «что если»",
}


class ForecastError(ValueError):
    pass


def _d(x) -> str | None:
    return None if x is None or pd.isna(x) else pd.Timestamp(x).strftime("%Y-%m-%d")


def _f(x) -> float | None:
    if x is None:
        return None
    try:
        if pd.isna(x):
            return None
    except (TypeError, ValueError):
        pass
    return round(float(x), 2)


@dataclass
class CompanyInfo:
    company_id: str
    name: str
    industry: str
    legal_form: str
    first_date: pd.Timestamp
    last_date: pd.Timestamp
    closed: bool


class ForecastService:
    def __init__(self, data_dir: str | Path = DATA_DIR, dataset: Dataset | None = None,
                 calibrator_path: Path = CALIBRATOR_PATH, n_paths: int = 1000, events: EventStore | None = None):
        self.n_paths = n_paths
        self.gbm = load_gbm()
        if self.gbm is None:
            log.warning("LightGBM artifact not available: serving M5 without the hybrid level")
            calibrator_path = FALLBACK_CALIBRATOR_PATH if calibrator_path == CALIBRATOR_PATH else calibrator_path
        self.events = events or EventStore()
        self.calibrator = ProbabilityCalibrator.load(calibrator_path) if Path(calibrator_path).exists() else None
        if self.calibrator is None:
            log.warning("probability calibrator not found, raw simulated probabilities will be shown")
        # forecasts at a past date (time machine) see the full registry, forecasts at the last date do not
        self.live_calibrator = (ProbabilityCalibrator.load(LIVE_CALIBRATOR_PATH)
                                if calibrator_path == CALIBRATOR_PATH and LIVE_CALIBRATOR_PATH.exists()
                                else self.calibrator)
        self.dataset_name = "" if dataset is not None else Path(data_dir).name
        self.use_dataset(dataset or prepare(data_dir), self.dataset_name)

    def use_dataset(self, ds: Dataset, name: str = "") -> None:
        """Switch to another dataset (e.g. the organizers' control one): everything is rebuilt first and
        then swapped in one go, so requests in flight see either the old or the new state."""
        # M6 (hybrid) when the LightGBM artifact is available, otherwise M5
        model = (HybridForecaster(ds.ops, gbm=self.gbm, n_paths=self.n_paths) if self.gbm is not None
                 else StructuralWithInvoices(ds.ops, n_paths=self.n_paths))
        model._slot_cache = {}  # never reuse slots detected for the previous dataset
        transfers = ds.ops[ds.ops["category"].isin(["in.internal_transfer", "out.internal_transfer"])]
        closed = set(ds.cleaning.closed_companies)
        dataset_end = max(cs.last_date for cs in ds.series.values())
        companies: dict[str, CompanyInfo] = {}
        for r in ds.companies.itertuples():
            cs = ds.series.get(r.company_id)
            if cs is None:
                continue
            companies[r.company_id] = CompanyInfo(
                r.company_id, str(r.company_name), str(r.industry or ""), str(r.legal_form or ""), cs.first_date,
                cs.last_date, r.company_id in closed or (dataset_end - cs.last_date).days > 30)
        self.ds, self.model, self.companies = ds, model, companies
        self.other_bank = set(transfers["company_id"])
        self.ops_by_company = {c: g for c, g in ds.ops.groupby("company_id")}
        self.dataset_name = name or self.dataset_name
        self.no_balance = bool(ds.load and ds.load.balance_reconstructed)
        self._cache = OrderedDict()

    # -- helpers --------------------------------------------------------------
    def list_companies(self, allowed=None) -> list[dict]:
        return [dict(company_id=c.company_id, name=c.name, industry=c.industry, legal_form=c.legal_form,
                     first_date=_d(c.first_date), last_date=_d(c.last_date), closed=c.closed)
                for c in self.companies.values() if allowed is None or allowed(c.company_id)]

    def _info(self, company_id: str) -> CompanyInfo:
        info = self.companies.get(company_id)
        if info is None:
            raise KeyError(company_id)
        return info

    def _cutoff(self, info: CompanyInfo, as_of: str | None) -> pd.Timestamp:
        cutoff = info.last_date if as_of is None else min(pd.Timestamp(as_of).normalize(), info.last_date)
        if cutoff < info.first_date + pd.Timedelta(days=MIN_HISTORY_DAYS):
            raise ForecastError(f"Слишком мало истории: нужно хотя бы {MIN_HISTORY_DAYS} дней операций до даты прогноза")
        return cutoff

    @staticmethod
    def _horizon(horizon: int) -> int:
        if not 7 <= horizon <= MAX_HORIZON:
            raise ForecastError(f"Горизонт прогноза должен быть от 7 до {MAX_HORIZON} дней")
        return horizon

    def _cached(self, key, build):
        if key in self._cache:
            self._cache.move_to_end(key)
            return self._cache[key]
        value = build()
        self._cache[key] = value
        if len(self._cache) > CACHE_SIZE:
            self._cache.popitem(last=False)
        return value

    def _simulate(self, info: CompanyInfo, cutoff: pd.Timestamp, horizon: int, scenario: Scenario = BASE) -> Simulation:
        manual = tuple(e.to_extra() for e in self.events.list(info.company_id))
        return self.model.simulate(self.ds.series[info.company_id], cutoff, horizon, scenario, manual)

    def _assess(self, info: CompanyInfo, sim: Simulation, threshold: float) -> RiskAssessment:
        calibrator = self.live_calibrator if sim.cutoff >= info.last_date else self.calibrator
        return assess(sim, threshold, calibrator, has_other_bank=info.company_id in self.other_bank)

    @staticmethod
    def _risk_dict(risk: RiskAssessment) -> dict:
        return dict(level=risk.level, probability=_f(risk.p_gap), probability_raw=_f(risk.p_gap_raw),
                    date=_d(risk.risk_date), shortfall=_f(risk.shortfall_p50), shortfall_bad=_f(risk.shortfall_p90),
                    message=risk.message, recommendations=risk.recommendations,
                    drivers=[dict(date=_d(x.date), label=x.label, amount=_f(x.amount), kind=x.kind,
                                  probability=_f(x.probability)) for x in risk.drivers])

    @staticmethod
    def _quantiles(sim: Simulation, risk: RiskAssessment) -> list[dict]:
        q = sim.quantiles((0.1, 0.5, 0.9))
        return [dict(date=_d(d), p10=_f(r.p10), p50=_f(r.p50), p90=_f(r.p90), p_below=_f(risk.p_by_day.loc[d]))
                for d, r in q.iterrows()]

    @staticmethod
    def _events(sim: Simulation) -> list[dict]:
        return [dict(date=_d(r["date"]), label=r["label"], amount=_f(r["amount"]), kind=r["kind"],
                     source=EVENT_SOURCE.get(r["kind"], r["kind"]), category=r["category"],
                     probability=_f(r["probability"]), overdue=bool(r["overdue"]) if pd.notna(r["overdue"]) else False,
                     event_id=None if pd.isna(r["event_id"]) else int(r["event_id"]))
                for _, r in sim.events.iterrows()]

    # -- forecast ---------------------------------------------------------------
    def forecast(self, company_id: str, as_of: str | None = None, horizon: int = 30, threshold: float = 0.0) -> dict:
        info = self._info(company_id)
        horizon = self._horizon(horizon)
        cutoff = self._cutoff(info, as_of)
        key = ("forecast", company_id, cutoff, horizon, threshold, self.events.version(company_id))
        return self._cached(key, lambda: self._build(info, cutoff, horizon, threshold))

    def _build(self, info: CompanyInfo, cutoff: pd.Timestamp, horizon: int, threshold: float) -> dict:
        cs = self.ds.series[info.company_id]
        sim = self._simulate(info, cutoff, horizon)
        risk = self._assess(info, sim, threshold)
        f = cs.frame
        hist = f.loc[cutoff - pd.Timedelta(days=HISTORY_DAYS_SHOWN - 1):cutoff]
        fut = f.loc[cutoff + pd.Timedelta(days=1):cutoff + pd.Timedelta(days=horizon)]
        actual = [dict(date=_d(d), balance=_f(r.bal), operating_balance=_f(op))
                  for (d, r), op in zip(fut.iterrows(), fut["bal"] - fut["net_fin"].cumsum())]
        history_days = (cutoff - cs.first_date).days + 1
        return dict(
            company=dict(company_id=info.company_id, name=info.name, industry=info.industry,
                         legal_form=info.legal_form, closed=info.closed),
            as_of=_d(cutoff), last_data_date=_d(info.last_date), is_time_machine=cutoff < info.last_date,
            horizon=horizon, threshold=threshold, balance_now=_f(sim.bal_now),
            model=dict(name=self.model.name, title=self.model.title, paths=int(sim.paths.shape[0]),
                       calibrated=self.calibrator is not None),
            data_quality=dict(history_days=int(history_days), short_history=history_days < 90,
                              missing_days_last_90=int(hist["missing"].sum()),
                              has_other_bank=info.company_id in self.other_bank,
                              seasonal_factors=[round(x, 2) for x in sim.seasonal]),
            history=[dict(date=_d(d), balance=_f(b)) for d, b in hist["bal"].items()],
            forecast=self._quantiles(sim, risk),
            actual=actual,
            risk=self._risk_dict(risk),
            events=self._events(sim),
            expected_other_flow=_f(sim.stream_mean.sum()),
        )

    # -- what if ----------------------------------------------------------------
    def presets(self) -> list[dict]:
        return [dict(id=p.id, title=p.title, description=p.description, params=p.params) for p in PRESETS]

    def clients(self, company_id: str, as_of: str | None = None) -> list[dict]:
        info = self._info(company_id)
        return top_clients(self.ds.ops, company_id, self._cutoff(info, as_of))

    def scenario(self, company_id: str, as_of: str | None = None, horizon: int = 30, threshold: float = 0.0,
                 **params) -> dict:
        info = self._info(company_id)
        horizon = self._horizon(horizon)
        cutoff = self._cutoff(info, as_of)
        key = ("scenario", company_id, cutoff, horizon, threshold, self.events.version(company_id),
               tuple(sorted(params.items())))
        return self._cached(key, lambda: self._build_scenario(info, cutoff, horizon, threshold, params))

    def _build_scenario(self, info: CompanyInfo, cutoff: pd.Timestamp, horizon: int, threshold: float,
                        params: dict) -> dict:
        clients = top_clients(self.ds.ops, info.company_id, cutoff)
        scen = build_scenario(cutoff, clients=clients, **params)
        base_sim = self._simulate(info, cutoff, horizon)
        scen_sim = self._simulate(info, cutoff, horizon, scen)
        base_risk, scen_risk = self._assess(info, base_sim, threshold), self._assess(info, scen_sim, threshold)
        base_p50 = np.median(base_sim.balance_paths(), axis=0)
        scen_p50 = np.median(scen_sim.balance_paths(), axis=0)
        client_name = next((c["name"] for c in clients if c["client"] == scen.client), None)
        return dict(
            as_of=_d(cutoff), horizon=horizon, threshold=threshold, balance_now=_f(base_sim.bal_now),
            applied=_describe(scen, client_name),
            base=dict(forecast=self._quantiles(base_sim, base_risk), risk=self._risk_dict(base_risk)),
            scenario=dict(forecast=self._quantiles(scen_sim, scen_risk), risk=self._risk_dict(scen_risk)),
            delta=dict(end_balance=_f(scen_p50[-1] - base_p50[-1]), min_balance=_f(scen_p50.min() - base_p50.min()),
                       probability=_f(scen_risk.p_gap - base_risk.p_gap)),
        )

    # -- plan vs fact ---------------------------------------------------------------
    def planfact(self, company_id: str, as_of: str | None = None, plan_days: int = 14, threshold: float = 0.0) -> dict:
        info = self._info(company_id)
        now = self._cutoff(info, as_of)
        if not 7 <= plan_days <= MAX_HORIZON:
            raise ForecastError(f"Период план-факта должен быть от 7 до {MAX_HORIZON} дней")
        plan_date = now - pd.Timedelta(days=plan_days)
        if plan_date < info.first_date + pd.Timedelta(days=MIN_HISTORY_DAYS):
            raise ForecastError("Слишком мало истории для план-факта на эту дату")
        key = ("planfact", company_id, now, plan_days, threshold, self.events.version(company_id))
        return self._cached(key, lambda: self._build_planfact(info, plan_date, now, threshold))

    def _build_planfact(self, info: CompanyInfo, plan_date: pd.Timestamp, now: pd.Timestamp, threshold: float) -> dict:
        cs = self.ds.series[info.company_id]
        plan = self._simulate(info, plan_date, 30)
        pf = plan_fact(plan, cs, self.ops_by_company[info.company_id], now, self.model.book)
        risk_then = self._assess(info, plan, threshold)
        risk_now = self._assess(info, self._simulate(info, now, 30), threshold)
        return dict(
            plan_date=_d(pf["plan_date"]), now=_d(now), days=pf["days"],
            totals={k: _f(v) for k, v in pf["totals"].items()},
            weeks=[{k: (_d(v) if k in ("start", "end") else (v if k == "outside" else _f(v))) for k, v in w.items()}
                   for w in pf["weeks"]],
            items=[dict(date=_d(i["date"]), label=i["label"], kind=i["kind"], amount=_f(i["amount"]),
                        status=i["status"], fact_date=_d(i["fact_date"]), fact_amount=_f(i["fact_amount"]),
                        delay_days=int(i["delay_days"]), date_late=_d(i["date_late"])) for i in pf["items"]],
            unplanned=[dict(date=_d(u["date"]), label=u["label"], counterparty=u["counterparty"],
                            amount=_f(u["amount"]), category=u["category"]) for u in pf["unplanned"]],
            alerts=pf["alerts"], counts=pf["counts"],
            risk_then=self._risk_dict(risk_then), risk_now=self._risk_dict(risk_now),
        )

    # -- owner's events ---------------------------------------------------------------
    def list_events(self, company_id: str) -> list[dict]:
        self._info(company_id)
        return [e.as_dict() for e in self.events.list(company_id)]

    def add_event(self, company_id: str, date: str, amount: float, label: str, user: str) -> dict:
        self._info(company_id)
        return self.events.add(company_id, date, amount, label, user).as_dict()

    def delete_event(self, company_id: str, event_id: int) -> bool:
        self._info(company_id)
        return self.events.delete(company_id, event_id)


def _describe(scen: Scenario, client_name: str | None) -> list[str]:
    out = []
    if scen.client_delay_days:
        who = f"Клиент {client_name}" if client_name else "Все клиенты"
        out.append(f"{who} платит на {scen.client_delay_days} дн. позже обычного")
    if scen.revenue_factor != 1:
        out.append(f"Новые продажи {scen.revenue_factor - 1:+.0%}")
    if scen.fixed_cost_factor != 1:
        out.append(f"Аренда, коммунальные и услуги {scen.fixed_cost_factor - 1:+.0%}")
    if scen.purchase_factor != 1:
        out.append(f"Закупки и прочие расходы {scen.purchase_factor - 1:+.0%}")
    for ev in scen.extra:
        out.append(f"{ev.label}: {rub(ev.amount)} {ev.date:%d.%m}")
    return out or ["Без изменений: совпадает с базовым прогнозом"]
