"""Load and validate bank statements.

The case format is CSV, UTF-8 with BOM, `;` separator. Real exports differ, so the loader
also accepts: cp1251, `,` / tab separators, Russian/English column names, `ДД.ММ.ГГГГ` dates,
decimal commas, signed amounts instead of a direction column, a missing balance column,
a ZIP archive or a folder with one CSV per company. Every guess is reported in `notes`.
"""
import io
import re
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

from cashradar.domain import schema as s

MAX_ZIP_BYTES = 1_500_000_000
EXCEL_SUFFIXES = (".xlsx", ".xlsm")
TABLE_SUFFIXES = (".csv",) + EXCEL_SUFFIXES   # what counts as a statement inside an archive or a folder

COLUMN_ALIASES = {
    s.COMPANY: ["company_id", "company", "компания", "id_компании", "client_id", "клиент"],
    s.OP_ID: ["operation_id", "op_id", "id", "id_операции", "номер_операции"],
    s.DATE: ["operation_date", "date", "дата", "дата_операции", "дата_проводки", "дата_платежа",
             "transaction_date", "posting_date"],
    s.AMOUNT: ["amount", "сумма", "sum", "сумма_операции"],
    s.DIRECTION: ["direction", "направление", "тип_операции", "вид_операции"],
    s.INN: ["counterparty_inn", "inn", "инн", "инн_контрагента"],
    s.CP_NAME: ["counterparty_name", "counterparty", "контрагент", "наименование_контрагента", "корреспондент"],
    s.PURPOSE: ["payment_purpose", "purpose", "назначение", "назначение_платежа", "description", "описание"],
    s.BALANCE: ["balance_eod", "balance", "остаток", "остаток_на_конец_дня", "исходящий_остаток", "closing_balance"],
}
# bank statement layout without one amount column: money in and money out in separate columns
# (in a client's statement «Кредит» is money in, «Дебет» is money out)
INFLOW_COLUMNS = ["кредит", "приход", "поступление", "поступления", "зачисление", "сумма_по_кредиту",
                  "сумма_прихода", "credit", "inflow", "money_in", "credit_amount"]
OUTFLOW_COLUMNS = ["дебет", "расход", "списание", "списания", "сумма_по_дебету", "сумма_расхода",
                   "debit", "outflow", "money_out", "debit_amount"]
INFLOW_WORDS = {"поступление", "приход", "зачисление", "in", "inflow", "credit", "кредит", "+"}
OUTFLOW_WORDS = {"списание", "расход", "out", "outflow", "debit", "дебет", "-"}


@dataclass
class LoadIssue:
    row: int
    column: str
    problem: str


@dataclass
class LoadResult:
    ops: pd.DataFrame
    issues: list[LoadIssue] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    balance_reconstructed: bool = False

    @property
    def n_rejected(self) -> int:
        return len({i.row for i in self.issues})

    def issue_summary(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for i in self.issues:
            key = f"{i.column}: {i.problem}"
            out[key] = out.get(key, 0) + 1
        return out


class StatementFormatError(ValueError):
    pass


# -- reading ---------------------------------------------------------------------

def read_table(data: bytes | str | Path) -> pd.DataFrame:
    """CSV with unknown encoding and separator, everything as strings."""
    raw = Path(data).read_bytes() if isinstance(data, (str, Path)) else data
    for encoding in ("utf-8-sig", "cp1251"):
        try:
            text = raw.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    else:
        raise StatementFormatError("Не удалось определить кодировку файла (ожидается UTF-8 или Windows-1251)")
    first = text.split("\n", 1)[0]
    sep = max([";", ",", "\t"], key=first.count)
    return pd.read_csv(io.StringIO(text), sep=sep, dtype=str, keep_default_na=False)


def read_csv(path: str | Path) -> pd.DataFrame:
    return read_table(path)


def read_excel(data: bytes | str | Path) -> pd.DataFrame:
    """First sheet of an Excel workbook, everything as strings."""
    try:
        import openpyxl  # noqa: F401
    except ImportError as e:
        raise StatementFormatError("Для Excel нужен пакет openpyxl (uv sync --all-extras) — или сохраните файл как CSV") from e
    src = io.BytesIO(data) if isinstance(data, bytes) else data
    return pd.read_excel(src, sheet_name=0, dtype=str).fillna("")


def read_member(name: str, data: bytes | str | Path) -> pd.DataFrame:
    return read_excel(data) if name.lower().endswith(EXCEL_SUFFIXES) else read_table(data)


def _csv_members(names: list[str]) -> tuple[list[str], str | None]:
    """Pick statement files among CSV/Excel names: all_operations wins, else every other table."""
    tables = [n for n in names if n.lower().endswith(TABLE_SUFFIXES) and not n.endswith("/")
              and not Path(n).name.startswith(("~$", "."))]  # Excel lock files, macOS metadata
    companies = next((n for n in tables if Path(n).stem.lower() == "companies"), None)
    whole = [n for n in tables if Path(n).stem.lower() == "all_operations"]
    statements = whole or [n for n in tables if n != companies]
    return statements, companies


def read_source(path: str | Path) -> tuple[list[tuple[str, pd.DataFrame]], pd.DataFrame | None]:
    """A CSV file, a ZIP archive or a folder → [(name, table)], companies table or None."""
    path = Path(path)
    if path.is_dir():
        names = [str(p.relative_to(path)).replace("\\", "/") for p in path.rglob("*") if p.is_file()]
        statements, companies = _csv_members(names)
        tables = [(Path(n).stem, read_member(n, path / n)) for n in sorted(statements)]
        return tables, read_member(companies, path / companies) if companies else None
    if path.suffix.lower() == ".zip":
        with zipfile.ZipFile(path) as zf:
            infos = [i for i in zf.infolist() if not i.is_dir()]
            if sum(i.file_size for i in infos) > MAX_ZIP_BYTES:
                raise StatementFormatError("Архив слишком большой")
            statements, companies = _csv_members([i.filename for i in infos])
            # read members in memory: nothing from the archive is written to disk
            tables = [(Path(n).stem, read_member(n, zf.read(n))) for n in sorted(statements)]
            return tables, read_member(companies, zf.read(companies)) if companies else None
    return [(path.stem, read_member(path.name, path))], None


# -- normalization ---------------------------------------------------------------------

def _key(name: str) -> str:
    return re.sub(r"[\s\-]+", "_", name.strip().lower())


def normalize_columns(raw: pd.DataFrame, source_name: str = "") -> tuple[pd.DataFrame, list[str]]:
    """Rename known aliases to the case schema and fill optional columns."""
    notes = []
    by_key = {_key(c): c for c in raw.columns}
    rename = {}
    for target, aliases in COLUMN_ALIASES.items():
        for a in aliases:
            if a in by_key and by_key[a] not in rename:
                rename[by_key[a]] = target
                if by_key[a] != target:
                    notes.append(f"колонка «{by_key[a]}» распознана как {target}")
                break
    df = raw.rename(columns=rename)
    if s.AMOUNT not in df:
        cin = next((by_key[k] for k in INFLOW_COLUMNS if k in by_key), None)
        cout = next((by_key[k] for k in OUTFLOW_COLUMNS if k in by_key), None)
        if cin is not None and cout is not None:
            signed = _parse_amount(raw[cin]).fillna(0) - _parse_amount(raw[cout]).fillna(0)
            df[s.AMOUNT] = signed.astype(str)
            notes.append(f"сумма собрана из колонок «{cin}» (поступления) и «{cout}» (списания)")
    if s.DATE not in df or s.AMOUNT not in df:
        raise StatementFormatError("В выписке нет даты или суммы операции "
                                   f"(найдены колонки: {', '.join(map(str, raw.columns))})")
    if s.COMPANY not in df:
        df[s.COMPANY] = source_name or "C_UPLOAD"
        notes.append(f"нет company_id: все операции файла отнесены к компании «{df[s.COMPANY].iloc[0]}»")
    for col in (s.INN, s.CP_NAME, s.PURPOSE):
        if col not in df:
            df[col] = ""
            notes.append(f"нет колонки {col}: категоризация будет менее точной")
    if s.OP_ID not in df:
        df[s.OP_ID] = [f"{c}-{i:07d}" for i, c in enumerate(df[s.COMPANY])]
    return df, notes


def _parse_amount(col: pd.Series) -> pd.Series:
    cleaned = (col.astype(str).str.replace(" ", "", regex=False).str.replace(" ", "", regex=False)
               .str.replace(",", ".", regex=False))
    return pd.to_numeric(cleaned, errors="coerce")


def _parse_date(col: pd.Series) -> pd.Series:
    col = col.astype(str).str.strip().str.slice(0, 10)
    iso = pd.to_datetime(col, format="%Y-%m-%d", errors="coerce")
    ru = pd.to_datetime(col, format="%d.%m.%Y", errors="coerce")
    return iso.fillna(ru)


def validate(raw: pd.DataFrame, source_name: str = "") -> LoadResult:
    """Coerce types and reject rows that cannot be used. Never raises on bad rows,
    only on a structurally wrong file (no date or amount)."""
    df, notes = normalize_columns(raw, source_name)
    issues: list[LoadIssue] = []
    balance_reconstructed = False

    def reject(mask: pd.Series, column: str, problem: str) -> None:
        for idx in df.index[mask]:
            issues.append(LoadIssue(int(idx), column, problem))

    df[s.DATE] = _parse_date(df[s.DATE])
    reject(df[s.DATE].isna(), s.DATE, "дата не распознана (ожидается ГГГГ-ММ-ДД или ДД.ММ.ГГГГ)")

    df[s.AMOUNT] = _parse_amount(df[s.AMOUNT])
    reject(df[s.AMOUNT].isna(), s.AMOUNT, "сумма не число")

    if s.DIRECTION in df:
        word = df[s.DIRECTION].astype(str).str.strip().str.lower()
        sign = np.where(word.isin(INFLOW_WORDS), 1, np.where(word.isin(OUTFLOW_WORDS), -1, 0))
        reject(pd.Series(sign == 0, index=df.index), s.DIRECTION, "неизвестное направление")
        if (df[s.AMOUNT] < 0).any():
            notes.append("в колонке суммы есть отрицательные значения: берём модуль, направление — из колонки направления")
    else:
        sign = np.where(df[s.AMOUNT] >= 0, 1, -1)
        notes.append("нет колонки направления: поступление/списание определено по знаку суммы")
    df[s.SIGN] = sign
    df[s.AMOUNT] = df[s.AMOUNT].abs()
    reject(df[s.AMOUNT] == 0, s.AMOUNT, "нулевая сумма")
    df[s.DIRECTION] = np.where(df[s.SIGN] > 0, s.INFLOW, s.OUTFLOW)

    if s.BALANCE in df:
        df[s.BALANCE] = _parse_amount(df[s.BALANCE])
        reject(df[s.BALANCE].isna(), s.BALANCE, "остаток не число")

    df[s.COMPANY] = df[s.COMPANY].astype(str).str.strip()
    reject(df[s.COMPANY] == "", s.COMPANY, "пустой company_id")

    bad = sorted({i.row for i in issues})
    df = df.drop(index=bad)

    df[s.INN] = df[s.INN].astype(str).str.strip().replace({"": pd.NA, "nan": pd.NA})
    df[s.PURPOSE] = df[s.PURPOSE].fillna("").astype(str).str.strip()
    df[s.CP_NAME] = df[s.CP_NAME].fillna("").astype(str).str.strip()
    df[s.SIGNED] = df[s.AMOUNT] * df[s.SIGN]
    df = df.sort_values([s.COMPANY, s.DATE, s.OP_ID], kind="stable").reset_index(drop=True)

    if s.BALANCE not in df:
        # relative balance: starts at 0, gaps are then «balance below the starting level»
        net_by_day = df.groupby([s.COMPANY, s.DATE])[s.SIGNED].transform("sum")
        first_of_day = ~df.duplicated([s.COMPANY, s.DATE])
        day_net = net_by_day.where(first_of_day, 0.0)
        df[s.BALANCE] = day_net.groupby(df[s.COMPANY]).cumsum()
        df[s.BALANCE] = df.groupby([s.COMPANY, s.DATE])[s.BALANCE].transform("max")
        balance_reconstructed = True
        notes.append("нет остатка на конец дня: остаток восстановлен от нуля по оборотам (только относительные значения)")

    cols = s.REQUIRED_COLUMNS + [s.SIGN, s.SIGNED]
    return LoadResult(df[cols], issues, notes, balance_reconstructed)


def load_operations(path: str | Path) -> LoadResult:
    """A CSV statement, a ZIP archive, or a folder (all_operations.csv or one CSV per company)."""
    return load_dataset(path)[0]


def load_dataset(path: str | Path) -> tuple[LoadResult, pd.DataFrame]:
    tables, companies_raw = read_source(path)
    if not tables:
        raise StatementFormatError("В источнике нет CSV-файлов с операциями")
    results = [validate(t, name) for name, t in tables]
    ops = pd.concat([r.ops for r in results], ignore_index=True)
    ops = ops.sort_values([s.COMPANY, s.DATE, s.OP_ID], kind="stable").reset_index(drop=True)
    issues = [i for r in results for i in r.issues]
    notes = sorted({n for r in results for n in r.notes})
    if len(tables) > 1:
        notes.insert(0, f"прочитано файлов с операциями: {len(tables)}")
    result = LoadResult(ops, issues, notes, any(r.balance_reconstructed for r in results))
    companies = companies_from(companies_raw, ops)
    return result, companies


def companies_from(raw: pd.DataFrame | None, ops: pd.DataFrame) -> pd.DataFrame:
    """Company directory: from companies.csv when given, otherwise derived from the operations."""
    derived = (ops.groupby(s.COMPANY).agg(first_operation_date=(s.DATE, "min"), last_operation_date=(s.DATE, "max"),
                                           operations_count=(s.AMOUNT, "size")).reset_index())
    derived["company_name"] = derived[s.COMPANY]
    derived["industry"] = ""
    derived["legal_form"] = ""
    if raw is None or s.COMPANY not in raw:
        return derived
    raw = raw.copy()
    keep = [c for c in ("company_id", "company_name", "company_inn", "legal_form", "industry") if c in raw]
    merged = derived.drop(columns=[c for c in ("company_name", "industry", "legal_form") if c in raw]).merge(
        raw[keep], on=s.COMPANY, how="left")
    for col in ("company_name", "industry", "legal_form"):
        if col in merged:
            merged[col] = merged[col].fillna(merged[s.COMPANY] if col == "company_name" else "")
    return merged


def load_companies(path: str | Path) -> pd.DataFrame:
    """Kept for compatibility: companies of a dataset folder or archive."""
    return load_dataset(path)[1]
