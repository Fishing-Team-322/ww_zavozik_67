"""Statement cleaning: duplicates, missing data, opening balance, closed accounts.

The end-of-day balance is treated as ground truth. Every operating day must satisfy
    balance_eod(d) = balance_eod(prev op day) + net(d)
Violations mean either a duplicated row (the bank balance did not count it)
or missing operations (a gap in the export).
"""
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from cashradar.core.config import BALANCE_TOL
from cashradar.domain import schema as s

DUP_KEY = [s.COMPANY, s.DATE, s.AMOUNT, s.DIRECTION, s.INN, s.CP_NAME, s.PURPOSE]
CLOSING_MARKER = "закрытием счета"


@dataclass
class CleaningReport:
    n_input: int
    duplicates_removed: int
    duplicates_unconfirmed: int
    mismatch_days: int
    companies_with_mismatch: int
    closed_companies: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return self.__dict__.copy()


@dataclass
class CleanResult:
    ops: pd.DataFrame
    days: pd.DataFrame
    report: CleaningReport


def day_table(ops: pd.DataFrame) -> pd.DataFrame:
    """One row per (company, operating day) with turnover, balances and reconciliation residual."""
    tmp = ops.assign(
        _in=np.where(ops[s.SIGN] > 0, ops[s.AMOUNT], 0.0),
        _out=np.where(ops[s.SIGN] < 0, ops[s.AMOUNT], 0.0),
    )
    days = (
        tmp.groupby([s.COMPANY, s.DATE], sort=True)
        .agg(inflow=("_in", "sum"), outflow=("_out", "sum"), net=(s.SIGNED, "sum"),
             bal_eod=(s.BALANCE, "first"), n_ops=(s.AMOUNT, "size"))
        .reset_index()
    )
    prev = days.groupby(s.COMPANY)["bal_eod"].shift()
    # First day: opening balance is derived from the day itself (README convention).
    days["bal_open"] = prev.fillna(days["bal_eod"] - days["net"])
    days["resid"] = days["bal_eod"] - days["bal_open"] - days["net"]
    days["gap_days"] = days.groupby(s.COMPANY)[s.DATE].diff().dt.days
    return days


def clean(ops: pd.DataFrame, tol: float = BALANCE_TOL) -> CleanResult:
    n_input = len(ops)
    ops = ops.reset_index(drop=True)
    dup_mask = ops.duplicated(DUP_KEY, keep="first")

    days = day_table(ops).set_index([s.COMPANY, s.DATE])
    dup_sum = ops[dup_mask].groupby([s.COMPANY, s.DATE])[s.SIGNED].sum()
    resid = days.loc[dup_sum.index, "resid"]
    # Duplicate is confirmed when the balance did not count it: removing it closes the residual.
    confirmed_days = dup_sum.index[((resid + dup_sum).abs() < tol) & (resid.abs() >= tol)]
    day_key = pd.MultiIndex.from_frame(ops[[s.COMPANY, s.DATE]])
    drop_mask = dup_mask & day_key.isin(confirmed_days)

    cleaned = ops[~drop_mask].reset_index(drop=True)
    days = day_table(cleaned)
    days["adjustment"] = np.where(days["resid"].abs() >= tol, days["resid"], 0.0)

    mismatch = days["adjustment"] != 0
    closed = sorted(cleaned.loc[cleaned[s.PURPOSE].str.lower().str.contains(CLOSING_MARKER), s.COMPANY].unique())
    report = CleaningReport(
        n_input=n_input,
        duplicates_removed=int(drop_mask.sum()),
        duplicates_unconfirmed=int((dup_mask & ~drop_mask).sum()),
        mismatch_days=int(mismatch.sum()),
        companies_with_mismatch=int(days.loc[mismatch, s.COMPANY].nunique()),
        closed_companies=closed,
    )
    return CleanResult(cleaned, days, report)
