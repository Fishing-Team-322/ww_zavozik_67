"""CLI: categorization coverage report and a stratified sample for manual («gold») labeling.

    uv run python -m cashradar.categorize.report [--data ../data/raw] [--out ../reports/categorization]

The sample file has a `gold_category` column pre-filled with the prediction:
annotators fix wrong values, then `--score` computes accuracy against it.
"""
import argparse
from pathlib import Path

import pandas as pd
from sklearn.metrics import f1_score

from cashradar.categorize.engine import Categorizer
from cashradar.core.config import DATA_DIR, REPORTS_DIR
from cashradar.domain import schema as s
from cashradar.ingest.cleaning import clean
from cashradar.ingest.loader import load_operations

SAMPLE_COLUMNS = [s.OP_ID, s.COMPANY, s.DATE, s.DIRECTION, s.AMOUNT, s.CP_NAME, s.PURPOSE, "category", "cat_source"]


def stratified_sample(ops: pd.DataFrame, n: int = 400, per_category_min: int = 5, seed: int = 7) -> pd.DataFrame:
    """At least `per_category_min` rows per category, everything not from purpose rules over-sampled, the rest random."""
    parts = [g.sample(min(len(g), per_category_min), random_state=seed) for _, g in ops.groupby("category")]
    tricky = ops[ops["cat_source"] != "rule:purpose"]
    parts.append(tricky.sample(min(len(tricky), n // 4), random_state=seed))
    taken = pd.concat(parts)
    rest = ops.drop(index=taken.index, errors="ignore")
    parts.append(rest.sample(max(0, n - len(taken.index.unique())), random_state=seed))
    sample = pd.concat(parts)
    sample = sample[~sample.index.duplicated()]
    return sample[SAMPLE_COLUMNS].assign(gold_category=sample["category"]).sort_values([s.DIRECTION, "category"])


def score(sample_path: Path) -> dict:
    g = pd.read_csv(sample_path, sep=";", encoding="utf-8-sig", dtype=str)
    return dict(n=len(g), accuracy=float((g["category"] == g["gold_category"]).mean()),
                macro_f1=float(f1_score(g["gold_category"], g["category"], average="macro")))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=str(DATA_DIR))
    ap.add_argument("--out", default=str(REPORTS_DIR / "categorization"))
    ap.add_argument("--score", action="store_true", help="score the labeled gold_sample.csv instead")
    args = ap.parse_args()
    out = Path(args.out)
    if args.score:
        print(score(out / "gold_sample.csv"))
        return

    ops = Categorizer().categorize(clean(load_operations(args.data).ops).ops)
    out.mkdir(parents=True, exist_ok=True)
    coverage = ops["cat_source"].value_counts().to_frame("operations")
    coverage["share"] = coverage["operations"] / len(ops)
    coverage.to_csv(out / "coverage.csv")
    by_cat = (ops.groupby(["category", "category_name", "category_group"])
              .agg(operations=(s.AMOUNT, "size"), amount_mln=(s.AMOUNT, lambda x: round(x.sum() / 1e6, 1)),
                   companies=(s.COMPANY, "nunique")).reset_index())
    by_cat.to_csv(out / "categories.csv", index=False)
    sample_path = out / "gold_sample.csv"
    if sample_path.exists():
        print(f"{sample_path} already exists, not overwriting (it may contain manual labels)")
    else:
        stratified_sample(ops).to_csv(sample_path, sep=";", index=False, encoding="utf-8-sig")
    print(coverage.to_string())
    print(by_cat.to_string(index=False))


if __name__ == "__main__":
    main()
