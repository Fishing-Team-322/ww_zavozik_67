"""Operation categorizer: purpose rules → counterparty rules → counterparty memory → fallback.

`cat_source` tells where the category came from, so the UI can show it and
the quality report can measure each stage separately.
"""
import re
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

from cashradar.domain import schema as s

DEFAULT_RULES = Path(__file__).with_name("rules.yaml")
FLAGS = ("mandatory", "controllable", "financing", "retail", "stress")
DIRECTION_SIGN = {"in": 1, "out": -1}


@dataclass(frozen=True)
class Category:
    id: str
    name: str
    group: str
    direction: str
    flags: frozenset[str]


@dataclass(frozen=True)
class Rule:
    category: str
    sign: int
    purpose: re.Pattern | None
    counterparty: re.Pattern | None


def normalize_text(series: pd.Series) -> pd.Series:
    return series.fillna("").str.lower().str.replace("ё", "е", regex=False).str.strip()


def counterparty_key(ops: pd.DataFrame) -> pd.Series:
    """INN when present, otherwise normalized name."""
    return ops[s.INN].fillna("name:" + normalize_text(ops[s.CP_NAME])).astype(str)


class Categorizer:
    def __init__(self, rules_path: str | Path = DEFAULT_RULES):
        cfg = yaml.safe_load(Path(rules_path).read_text(encoding="utf-8"))
        self.categories: dict[str, Category] = {
            cid: Category(cid, c["name"], c["group"], c["direction"], frozenset(c.get("flags", [])))
            for cid, c in cfg["categories"].items()
        }
        self.rules: list[Rule] = []
        for r in cfg["rules"]:
            cat = self.categories[r["category"]]  # KeyError = typo in rules.yaml
            self.rules.append(Rule(
                category=cat.id,
                sign=DIRECTION_SIGN[cat.direction],
                purpose=re.compile(r["purpose"]) if "purpose" in r else None,
                counterparty=re.compile(r["counterparty"]) if "counterparty" in r else None,
            ))

    def categorize(self, ops: pd.DataFrame, overrides: dict[tuple[str, str, int], str] | None = None) -> pd.DataFrame:
        """Return a copy of `ops` with category columns.

        overrides: user corrections {(company_id, counterparty_key, sign): category_id};
        they win over everything else and act as counterparty memory.
        """
        out = ops.copy()
        purpose = normalize_text(out[s.PURPOSE])
        cp_name = normalize_text(out[s.CP_NAME])
        cp_key = counterparty_key(out)
        sign = out[s.SIGN].to_numpy()
        category = np.full(len(out), None, dtype=object)
        source = np.full(len(out), None, dtype=object)

        if overrides:
            keys = list(zip(out[s.COMPANY], cp_key, sign))
            for i, k in enumerate(keys):
                if k in overrides:
                    category[i], source[i] = overrides[k], "user"

        for field, text in (("purpose", purpose), ("counterparty", cp_name)):
            for rule in self.rules:
                pattern = getattr(rule, field)
                if pattern is None:
                    continue
                todo = (category == None) & (sign == rule.sign)  # noqa: E711
                if not todo.any():
                    continue
                hit = np.zeros(len(out), dtype=bool)
                hit[todo] = text[todo].str.contains(pattern).to_numpy()
                category[hit] = rule.category
                source[hit] = f"rule:{field}"

        # Counterparty memory: the most frequent category of the same counterparty,
        # first within the company, then across all companies.
        known = category != None  # noqa: E711
        frame = pd.DataFrame({"company": out[s.COMPANY].to_numpy(), "cp": cp_key.to_numpy(), "sign": sign, "cat": category})
        for keys, label in ((["company", "cp", "sign"], "memory:company"), (["cp", "sign"], "memory:global")):
            todo = category == None  # noqa: E711
            if not todo.any():
                break
            mode = frame[known].groupby(keys)["cat"].agg(lambda x: x.value_counts().index[0])
            looked = frame.loc[todo, keys].merge(mode.rename("m").reset_index(), on=keys, how="left")["m"].to_numpy()
            idx = np.flatnonzero(todo)
            found = pd.notna(looked)
            category[idx[found]] = looked[found]
            source[idx[found]] = label

        todo = category == None  # noqa: E711
        category[todo] = np.where(sign[todo] > 0, "in.other", "out.other")
        source[todo] = "fallback"

        out["category"] = category
        out["cat_source"] = source
        return self.decorate(out)

    def decorate(self, ops: pd.DataFrame) -> pd.DataFrame:
        """(Re)derive name, group and flags from the `category` column — also after setting it externally."""
        unknown = set(ops["category"]) - set(self.categories)
        if unknown:
            raise KeyError(f"unknown categories: {sorted(unknown)}")
        ops["category_name"] = ops["category"].map(lambda c: self.categories[c].name)
        ops["category_group"] = ops["category"].map(lambda c: self.categories[c].group)
        for flag in FLAGS:
            members = {cid for cid, c in self.categories.items() if flag in c.flags}
            ops[f"is_{flag}"] = ops["category"].isin(members)
        return ops
