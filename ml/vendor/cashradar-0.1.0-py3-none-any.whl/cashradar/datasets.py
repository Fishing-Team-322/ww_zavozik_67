"""Uploading a dataset (e.g. the organizers' control one) and evaluating it in the background.

    upload (CSV / ZIP) → step-by-step pipeline → the service switches to the new data
    → control run: forecast for every company, backtest on the dataset itself, metrics, confusion matrix

One job at a time; its state (steps, progress, metrics) is polled by the UI.
The uploaded file is stored under data/uploads/ (git-ignored) and never logged.
"""
import math
import re
import threading
import time
import traceback
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path

from cashradar.control.evaluate import run_control, write_report
from cashradar.core.config import REPO_ROOT, REPORTS_DIR
from cashradar.core.logging import get_logger
from cashradar.pipeline import prepare

log = get_logger(__name__)

UPLOAD_DIR = REPO_ROOT / "data" / "uploads"
MAX_UPLOAD_BYTES = 300 * 1024 * 1024
ALLOWED_SUFFIXES = {".csv", ".zip", ".txt", ".xlsx", ".xlsm"}


class UploadError(ValueError):
    pass


@dataclass
class Job:
    id: str
    name: str
    status: str = "queued"          # queued | loading | evaluating | done | error
    steps: list[dict] = field(default_factory=list)
    progress: dict = field(default_factory=dict)
    error: str | None = None
    summary: dict | None = None
    report_path: str | None = None
    started: float = field(default_factory=time.time)
    finished: float | None = None

    def public(self) -> dict:
        d = asdict(self)
        d["seconds"] = round((self.finished or time.time()) - self.started, 1)
        return json_safe(d)


def json_safe(obj):
    """NaN/inf → None, numpy scalars → Python numbers: metrics are often undefined on small datasets."""
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [json_safe(v) for v in obj]
    if hasattr(obj, "item") and not isinstance(obj, (str, bytes)):
        obj = obj.item()
    if isinstance(obj, float) and not math.isfinite(obj):
        return None
    if hasattr(obj, "isoformat"):
        return obj.isoformat()
    return obj


def safe_name(filename: str) -> str:
    stem = re.sub(r"[^\w.\-]+", "_", Path(filename or "dataset.csv").name)[:80] or "dataset.csv"
    if Path(stem).suffix.lower() not in ALLOWED_SUFFIXES:
        raise UploadError("Поддерживаются файлы .csv, .xlsx и .zip")
    return stem


class DatasetManager:
    def __init__(self, service, upload_dir: Path = UPLOAD_DIR, reports_dir: Path = REPORTS_DIR / "control"):
        self.service = service
        self.upload_dir = Path(upload_dir)
        self.reports_dir = Path(reports_dir)
        self.current: Job | None = None
        self._lock = threading.Lock()

    def start(self, filename: str, data: bytes, quick: bool = True, as_of: str | None = None) -> Job:
        name = safe_name(filename)
        if not data:
            raise UploadError("Файл пустой")
        if len(data) > MAX_UPLOAD_BYTES:
            raise UploadError(f"Файл больше {MAX_UPLOAD_BYTES // 2**20} МБ")
        with self._lock:
            if self.current and self.current.status in ("queued", "loading", "evaluating"):
                raise UploadError("Предыдущий датасет ещё обрабатывается")
            job = Job(id=uuid.uuid4().hex[:12], name=name)
            self.current = job
        self.upload_dir.mkdir(parents=True, exist_ok=True)
        path = self.upload_dir / f"{job.id}_{name}"
        path.write_bytes(data)
        threading.Thread(target=self._run, args=(job, path, quick, as_of), daemon=True, name=f"dataset-{job.id}").start()
        return job

    def _run(self, job: Job, path: Path, quick: bool, as_of: str | None = None) -> None:
        try:
            job.status = "loading"
            ds = prepare(path, on_step=job.steps.append)
            self.service.use_dataset(ds, job.name)
            job.status = "evaluating"
            summary, rows, daily = run_control(
                ds, quick=quick, on_step=job.steps.append, as_of=as_of,
                progress=lambda done, total: job.progress.update(done=done, total=total))
            report = write_report(summary, rows, daily, self.reports_dir / f"{Path(job.name).stem}_{job.id}")
            job.summary = {k: summary[k] for k in ("metrics", "config", "main_model", "model_titles", "as_of",
                                                   "definitions", "forecasts")}
            job.report_path = str(report)
            job.status = "done"
        except Exception as e:  # noqa: BLE001 — the UI must show the reason, not hang
            job.status = "error"
            job.error = f"{type(e).__name__}: {e}"[:500]
            log.error("dataset job %s failed: %s", job.id, traceback.format_exc()[-1500:])
        finally:
            job.finished = time.time()
