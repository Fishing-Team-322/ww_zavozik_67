"""CLI: control run on any dataset (CSV, ZIP or folder).

    uv run python -m cashradar.control.run --data ../control.zip [--out ../reports/control/control] [--quick]
    uv run python -m cashradar.control.run --data ../history_and_answer.zip --as-of 2026-09-30

Prints the step-by-step log and writes report.md, summary.json, forecast_by_company.csv,
forecast_daily.csv and backtest_rows.csv.gz into the output folder.
"""
import argparse
import sys
import time
from pathlib import Path

from cashradar.control.evaluate import run_control, write_report
from cashradar.core.config import REPORTS_DIR
from cashradar.pipeline import prepare


def main() -> None:
    ap = argparse.ArgumentParser(description="Контрольный прогон: лог, прогноз, метрики")
    ap.add_argument("--data", required=True, help="CSV, ZIP или папка с выписками")
    ap.add_argument("--out", default=None, help="папка для отчёта (по умолчанию reports/control/<имя данных>)")
    ap.add_argument("--quick", action="store_true", help="6 срезов вместо 12 (быстрее, менее точно)")
    ap.add_argument("--models", default="", help="через запятую; по умолчанию: M0_naive,M1b_month,M3_lgbm,"
                                                  "M5_statement,M6_statement,M6_hybrid")
    ap.add_argument("--as-of", default=None, help="ГГГГ-ММ-ДД: прогноз от этой даты и сверка с данными после неё "
                                                   "(история и «ответ» в одном файле или архиве)")
    args = ap.parse_args()

    t0 = time.time()
    out = Path(args.out) if args.out else REPORTS_DIR / "control" / Path(args.data).stem
    ds = prepare(args.data)
    summary, rows, daily = run_control(ds, quick=args.quick, model_names=[m for m in args.models.split(",") if m] or None,
                                       progress=lambda d, n: print(f"  бэктест: срез {d}/{n}", file=sys.stderr),
                                       as_of=args.as_of)
    report = write_report(summary, rows, daily, out)
    print(report.read_text(encoding="utf-8"))
    print(f"\nОтчёт: {report}  ({time.time() - t0:.0f} с)", file=sys.stderr)


if __name__ == "__main__":
    main()
