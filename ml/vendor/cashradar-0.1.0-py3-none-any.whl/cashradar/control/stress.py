"""Stress suite: «what could the organizers send us?» — hostile variants of the case data.

    uv run python -m cashradar.control.stress [--data ../data/raw] [--companies 20] [--only foreign_format,short_100]

Every variant is written as files (CSV/ZIP, like a real hand-over), loaded through the normal
pipeline and evaluated by the control run (quick mode). The report says, per variant: did it
finish, how long it took, what the loader had to guess, and whether the main model still beats
the naive one. Nothing here is tuned on: it only checks that nothing breaks.
"""
import argparse
import io
import re
import time
import traceback
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

from cashradar.control.evaluate import MAIN_MODEL, run_control
from cashradar.core.config import DATA_DIR, REPORTS_DIR
from cashradar.ingest.loader import read_table
from cashradar.pipeline import prepare

PARAPHRASE = [  # how the same payments could be worded by another generator / bank
    (r"(?i)перечисление заработной платы", "ЗП сотрудникам"), (r"(?i)заработн\w* плат\w*", "оплата труда"),
    (r"(?i)единый налоговый плат[её]ж", "Налог единым платежом"), (r"(?i)\bенп\b", "налог"),
    (r"(?i)оплата аренды нежилого помещения", "Арендная плата за офис"),
    (r"(?i)зачисление средств по операциям эквайринга", "Возмещение по картам (эквайринг)"),
    (r"(?i)оплата по счету", "Платеж по сч."), (r"(?i)оплата по упд", "Платёж по УПД"), (r"№\s*", "N "),
]


def statements(data_dir: Path) -> pd.DataFrame:
    return read_table(Path(data_dir) / "all_operations.csv")


def pick(raw: pd.DataFrame, n: int, seed: int = 7) -> pd.DataFrame:
    ids = sorted(raw["company_id"].unique())
    keep = set(np.random.default_rng(seed).choice(ids, size=min(n, len(ids)), replace=False))
    return raw[raw["company_id"].isin(keep)].copy()


def to_zip(df: pd.DataFrame, path: Path, by_company: bool = True, encoding: str = "utf-8-sig", sep: str = ";") -> Path:
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        groups = df.groupby("company_id") if by_company and "company_id" in df else [("all_operations", df)]
        for cid, g in groups:
            name = f"statements/{cid}.csv" if by_company else "all_operations.csv"
            zf.writestr(name, g.to_csv(sep=sep, index=False).encode(encoding))
    return path


def variants(raw: pd.DataFrame, n: int, out: Path) -> dict[str, Path]:
    base = pick(raw, n)
    out.mkdir(parents=True, exist_ok=True)
    v: dict[str, Path] = {}
    v["as_is"] = to_zip(base, out / "as_is.zip")

    f = base.copy()
    f["Сумма"] = np.where(f["direction"] == "Списание", "-", "") + f["amount"].str.replace(".", ",", regex=False)
    f["Дата"] = pd.to_datetime(f["operation_date"]).dt.strftime("%d.%m.%Y")
    f = f.rename(columns={"company_id": "Клиент", "counterparty_inn": "ИНН контрагента", "counterparty_name": "Контрагент",
                          "payment_purpose": "Назначение платежа", "balance_eod": "Остаток"})
    f = f[["Клиент", "Дата", "Сумма", "ИНН контрагента", "Контрагент", "Назначение платежа", "Остаток"]]
    f["Остаток"] = f["Остаток"].str.replace(".", ",", regex=False)
    p = out / "foreign_format.csv"
    p.write_bytes(f.to_csv(sep=",", index=False).encode("cp1251", errors="replace"))
    v["foreign_format"] = p

    v["no_balance"] = to_zip(base.drop(columns=["balance_eod"]), out / "no_balance.zip")

    g = base.copy()
    g["payment_purpose"] = ""
    g["counterparty_name"] = ""
    v["no_purpose"] = to_zip(g, out / "no_purpose.zip")

    g = base.copy()
    for pat, rep in PARAPHRASE:
        g["payment_purpose"] = g["payment_purpose"].str.replace(pat, rep, regex=True)
    g["payment_purpose"] = g["payment_purpose"].str.upper()
    v["paraphrased"] = to_zip(g, out / "paraphrased.zip")

    d = pd.to_datetime(base["operation_date"])
    for days, name in ((100, "short_100"), (45, "short_45")):
        cut = d.max() - pd.Timedelta(days=days)
        v[name] = to_zip(base[d > cut], out / f"{name}.zip")

    g = base.copy()  # 104 weeks back: weekdays stay, years and holidays change
    g["operation_date"] = (d - pd.Timedelta(weeks=104)).dt.strftime("%Y-%m-%d")
    v["other_years"] = to_zip(g, out / "other_years.zip")

    one = base[base["company_id"] == base["company_id"].iloc[0]]
    v["single_company"] = out / "single_company.csv"
    v["single_company"].write_bytes(one.to_csv(sep=";", index=False).encode("utf-8-sig"))

    big = pd.concat([raw.assign(company_id=raw["company_id"] + f"_{k}") for k in range(3)], ignore_index=True)
    v["big_450"] = to_zip(big, out / "big_450.zip", by_company=False)

    rng = np.random.default_rng(1)
    g = base.copy()
    dup = g.sample(frac=0.02, random_state=1)
    days = sorted(pd.to_datetime(g["operation_date"]).dt.strftime("%Y-%m-%d").unique())
    drop_days = set(rng.choice(days, size=len(days) // 30, replace=False))
    g = pd.concat([g[~g["operation_date"].isin(drop_days)], dup], ignore_index=True)
    junk = g.sample(5, random_state=2).copy()
    junk["operation_date"] = ["не дата", "2026-13-01", "", "31.02.2026", "abc"]
    junk["amount"] = ["NaN", "-", "1e999", "", "сто"]
    g = pd.concat([g, junk], ignore_index=True).sample(frac=1.0, random_state=3)
    v["dirty"] = to_zip(g, out / "dirty.zip", by_company=False)
    return v


def check(name: str, path: Path, quick: bool = True) -> dict:
    t0 = time.time()
    row = dict(variant=name, file=path.name)
    try:
        ds = prepare(path)
        load = ds.steps[0]["details"]
        row.update(companies=len(ds.series), operations=len(ds.ops), rejected=load["rejected_rows"],
                   notes=" | ".join(load["notes"])[:160])
        summary, rows, _ = run_control(ds, quick=quick)
        row["forecasts"] = len(summary["forecasts"])
        m = summary.get("metrics") or {}
        bal, gaps = m.get("balance", {}), m.get("gaps", {})
        if bal:
            main, naive = bal.get(MAIN_MODEL, {}), bal.get("M0_naive", {})
            row["windows"] = main.get("windows")
            row["mae_vs_naive"] = round(main["mae_rub"] / naive["mae_rub"], 3) if naive.get("mae_rub") else None
            g = gaps.get(MAIN_MODEL, {})
            row.update(gap_events=g.get("positives"), f1=round(g.get("f1", float("nan")), 3),
                       accuracy=round(g.get("accuracy", float("nan")), 3))
        else:
            row["windows"] = 0
            row["note_backtest"] = summary["steps"][-1]["details"].get("skipped", "")
        row["status"] = "ok"
    except Exception as e:  # noqa: BLE001 — the point is to see what breaks
        row.update(status="FAIL", error=f"{type(e).__name__}: {e}"[:200], trace=traceback.format_exc()[-800:])
    row["seconds"] = round(time.time() - t0, 1)
    return row


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=str(DATA_DIR))
    ap.add_argument("--companies", type=int, default=20)
    ap.add_argument("--only", default="", help="comma-separated variant names")
    ap.add_argument("--work", default=str(REPORTS_DIR / "stress" / "data"))
    args = ap.parse_args()
    raw = statements(Path(args.data))
    files = variants(raw, args.companies, Path(args.work))
    only = {x for x in args.only.split(",") if x}
    rows = []
    for name, path in files.items():
        if only and name not in only:
            continue
        r = check(name, path)
        print(f"{name:16s} {r['status']:4s} {r['seconds']:6.1f}s  companies={r.get('companies')} windows={r.get('windows')} "
              f"mae/naive={r.get('mae_vs_naive')} f1={r.get('f1')} {r.get('error', '')}", flush=True)
        rows.append(r)
    out = Path(args.work).parent
    rep = pd.DataFrame(rows)
    if only and (out / "stress_report.csv").exists():  # a partial rerun updates its rows, keeps the others
        old = pd.read_csv(out / "stress_report.csv", encoding="utf-8-sig")
        rep = pd.concat([old[~old["variant"].isin(only)], rep], ignore_index=True)
        rep = rep.set_index("variant").reindex([v for v in files if v in set(rep["variant"])]).reset_index()
    rep.to_csv(out / "stress_report.csv", index=False, encoding="utf-8-sig")
    print(rep.drop(columns=[c for c in ("trace",) if c in rep]).to_string(index=False))


if __name__ == "__main__":
    main()
