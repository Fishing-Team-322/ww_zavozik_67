"""Control run on an arbitrary dataset: step-by-step log, forecasts, quality metrics.

Used by the CLI (`python -m cashradar.control.run`) and by the API after a dataset upload.
Steps 1–5 come from cashradar.pipeline.prepare; this module adds:
    6. regular payments found,  7. forecast for every company at its last date (or at `as_of`),
    8. rolling-origin backtest on the dataset itself (or one cutoff at `as_of`),  9. metrics with confusion matrices.

The main model is M6 fed by the statement alone: at a past cutoff its invoice registry knows only
invoices already paid by then. «M6 + реестр счетов» rebuilds the registry from the whole statement,
standing in for an accounting system (it knows invoices paid after the cutoff) — it shows what
that additional source is worth, but is not a fair forecast of the statement alone.
"""
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score

from cashradar.core.config import REPORTS_DIR
from cashradar.core.logging import get_logger
from cashradar.evaluation.backtest import BacktestConfig, run_backtest, truth
from cashradar.forecast.baselines import FLOW_FEATURES, GlobalGBM, NaiveFlat, SameDayOfMonth
from cashradar.forecast.structural import StructuralWithInvoices
from cashradar.pipeline import Dataset
from cashradar.recurring.detector import detect
from cashradar.risk.engine import ProbabilityCalibrator, assess
from cashradar.sources.invoices import InvoiceBook

log = get_logger(__name__)

ARTIFACTS = Path(__file__).resolve().parents[1] / "artifacts"
CALIBRATOR_FILES = {"M6_statement": "calibrator_M6_statement.json", "M6_hybrid": "calibrator_M6.json"}
MAIN_MODEL = "M6_statement"
RED_LEVEL = 0.4      # calibrated probability that turns the risk «red» in the product
HORIZON = 30

MODEL_TITLES = {
    "M0_naive": "M0: остаток не меняется (naive)",
    "M1b_month": "M1b: как в тот же день прошлого месяца",
    "M3_lgbm": "M3: LightGBM по дневному ряду",
    "M5_statement": "M5: структурная модель, только выписка",
    "M5_struct_invoices": "M5 + реестр счетов (имитация 1С)",
    "M6_statement": "M6: гибрид M5 + LightGBM, только выписка (основная)",
    "M6_hybrid": "M6 + реестр счетов (имитация 1С)",
}
DEFAULT_MODELS = ["M0_naive", "M1b_month", "M3_lgbm", "M5_statement", "M6_statement", "M6_hybrid"]


def model_zoo(ds: Dataset, names: list[str] | None = None) -> list:
    """M5/M6 variants share one invoice registry; the statement-only M6 shares M6's LightGBM when both run.
    In the backtest LightGBM is retrained on this dataset, on data before each cutoff only."""
    from cashradar.forecast.hybrid import HybridForecaster

    names = [n for n in (names or DEFAULT_MODELS) if n in MODEL_TITLES]
    book = InvoiceBook(ds.ops) if any(n[:2] in ("M5", "M6") for n in names) else None
    m6 = HybridForecaster(ds.ops, book=book) if "M6_hybrid" in names else None

    def m6_statement():
        m = HybridForecaster(ds.ops, book=book, gbm=m6.gbm if m6 else None, point_in_time=True, name="M6_statement")
        if m6 is not None:
            m.needs_training = False
        return m

    makers = {
        "M0_naive": NaiveFlat,
        "M1b_month": SameDayOfMonth,
        "M3_lgbm": GlobalGBM,
        "M5_statement": lambda: StructuralWithInvoices(ds.ops, book=book, point_in_time=True, name="M5_statement"),
        "M5_struct_invoices": lambda: StructuralWithInvoices(ds.ops, book=book),
        "M6_statement": m6_statement,
        "M6_hybrid": lambda: m6,
    }
    return [makers[n]() for n in names]


def load_calibrators() -> dict[str, ProbabilityCalibrator]:
    out = {}
    for name, file in CALIBRATOR_FILES.items():
        if (ARTIFACTS / file).exists():
            out[name] = ProbabilityCalibrator.load(ARTIFACTS / file)
    return out


# (history before a cutoff, horizon) from the preferred one down to what a short export still allows
BACKTEST_LADDER = ((90, 30), (56, 30), (42, 14), (28, 14), (21, 7))


def auto_config(ds: Dataset, quick: bool) -> BacktestConfig | None:
    """Cutoffs spread over the dataset with enough history before and a full horizon after.
    Short exports get a shorter history requirement and horizon instead of no check at all."""
    first = min(cs.first_date for cs in ds.series.values())
    last = max(cs.last_date for cs in ds.series.values())
    for min_history, horizon in BACKTEST_LADDER:
        start, end = first + pd.Timedelta(days=min_history), last - pd.Timedelta(days=horizon)
        if end >= start:
            break
    else:
        return None
    n_cutoffs = 6 if quick else 12
    step = max(7, math.ceil(((end - start).days + 1) / n_cutoffs))
    # align the last cutoff to the end of the data: the most recent windows are the most relevant
    start = max(end - pd.Timedelta(days=step * (n_cutoffs - 1)), start)
    return BacktestConfig(start=f"{start:%Y-%m-%d}", end=f"{end:%Y-%m-%d}", step_days=step, horizon=horizon,
                          min_history_days=min_history, retrain_every_days=91)


def fixed_config(ds: Dataset, as_of: pd.Timestamp) -> BacktestConfig | None:
    """One cutoff at `as_of`: for hand-overs of «history up to a date + what happened after it».
    The horizon is what the data after as_of allows, at most 30 days."""
    first = min(cs.first_date for cs in ds.series.values())
    last = max(cs.last_date for cs in ds.series.values())
    horizon = min(HORIZON, (last - as_of).days)
    history = [h for h, _ in BACKTEST_LADDER if first + pd.Timedelta(days=h) <= as_of]
    if horizon < 7 or not history:
        return None
    return BacktestConfig(start=f"{as_of:%Y-%m-%d}", end=f"{as_of:%Y-%m-%d}", step_days=7, horizon=horizon,
                          min_history_days=history[0], retrain_every_days=91)


def check_as_of(ds: Dataset, as_of: str | None) -> pd.Timestamp | None:
    if not as_of:
        return None
    when = pd.Timestamp(as_of)
    first = min(cs.first_date for cs in ds.series.values())
    last = max(cs.last_date for cs in ds.series.values())
    if not first < when < last:
        raise ValueError(f"Дата прогноза {when:%d.%m.%Y} вне периода данных {first:%d.%m.%Y}–{last:%d.%m.%Y}")
    return when


def classification(y: np.ndarray, pred: np.ndarray, score: np.ndarray | None = None,
                   prob: np.ndarray | None = None) -> dict:
    y, pred = y.astype(bool), pred.astype(bool)
    tp, fp = int((y & pred).sum()), int((~y & pred).sum())
    fn, tn = int((y & ~pred).sum()), int((~y & ~pred).sum())
    n = tp + fp + fn + tn
    precision = tp / (tp + fp) if tp + fp else float("nan")
    recall = tp / (tp + fn) if tp + fn else float("nan")
    f1 = 2 * precision * recall / (precision + recall) if tp else 0.0
    both = len(np.unique(y)) == 2
    out = dict(n=n, positives=int(y.sum()), accuracy=(tp + tn) / n if n else float("nan"),
               precision=precision, recall=recall, f1=f1, specificity=tn / (tn + fp) if tn + fp else float("nan"),
               confusion=dict(tp=tp, fp=fp, fn=fn, tn=tn))
    if score is not None and both:
        out.update(roc_auc=float(roc_auc_score(y, score)), pr_auc=float(average_precision_score(y, score)))
    if prob is not None:
        out["brier"] = float(np.mean((prob - y) ** 2))
    return out


def balance_metrics(rows: pd.DataFrame) -> dict:
    """Pooled ruble errors are dominated by the few largest companies (in the case data 5% of windows
    carry ~45% of the total error), so the typical-company view is reported next to them:
    errors in units of the company's own daily turnover and the share of windows beaten vs naive."""
    rows = rows[~rows["data_gap"]]
    naive = rows[rows["model"] == "M0_naive"].set_index(["company_id", "cutoff"])["mae_rub"]
    out = {}
    for model, g in rows.groupby("model"):
        m = dict(windows=len(g), mae_rub=float(g["mae_rub"].mean()), mse_rub=float(g["mse_rub"].mean()),
                 rmse_rub=float(math.sqrt(g["mse_rub"].mean())), median_ae_rub=float(g["mae_rub"].median()),
                 nmae_median=float(g["nmae"].median()), nmae_mean=float(g["nmae"].mean()))
        if len(naive) and model != "M0_naive":
            mine, ref = g.set_index(["company_id", "cutoff"])["mae_rub"].align(naive, join="inner")
            m["win_rate_vs_naive"] = float((mine < ref).mean()) if len(mine) else float("nan")
        for h in (7, 14, 30):
            if f"ae_h{h}" in g and g[f"ae_h{h}"].notna().any():
                m[f"mae_h{h}_rub"] = float(g[f"ae_h{h}"].mean())
                m[f"nmae_h{h}_median"] = float(g[f"nae_h{h}"].median())
        if "coverage80" in g and g["coverage80"].notna().any():
            m["coverage80"] = float(g["coverage80"].mean())
        out[model] = m
    return out


def gap_metrics(rows: pd.DataFrame, label: str, calibrators: dict[str, ProbabilityCalibrator]) -> dict:
    """Detection quality for windows starting with a non-negative balance."""
    r = rows[~rows["data_gap"] & (rows["bal_now"] >= 0)]
    out = {}
    for model, g in r.groupby("model"):
        y = g[label].to_numpy(bool)
        has_prob = "p_gap" in g and g["p_gap"].notna().all()
        prob = g["p_gap"].to_numpy() if has_prob else None
        rule = "вероятность ≥ 0.5" if has_prob else "прогнозный остаток < 0"
        out[model] = dict(rule=rule, **classification(y, g["pred_gap"].to_numpy(bool), g["score"].to_numpy(), prob))
        if has_prob and model in calibrators:
            p_cal = calibrators[model](prob)
            out[f"{model} · калиброванная ≥ {RED_LEVEL}"] = dict(
                rule=f"калиброванная вероятность ≥ {RED_LEVEL} («красный» уровень в продукте)",
                **classification(y, p_cal >= RED_LEVEL, p_cal, p_cal))
        if label == "gap":
            tp = g[y & g["pred_gap"].to_numpy(bool)]
            out[model]["lead_days_median"] = float(tp["gap_first_day"].median()) if len(tp) else float("nan")
            out[model]["date_error_days_median"] = (float((tp["pred_first_day"] - tp["gap_first_day"]).abs().median())
                                                    if len(tp) else float("nan"))
    return out


def run_control(ds: Dataset, quick: bool = False, model_names: list[str] | None = None,
                on_step=None, progress=None, max_backtest_companies: int = 150,
                as_of: str | None = None) -> tuple[dict, pd.DataFrame, pd.DataFrame]:
    """Returns (summary, backtest rows, daily forecasts).
    as_of: forecast from this date instead of the end of the data, and check it against what follows it."""
    steps = list(ds.steps)
    t0 = time.time()
    no_balance = bool(ds.load and ds.load.balance_reconstructed)
    when = check_as_of(ds, as_of)

    def step(title: str, **details):
        rec = dict(n=len(steps) + 1, title=title, seconds=round(time.time() - t0, 2), details=details)
        steps.append(rec)
        log.info("step %d. %s %s", rec["n"], title, details)
        if on_step:
            on_step(rec)

    calibrators = load_calibrators()
    calibrator = calibrators.get(MAIN_MODEL) or calibrators.get("M6_hybrid")

    # 6. regular payments at the last date of every company
    slots_by_cat: dict[str, int] = {}
    total_slots = 0
    by_company = {c: g for c, g in ds.ops.groupby("company_id")}
    for cid, cs in ds.series.items():
        cut = cs.last_date if when is None else min(when, cs.last_date)
        for sl in detect(by_company[cid], cut):
            slots_by_cat[sl.category_name] = slots_by_cat.get(sl.category_name, 0) + 1
            total_slots += 1
    step("Поиск регулярных платежей", regular_series=total_slots,
         by_category=dict(sorted(slots_by_cat.items(), key=lambda kv: -kv[1])))

    # 7. forecast at the last date of every company (or at as_of): M6 on the statement alone, with the
    # packaged LightGBM; at a past as_of LightGBM is trained on this dataset up to that date
    from cashradar.embed import load_gbm
    from cashradar.forecast.hybrid import HybridForecaster

    if when is None:
        gbm = load_gbm()
    else:
        gbm = GlobalGBM(features=FLOW_FEATURES)
        gbm.fit(ds.series, when, HORIZON)
        gbm = gbm if gbm.model is not None else None
    model = (HybridForecaster(ds.ops, gbm=gbm, point_in_time=True) if gbm is not None
             else StructuralWithInvoices(ds.ops, point_in_time=True))
    forecasts, daily = [], []
    for cid, cs in ds.series.items():
        cut = cs.last_date if when is None else min(when, cs.last_date)
        if (cut - cs.first_date).days + 1 < 15:
            continue
        sim = model.simulate(cs, cut, HORIZON)
        risk = assess(sim, 0.0, calibrator)
        q = sim.quantiles()
        row = dict(company_id=cid, as_of=f"{cut:%Y-%m-%d}", balance_now=round(sim.bal_now, 2),
                   p50_d7=round(q["p50"].iloc[6], 2), p50_d30=round(q["p50"].iloc[-1], 2),
                   min_p50=round(q["p50"].min(), 2), level=risk.level, probability=round(risk.p_gap, 3),
                   risk_date=None if risk.risk_date is None else f"{risk.risk_date:%Y-%m-%d}",
                   shortfall=round(risk.shortfall_p50, 2), message=risk.message)
        if cut < cs.last_date:  # what happened after the forecast date is in the data: put it next to the forecast
            t = truth(cs, cut, min(HORIZON, (cs.last_date - cut).days))
            k = len(t["op_path"])
            row.update(fact_days=k, p50_fact_day=round(float(q["p50"].iloc[k - 1]), 2),
                       fact=round(float(t["op_path"][-1]), 2), fact_min=round(float(t["op_path"].min()), 2),
                       fact_gap=bool(t["op_path"].min() < 0))
        forecasts.append(row)
        daily.append(q.assign(company_id=cid, p_below=risk.p_by_day.values).rename_axis("date").reset_index())
    levels = pd.Series([f["level"] for f in forecasts]).value_counts().to_dict()
    step("Прогноз остатка на 30 дней по каждой компании", companies=len(forecasts), by_level=levels,
         as_of="последняя дата выписки каждой компании" if when is None else f"{when:%Y-%m-%d}",
         model=model.title + " (реестр счетов — только то, что видно в выписке на дату)", calibrated=calibrator is not None,
         **({"with_fact": sum("fact" in f for f in forecasts)} if when is not None else {}),
         **({"warning": "остаток не предоставлен: уровни риска считаются от нулевого остатка"} if no_balance else {}))

    # 8. backtest on this very dataset (or one cutoff at as_of)
    cfg = auto_config(ds, quick) if when is None else fixed_config(ds, when)
    rows = pd.DataFrame()
    metrics: dict = {}
    if cfg is None:
        step("Проверка качества (бэктест)",
             skipped="истории меньше 4 недель: не на чем проверить прогноз задним числом" if when is None
             else "до даты прогноза меньше 3 недель истории или после неё меньше 7 дней данных")
    else:
        models = model_zoo(ds, model_names)
        series = ds.series
        sampled = ""
        if len(series) > max_backtest_companies:
            # time budget: the forecast above covers every company, the quality check a fixed random sample
            keep = sorted(np.random.default_rng(0).choice(sorted(series), size=max_backtest_companies, replace=False))
            series = {c: series[c] for c in keep}
            sampled = f"{max_backtest_companies} случайных компаний из {len(ds.series)} (ограничение времени)"
        rows = run_backtest(series, ds.events, models, cfg, progress=progress)
        step("Проверка качества (бэктест)", cutoffs=len(cfg.cutoffs()), first_cutoff=cfg.start, last_cutoff=cfg.end,
             step_days=cfg.step_days, horizon_days=cfg.horizon, min_history_days=cfg.min_history_days,
             windows=int(rows[["company_id", "cutoff"]].drop_duplicates().shape[0]) if len(rows) else 0,
             companies=sampled or len(series), models=[m.name for m in models])
        # 9. metrics
        metrics = dict(balance=balance_metrics(rows), gaps=gap_metrics(rows, "gap", calibrators),
                       stress_events=gap_metrics(rows, "event", calibrators)) if len(rows) else {}
        if metrics and no_balance:
            # gaps are about the real balance; with a balance rebuilt from zero they mean nothing
            metrics["gaps"], metrics["stress_events"] = {}, {}
            metrics["note"] = ("В данных нет остатка на счёте: метрики разрывов не считаются, "
                               "точность прогноза дана для изменения остатка относительно даты прогноза.")
        main = (metrics.get("gaps") or {}).get(MAIN_MODEL, {})
        bal = (metrics.get("balance") or {}).get(MAIN_MODEL, {})
        step("Метрики качества", main_model=MAIN_MODEL,
             gap_accuracy=round(main.get("accuracy", float("nan")), 3),
             gap_precision=round(main.get("precision", float("nan")), 3),
             gap_recall=round(main.get("recall", float("nan")), 3), gap_f1=round(main.get("f1", float("nan")), 3),
             balance_mae_rub=round(bal.get("mae_rub", float("nan"))),
             nmae_median=round(bal.get("nmae_median", float("nan")), 3),
             win_rate_vs_naive=round(bal.get("win_rate_vs_naive", float("nan")), 3))

    summary = dict(steps=steps, forecasts=forecasts, metrics=metrics,
                   config=None if cfg is None else cfg.__dict__, main_model=MAIN_MODEL,
                   model_titles=MODEL_TITLES, as_of=None if when is None else f"{when:%Y-%m-%d}",
                   definitions=DEFINITIONS)
    daily_df = pd.concat(daily, ignore_index=True) if daily else pd.DataFrame()
    return summary, rows, daily_df


DEFINITIONS = {
    "окно": "компания × дата прогноза: модель видит данные только до этой даты и прогнозирует 30 дней вперёд",
    "разрыв (gap)": "операционный остаток (факт минус деньги владельца и кредиты после даты прогноза) "
                    "опускается ниже 0 в течение 30 дней; окна с отрицательным остатком на дату прогноза не считаются",
    "следы нехватки (stress_events)": "скрытый разрыв (владелец внёс деньги, без них был бы минус), овердрафт, "
                                       "задержка зарплаты с компенсацией, взыскание налоговой или исполнительный лист",
    "MAE/MSE/RMSE, ₽": "ошибка медианного прогноза остатка относительно операционного остатка, усреднённая по дням "
                       "горизонта и по окнам",
    "nMAE": "MAE в «средних дневных оборотах» компании — сравнимо между малыми и крупными компаниями",
    "coverage80": "доля дней, когда факт попал в диапазон 80% сценариев (цель — 0.8)",
    "только выписка / реестр счетов": "основная модель видит на дату прогноза только операции до неё. Вариант "
                                      "«+ реестр счетов» восстанавливает реестр по всей выписке, как если бы была "
                                      "подключена 1С: знает счета, которые оплатят позже, — показывает вклад "
                                      "этого источника, но не является прогнозом по одной выписке",
    "Brier": "средний квадрат ошибки вероятности (0 — идеально; у «всегда средней частоты» ≈ p·(1−p))",
}


def write_report(summary: dict, rows: pd.DataFrame, daily: pd.DataFrame, out: Path) -> Path:
    import json

    out.mkdir(parents=True, exist_ok=True)
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    if not rows.empty:
        rows.to_csv(out / "backtest_rows.csv.gz", index=False)
    pd.DataFrame(summary["forecasts"]).to_csv(out / "forecast_by_company.csv", index=False, encoding="utf-8-sig")
    if not daily.empty:
        daily.to_csv(out / "forecast_daily.csv", index=False, encoding="utf-8-sig")
    (out / "report.md").write_text(render_markdown(summary), encoding="utf-8")
    return out / "report.md"


def _fmt(v, kind="num"):
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return "—"
    if kind == "rub":
        return f"{v:,.0f}".replace(",", " ")
    if kind == "pct":
        return f"{v:.1%}"
    return f"{v:.3f}" if isinstance(v, float) else str(v)


def render_markdown(summary: dict) -> str:
    lines = ["# Контрольный прогон «Кассового радара»", ""]
    titles = summary.get("model_titles") or {}
    lines += ["## Пошаговый лог", ""]
    for st in summary["steps"]:
        lines.append(f"**{st['n']}. {st['title']}** ({st['seconds']} с)")
        for k, v in st["details"].items():
            lines.append(f"- {k}: {v}")
        lines.append("")
    m = summary.get("metrics") or {}
    if m:
        horizon = (summary.get("config") or {}).get("horizon", 30)
        if m.get("note"):
            lines += [f"> {m['note']}", ""]
        lines += [f"## Точность прогноза остатка ({horizon} дней)", "",
                  "| Модель | окон | MAE, ₽ | RMSE, ₽ | MSE, ₽² | медиана MAE, ₽ | nMAE (медиана) | nMAE (среднее) | "
                  "лучше naive, доля окон | покрытие 80% |",
                  "|---|---|---|---|---|---|---|---|---|---|"]
        for name, b in sorted(m["balance"].items(), key=lambda kv: kv[1]["nmae_median"]):
            lines.append(f"| {titles.get(name, name)} | {b['windows']} | {_fmt(b['mae_rub'], 'rub')} | {_fmt(b['rmse_rub'], 'rub')} | "
                         f"{b['mse_rub']:.3e} | {_fmt(b['median_ae_rub'], 'rub')} | {b['nmae_median']:.2f} | "
                         f"{b['nmae_mean']:.2f} | {_fmt(b.get('win_rate_vs_naive'), 'pct')} | {_fmt(b.get('coverage80'), 'pct')} |")
        lines += ["", "MAE/MSE в рублях усредняют все окна, и их почти целиком определяют несколько крупнейших "
                      "компаний; nMAE (ошибка в средних дневных оборотах самой компании) и доля окон, где модель "
                      "точнее naive, показывают качество для типичной компании.", ""]
        for key, title in (("gaps", "Выявление кассовых разрывов"), ("stress_events", "Совпадение со следами нехватки денег")):
            if not m.get(key):
                continue
            lines += ["", f"## {title}", "",
                      "| Модель / правило | Accuracy | Precision | Recall | F1 | ROC-AUC | PR-AUC | Brier | TP | FP | FN | TN |",
                      "|---|---|---|---|---|---|---|---|---|---|---|---|"]
            for name, g in m[key].items():
                c = g["confusion"]
                lines.append(f"| {titles.get(name, name)} ({g['rule']}) | {_fmt(g['accuracy'])} | {_fmt(g['precision'])} | "
                             f"{_fmt(g['recall'])} | {_fmt(g['f1'])} | {_fmt(g.get('roc_auc'))} | {_fmt(g.get('pr_auc'))} | "
                             f"{_fmt(g.get('brier'))} | {c['tp']} | {c['fp']} | {c['fn']} | {c['tn']} |")
        main = (m.get("gaps") or {}).get(summary["main_model"])
        if main:
            c = main["confusion"]
            lines += ["", f"### Матрица ошибок: {titles.get(summary['main_model'], summary['main_model'])} ({main['rule']})", "",
                      "| | прогноз: разрыв | прогноз: нет |", "|---|---|---|",
                      f"| **факт: разрыв** | {c['tp']} (верно) | {c['fn']} (пропуск) |",
                      f"| **факт: нет** | {c['fp']} (ложная тревога) | {c['tn']} (верно) |", "",
                      f"Заблаговременность (медиана): {_fmt(main.get('lead_days_median'))} дн.; "
                      f"ошибка даты (медиана): {_fmt(main.get('date_error_days_median'))} дн."]
    with_fact = any("fact" in f for f in summary["forecasts"])
    when = f"на {summary['as_of']}" if summary.get("as_of") else "на последнюю дату выписки"
    lines += ["", f"## Прогноз по компаниям ({when})", "",
              "| Компания | дата | остаток | медиана через 30 дн. | уровень | вероятность | дата риска | нехватка |"
              + (" факт: дней | прогноз на этот день | факт | минимум факта |" if with_fact else ""),
              "|---|---|---|---|---|---|---|---|" + ("---|---|---|---|" if with_fact else "")]
    for f in sorted(summary["forecasts"], key=lambda f: -f["probability"]):
        line = (f"| {f['company_id']} | {f['as_of']} | {_fmt(f['balance_now'], 'rub')} | {_fmt(f['p50_d30'], 'rub')} | "
                f"{f['level']} | {f['probability']:.0%} | {f['risk_date'] or '—'} | {_fmt(f['shortfall'], 'rub')} |")
        if with_fact:
            line += (f" {f.get('fact_days', '—')} | {_fmt(f.get('p50_fact_day'), 'rub')} | {_fmt(f.get('fact'), 'rub')} | "
                     f"{_fmt(f.get('fact_min'), 'rub')} |")
        lines.append(line)
    lines += ["", "## Определения", ""] + [f"- **{k}** — {v}" for k, v in summary["definitions"].items()]
    return "\n".join(lines) + "\n"
