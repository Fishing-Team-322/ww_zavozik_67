"""«What if» scenarios: presets from the case and helpers to build them.

The scenario itself is applied inside the simulation (app.forecast.structural), on the
same random paths as the base forecast, so base vs scenario differ only by the scenario.
"""
from dataclasses import dataclass

import pandas as pd

from cashradar.categorize.engine import counterparty_key
from cashradar.domain import schema as s
from cashradar.domain.scenario import ExtraEvent, Scenario

CUSTOMER_CATEGORIES = {"in.customer_payment", "in.customer_prepayment", "in.marketplace"}


@dataclass(frozen=True)
class Preset:
    id: str
    title: str
    description: str
    params: dict


PRESETS = [
    Preset("client_late", "Крупный клиент платит на 3 недели позже",
           "Самый крупный клиент за полгода задерживает оплату на 21 день", {"client_delay_days": 21, "client": "top"}),
    Preset("revenue_drop", "Выручка −20%", "Сезонный спад или потеря клиента: новые продажи на 20% ниже",
           {"revenue_change_pct": -20}),
    Preset("unplanned", "Внеплановый расход", "Ремонт оборудования, штраф или доначисление налога через 10 дней",
           {"one_off_amount": 500_000, "one_off_in_days": 10}),
    Preset("costs_up", "Аренда и закупки +15%", "Рост постоянных расходов и закупочных цен на 15%",
           {"fixed_cost_change_pct": 15, "purchase_change_pct": 15}),
]


def top_clients(ops: pd.DataFrame, company: str, cutoff: pd.Timestamp, days: int = 180, k: int = 8) -> list[dict]:
    """Largest customers by money received in the trailing window."""
    o = ops[(ops[s.COMPANY] == company) & (ops[s.SIGN] > 0) & ops["category"].isin(CUSTOMER_CATEGORIES)
            & (ops[s.DATE] <= cutoff) & (ops[s.DATE] > cutoff - pd.Timedelta(days=days))]
    if o.empty:
        return []
    o = o.assign(cp=counterparty_key(o))
    total = o[s.AMOUNT].sum()
    g = o.groupby("cp").agg(name=(s.CP_NAME, "last"), amount=(s.AMOUNT, "sum"), payments=(s.AMOUNT, "size"))
    g = g.sort_values("amount", ascending=False).head(k)
    # r["name"], not r.name: the latter is the row label (the counterparty key)
    return [dict(client=cp, name=r["name"], share=round(r["amount"] / total, 3), payments=int(r["payments"]))
            for cp, r in g.iterrows()]


def build_scenario(cutoff: pd.Timestamp, *, revenue_change_pct: float = 0, fixed_cost_change_pct: float = 0,
                   purchase_change_pct: float = 0, client_delay_days: int = 0, client: str | None = None,
                   one_off_amount: float = 0, one_off_in_days: int = 10, one_off_label: str = "",
                   clients: list[dict] | None = None) -> Scenario:
    """Translate UI parameters (percent changes, «top» client) into a Scenario."""
    if client == "top":
        if not clients:  # no customers to delay: do not silently delay everybody
            client_delay_days = 0
        client = clients[0]["client"] if clients else None
    extra = ()
    if one_off_amount:
        extra = (ExtraEvent(cutoff + pd.Timedelta(days=int(one_off_in_days)), -abs(float(one_off_amount)),
                            one_off_label or "Внеплановый расход (сценарий)", source="scenario"),)
    return Scenario(
        revenue_factor=1 + revenue_change_pct / 100,
        fixed_cost_factor=1 + fixed_cost_change_pct / 100,
        purchase_factor=1 + purchase_change_pct / 100,
        client_delay_days=int(client_delay_days),
        client=client or None,
        extra=extra,
    )
