"""Daily calendar series per company — the common input of all forecast models.

Columns (index = calendar date, every day from the first to the last operation):
    bal         end-of-day balance (carried over days without operations)
    net         net flow of all operations
    net_fin     net flow of financing operations (owner money, credits, transfers between own accounts)
    net_op      operating net flow = net - net_fin  (what the forecast predicts)
    inflow_op   operating inflows
    outflow_op  operating outflows (positive numbers)
    adj         unexplained balance change: missing data in the export
    has_ops     the day has at least one operation
    missing     the day falls into a gap of the export (flows unknown)

Invariant: bal[d] = bal[d-1] + net[d] + adj[d].
"""
from dataclasses import dataclass

import numpy as np
import pandas as pd

from cashradar.domain import schema as s


@dataclass
class CompanySeries:
    company_id: str
    industry: str
    frame: pd.DataFrame

    @property
    def first_date(self) -> pd.Timestamp:
        return self.frame.index[0]

    @property
    def last_date(self) -> pd.Timestamp:
        return self.frame.index[-1]

    def history(self, cutoff: pd.Timestamp) -> pd.DataFrame:
        """Everything known at the end of `cutoff` day."""
        return self.frame.loc[:cutoff]


def build_series(ops: pd.DataFrame, days: pd.DataFrame, industries: dict[str, str] | None = None) -> dict[str, CompanySeries]:
    """ops: categorized and cleaned operations; days: CleanResult.days."""
    industries = industries or {}
    fin = ops["is_financing"].to_numpy()
    sign = ops[s.SIGN].to_numpy()
    amount = ops[s.AMOUNT].to_numpy()
    flows = pd.DataFrame({
        s.COMPANY: ops[s.COMPANY].to_numpy(),
        s.DATE: ops[s.DATE].to_numpy(),
        "net": ops[s.SIGNED].to_numpy(),
        "net_fin": np.where(fin, ops[s.SIGNED].to_numpy(), 0.0),
        "inflow_op": np.where(~fin & (sign > 0), amount, 0.0),
        "outflow_op": np.where(~fin & (sign < 0), amount, 0.0),
    }).groupby([s.COMPANY, s.DATE]).sum()

    result = {}
    days_by_company = dict(tuple(days.groupby(s.COMPANY)))
    for company, f in flows.groupby(level=0):
        f = f.droplevel(0)
        d = days_by_company[company].set_index(s.DATE)
        idx = pd.date_range(f.index.min(), f.index.max(), freq="D")
        frame = f.reindex(idx, fill_value=0.0)
        frame["net_op"] = frame["net"] - frame["net_fin"]
        frame["adj"] = d["adjustment"].reindex(idx, fill_value=0.0)
        frame["bal"] = d["bal_eod"].reindex(idx).ffill()
        frame["has_ops"] = frame.index.isin(d.index)
        # days inside an export gap: between the previous operating day and a day whose balance did not reconcile
        missing = np.zeros(len(idx), dtype=bool)
        op_days = d.index.to_numpy()
        for k in np.flatnonzero(d["adjustment"].to_numpy() != 0):
            if k > 0:
                missing[(idx > op_days[k - 1]) & (idx < op_days[k])] = True
        frame["missing"] = missing
        result[company] = CompanySeries(company, industries.get(company, ""), frame)
    return result


def opening_balance(series: CompanySeries) -> float:
    f = series.frame
    return float(f["bal"].iloc[0] - f["net"].iloc[0] - f["adj"].iloc[0])
