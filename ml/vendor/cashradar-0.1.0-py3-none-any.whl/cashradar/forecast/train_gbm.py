"""CLI: train the LightGBM part of the hybrid (M6) and save it as an artifact.

    uv run python -m cashradar.forecast.train_gbm [--data ../data/raw] [--until 2026-09-30]
                  [--exclude C003,C013,...] [--out cashradar/artifacts/m6_gbm]

The flows are the team's «business» scope (own transfers and founder loans excluded, credits
included), the same scope the embedding API receives. `--exclude` keeps companies out of training,
e.g. the team's audit companies, so that a benchmark on them stays out-of-sample.
"""
import argparse
from pathlib import Path

import pandas as pd

from cashradar.core.config import DATA_DIR
from cashradar.forecast.baselines import FLOW_FEATURES, GlobalGBM
from cashradar.forecast.series import build_series
from cashradar.pipeline import prepare

ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts" / "m6_gbm"
TEAM_INTERNAL_RE = r"займ.*учредител|учредител.*займ|собственн\S* средств"


def business_series(ds):
    """Daily series where «financing» = the team's internal movements of the owner only."""
    ops = ds.ops.copy()
    ops["is_financing"] = ops["payment_purpose"].str.lower().str.contains(TEAM_INTERNAL_RE, regex=True).to_numpy()
    return ops, build_series(ops, ds.days, dict(zip(ds.companies["company_id"], ds.companies["industry"])))


def train(ds, until: pd.Timestamp, exclude: set[str] = frozenset(), horizon: int = 30) -> GlobalGBM:
    _, series = business_series(ds)
    gbm = GlobalGBM(features=FLOW_FEATURES)
    gbm.fit({c: s for c, s in series.items() if c not in exclude}, until, horizon)
    return gbm


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=str(DATA_DIR))
    ap.add_argument("--until", default=None, help="last target date used for training (default: end of data)")
    ap.add_argument("--exclude", default="", help="company ids to keep out of training, comma-separated")
    ap.add_argument("--out", default=str(ARTIFACT_DIR))
    args = ap.parse_args()
    ds = prepare(args.data)
    until = pd.Timestamp(args.until) if args.until else max(cs.last_date for cs in ds.series.values())
    gbm = train(ds, until, {c for c in args.exclude.split(",") if c})
    gbm.save(args.out)
    print(f"saved to {args.out}: {gbm.n_train_rows} training rows, targets up to {until:%Y-%m-%d}")


if __name__ == "__main__":
    main()
