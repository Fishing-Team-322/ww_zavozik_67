"""Structural cash-flow model with Monte Carlo simulation (M4, M5).

    B(t) = B(T) + Σ regular obligations          (recurring detector: date + amount ± noise)
                + Σ open invoices                  (M5 only: payment date from the invoice-age Markov model)
                + Σ new invoices issued after T    (M5 only: Poisson issuance × payment lag)
                + flow of everything else          (block bootstrap of recent weeks, aligned by weekday,
                                                    scaled by last year's seasonality)
                + Σ events entered by the owner    (known amounts and dates)
Financing (owner money, credits, transfers between own accounts) is not forecast:
the model answers «what happens if nobody adds money».

Each simulation path is one plausible future; the spread of paths gives the
probability of a gap, its date and the size of the shortfall. A «what if» scenario
re-runs the same paths with adverse changes applied (see app.domain.scenario).
"""
import zlib
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from cashradar.domain import schema as s
from cashradar.domain.scenario import BASE, ExtraEvent, Scenario
from cashradar.forecast.baselines import Forecaster, future_dates
from cashradar.forecast.series import CompanySeries
from cashradar.recurring.detector import RecurringSlot, detect, schedule
from cashradar.sources.calendar import business_shift_index
from cashradar.sources.invoices import InvoiceBook

ONE_OFF_CATEGORIES = {"out.capex", "in.subsidy", "in.refund"}
ONE_OFF_MARKER = "разов"
SEASONAL_CLIP = (0.5, 2.0)
SETTLE_DAYS = 60          # invoices older than this are almost all paid, so the registry sees them
MAX_BACKLOG_AGE = 180
FIXED_COST_CATEGORIES = {"out.rent", "out.utilities", "out.services", "out.telecom_software"}
LATE_GRACE_DAYS = 5       # a regular payment is «late» this many days after its expected date
# With little history the expected change of the balance is shrunk towards «no change»: regular payments
# cannot be detected yet and a few weeks of lumpy flows overstate the drift. Linear from 0 at
# MIN_EVIDENCE_DAYS to 1 at FULL_EVIDENCE_DAYS (the backtests start at 90 days, so they are unaffected).
MIN_EVIDENCE_DAYS = 28
FULL_EVIDENCE_DAYS = 90

EVENT_COLUMNS = ["date", "amount", "sigma", "slot", "category", "label", "kind", "overdue", "probability",
                 "cp_key", "doc_no", "date_late", "typical_lag", "age", "event_id"]


@dataclass
class Simulation:
    company_id: str
    cutoff: pd.Timestamp
    dates: pd.DatetimeIndex
    bal_now: float
    paths: np.ndarray                       # (n_paths, horizon) daily operating net flow
    events: pd.DataFrame                    # known future events for explanations and plan-vs-fact
    stream_mean: np.ndarray                 # expected daily flow of the bootstrapped remainder
    inflow_mean: np.ndarray                 # expected daily inflows (outflows = inflow_mean - paths.mean)
    slots: list[RecurringSlot] = field(default_factory=list)
    seasonal: tuple[float, float] = (1.0, 1.0)
    scenario: Scenario = BASE
    # gross flows per path, both >= 0, inflow_paths - outflow_paths == paths (for services that need them apart)
    inflow_paths: np.ndarray | None = None
    outflow_paths: np.ndarray | None = None

    def balance_paths(self) -> np.ndarray:
        return self.bal_now + np.cumsum(self.paths, axis=1)

    def quantiles(self, qs=(0.1, 0.5, 0.9)) -> pd.DataFrame:
        b = self.balance_paths()
        return pd.DataFrame({f"p{int(q * 100)}": np.quantile(b, q, axis=0) for q in qs}, index=self.dates)


def nonnegative(inflow: np.ndarray, outflow: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Widening the spread can push a gross flow below zero on some paths. Move the negative part to the
    opposite flow: the net flow (and hence the balance) stays exactly the same, both flows become >= 0."""
    inflow, outflow = inflow.copy(), outflow.copy()
    neg_in = np.minimum(inflow, 0.0)
    inflow -= neg_in
    outflow -= neg_in
    neg_out = np.minimum(outflow, 0.0)
    outflow -= neg_out
    inflow -= neg_out
    return inflow, outflow


class StructuralForecaster(Forecaster):
    name, title = "M4_structural", "Структурная + Монте-Карло (только выписка)"

    _slot_cache: dict[tuple[str, pd.Timestamp], list[RecurringSlot]] = {}

    def __init__(self, ops: pd.DataFrame, n_paths: int = 1000, pool_weeks: int = 12,
                 seasonal: bool = True, seed: int = 0, name: str | None = None, spread: float = 1.5,
                 point_in_time: bool = False):
        if name:
            self.name = name
        # True: at a past cutoff the invoice registry knows only what the statement showed by then
        # (no accounting system). False: the full registry stands in for one (see sources/invoices.py).
        self.point_in_time = point_in_time
        self.spread = spread  # scales path deviations from the mean path: calibrates interval width
        self.ops_by_company = {c: g for c, g in ops.groupby(s.COMPANY)}
        self.n_paths = n_paths
        self.pool_weeks = pool_weeks
        self.seasonal = seasonal
        self.seed = seed
        self.book: InvoiceBook | None = None

    # -- Forecaster interface ------------------------------------------------
    def predict(self, cs, cutoff, horizon):
        return self.simulate(cs, cutoff, horizon).paths.mean(axis=0)

    def predict_paths(self, cs, cutoff, horizon) -> np.ndarray:
        return self.simulate(cs, cutoff, horizon).paths

    # -- simulation ----------------------------------------------------------
    def _rng(self, company: str, cutoff: pd.Timestamp) -> np.random.Generator:
        return np.random.default_rng(zlib.crc32(f"{company}|{cutoff.date()}|{self.seed}".encode()))

    def _book_at(self, cutoff: pd.Timestamp) -> InvoiceBook | None:
        if self.book is None or not self.point_in_time:
            return self.book
        return self.book.as_of(cutoff)

    def _slots(self, company: str, ops: pd.DataFrame, cutoff: pd.Timestamp) -> list[RecurringSlot]:
        key = (company, cutoff)
        if key not in self._slot_cache:
            self._slot_cache[key] = detect(ops, cutoff)
        return self._slot_cache[key]

    def _excluded_from_pool(self, hist: pd.DataFrame, recurring_idx: set) -> np.ndarray:
        return (hist["is_financing"].to_numpy()
                | hist.index.isin(list(recurring_idx))
                | hist["category"].isin(ONE_OFF_CATEGORIES).to_numpy()
                | hist[s.PURPOSE].str.lower().str.contains(ONE_OFF_MARKER).to_numpy())

    def simulate(self, cs: CompanySeries, cutoff: pd.Timestamp, horizon: int,
                 scenario: Scenario = BASE, extra_events: tuple[ExtraEvent, ...] = ()) -> Simulation:
        """Random draws do not depend on the scenario (common random numbers), so the
        difference between a scenario and the base forecast is the scenario's effect, not noise."""
        company = cs.company_id
        rng = self._rng(company, cutoff)
        n, H = self.n_paths, horizon
        dates = future_dates(cutoff, H)
        f = cs.frame
        bal_now = float(f.at[cutoff, "bal"])
        ops = self.ops_by_company.get(company, pd.DataFrame(columns=[s.DATE]))
        ops = ops[ops[s.DATE] <= cutoff]
        book = self._book_at(cutoff)

        # -- regular obligations ---------------------------------------------
        slots = self._slots(company, ops, cutoff)
        recurring_idx = {i for sl in slots for i in sl.op_index}
        rec = schedule(slots, cutoff, H)
        inflow_p = np.zeros((n, H))   # gross inflows per path and day
        outflow_p = np.zeros((n, H))  # gross outflows per path and day
        if not rec.empty:
            factor = np.where(rec["category"].isin(FIXED_COST_CATEGORIES), scenario.fixed_cost_factor, 1.0)
            rec = rec.assign(amount=rec["amount"] * factor, sigma=rec["sigma"] * factor)
            pos = (rec["date"] - dates[0]).dt.days.to_numpy()
            amt = np.abs(rec["amount"].to_numpy())
            draws = np.maximum(rng.normal(amt, rec["sigma"].to_numpy(), size=(n, len(rec))), 0.0)
            for j in range(len(rec)):
                outflow_p[:, pos[j]] += draws[:, j]
        events = rec.assign(probability=1.0, date_late=rec["date"] + pd.Timedelta(days=LATE_GRACE_DAYS))

        # -- remainder: block bootstrap of recent weeks -----------------------
        pool_days = 7 * self.pool_weeks
        start = cutoff - pd.Timedelta(days=pool_days - 1)
        hist = ops[ops[s.DATE] >= start]
        keep = ~self._excluded_from_pool(hist, recurring_idx)
        if book is not None:
            keep &= ~hist.index.isin(list(book.linked_op_index))
        hist = hist[keep]
        day = (hist[s.DATE] - start).dt.days.to_numpy()
        pool_in = np.bincount(day, weights=np.where(hist[s.SIGN] > 0, hist[s.AMOUNT], 0.0), minlength=pool_days)
        pool_out = np.bincount(day, weights=np.where(hist[s.SIGN] < 0, hist[s.AMOUNT], 0.0), minlength=pool_days)
        win = f.loc[start:cutoff]
        valid_weeks = [k for k in range(self.pool_weeks)
                       if start + pd.Timedelta(days=7 * k) >= cs.first_date
                       and not win["missing"].iloc[7 * k:7 * k + 7].any()]
        seas = self._seasonal_factors(f, cutoff, H, pool_days) if self.seasonal else (1.0, 1.0)
        stream_mean = np.zeros(H)
        if valid_weeks:
            week_in = pool_in.reshape(-1, 7) * seas[0] * scenario.revenue_factor
            week_out = pool_out.reshape(-1, 7) * seas[1] * scenario.purchase_factor
            n_blocks = -(-H // 7)
            pick = rng.choice(valid_weeks, size=(n, n_blocks))
            inflow_p += week_in[pick].reshape(n, n_blocks * 7)[:, :H]
            outflow_p += week_out[pick].reshape(n, n_blocks * 7)[:, :H]
            stream_mean = np.tile((week_in - week_out)[valid_weeks].mean(axis=0), n_blocks)[:H]

        if book is not None:
            inv_in, inv_out, inv_events = self._invoices(company, cutoff, dates, rng, scenario, book)
            inflow_p += inv_in
            outflow_p += inv_out
            events = pd.concat([events, inv_events], ignore_index=True)

        if self.spread != 1.0:
            # widen the uncertainty around the mean path (calibrated on the backtest). Scaling daily
            # deviations scales the cumulative ones by the same factor: the balance spread is what is calibrated.
            for m in (inflow_p, outflow_p):
                mu = m.mean(axis=0)
                m -= mu
                m *= self.spread
                m += mu

        # -- owner's events and scenario one-offs: known for sure, added after the noise ----
        extra_rows = []
        for ev in (*extra_events, *scenario.extra):
            pos = (pd.Timestamp(ev.date) - dates[0]).days
            if not 0 <= pos < H:
                continue
            if ev.amount > 0:
                inflow_p[:, pos] += ev.amount
            else:
                outflow_p[:, pos] -= ev.amount
            extra_rows.append(dict(date=pd.Timestamp(ev.date), amount=ev.amount, sigma=0.0, slot=-1,
                                   category="manual_in" if ev.amount > 0 else "manual_out", label=ev.label,
                                   kind=ev.source, overdue=False, probability=1.0, event_id=ev.id,
                                   date_late=pd.Timestamp(ev.date) + pd.Timedelta(days=LATE_GRACE_DAYS)))
        if extra_rows:
            events = pd.concat([events, pd.DataFrame(extra_rows)], ignore_index=True)

        events = events.reindex(columns=EVENT_COLUMNS).sort_values("date", kind="stable").reset_index(drop=True)
        history_days = (cutoff - cs.first_date).days + 1
        if history_days < FULL_EVIDENCE_DAYS:
            # shrink the net flow by alpha, keeping both gross flows >= 0 (the change is added to one side)
            alpha = float(np.clip((history_days - MIN_EVIDENCE_DAYS) / (FULL_EVIDENCE_DAYS - MIN_EVIDENCE_DAYS), 0, 1))
            delta = -(1 - alpha) * (inflow_p - outflow_p)
            inflow_p += np.maximum(delta, 0.0)
            outflow_p += np.maximum(-delta, 0.0)
        paths = inflow_p - outflow_p
        inflow_mean = inflow_p.mean(axis=0)
        gross_in, gross_out = nonnegative(inflow_p, outflow_p)
        return Simulation(company, cutoff, dates, bal_now, paths, events, stream_mean, inflow_mean, slots, seas,
                          scenario, gross_in, gross_out)

    def _seasonal_factors(self, f: pd.DataFrame, cutoff: pd.Timestamp, H: int, pool_days: int) -> tuple[float, float]:
        """Last year's (future window / pool window) ratio of operating inflows and outflows."""
        year = pd.Timedelta(days=364)  # 52 weeks keeps weekdays aligned
        fut = f.loc[cutoff + pd.Timedelta(days=1) - year: cutoff + pd.Timedelta(days=H) - year]
        past = f.loc[cutoff - pd.Timedelta(days=pool_days - 1) - year: cutoff - year]
        if len(past) < pool_days or len(fut) < H or past["missing"].any() or fut["missing"].any():
            return 1.0, 1.0
        out = []
        for col in ("inflow_op", "outflow_op"):
            a, b = fut[col].mean(), past[col].mean()
            out.append(float(np.clip(a / b, *SEASONAL_CLIP)) if b > 0 else 1.0)
        return out[0], out[1]

    def _invoices(self, company: str, cutoff: pd.Timestamp, dates: pd.DatetimeIndex, rng: np.random.Generator,
                  scenario: Scenario, book: InvoiceBook) -> tuple[np.ndarray, np.ndarray, pd.DataFrame]:
        """Returns (gross inflow paths, gross outflow paths, events)."""
        n, H = self.n_paths, len(dates)
        ext = pd.date_range(dates[0], periods=H + 7, freq="D")  # lets payments on weekends at the end shift
        shift = np.array([p if p is not None and p < H else -1 for p in business_shift_index(ext)] + [-1])
        paths = np.zeros((n, H))
        inflow = np.zeros((n, H))
        lm = book.lag_model(company, cutoff)
        rows = []

        def book_payments(path_idx: np.ndarray, day_offset: np.ndarray, amount: np.ndarray) -> None:
            ok = (day_offset >= 1) & (day_offset <= H + 7)
            target = shift[np.where(ok, day_offset - 1, H + 7)]
            hit = target >= 0
            np.add.at(paths, (path_idx[hit], target[hit]), amount[hit])
            pos = hit & (amount > 0)
            np.add.at(inflow, (path_idx[pos], target[pos]), amount[pos])

        for inv in book.open_at(company, cutoff):
            age = (cutoff - inv.doc_date).days
            offs = lm.sample_remaining(rng, inv.cp, inv.sign, age, n)
            if inv.sign > 0:
                offs = offs + scenario.delays(inv.cp)
            book_payments(np.arange(n), offs, np.full(n, inv.sign * inv.open_amount))
            p_in = float((offs <= H).mean())
            if p_in > 0:
                rows.append(dict(date=cutoff + pd.Timedelta(days=int(np.median(offs))), amount=inv.sign * inv.open_amount,
                                 sigma=0.0, slot=-1, category="invoice_in" if inv.sign > 0 else "invoice_out",
                                 label=f"{'Счёт клиенту' if inv.sign > 0 else 'Счёт поставщика'} № {inv.doc_no} "
                                       f"от {inv.doc_date:%d.%m.%Y}: {inv.cp_name}",
                                 kind="invoice", overdue=False, probability=p_in, cp_key=inv.cp, doc_no=inv.doc_no,
                                 # late = later than in 80% of this client's history
                                 date_late=cutoff + pd.Timedelta(days=int(np.quantile(offs, 0.8))),
                                 typical_lag=lm.typical_lag(inv.cp, inv.sign), age=age))

        # Scenario «client X pays later» for invoices whose client is not known yet (new ones and the
        # backlog): delay the client's share of them. A separate generator keeps base draws untouched.
        srng = np.random.default_rng(zlib.crc32(f"{company}|{cutoff.date()}|{self.seed}|scenario".encode()))
        client_share = self._client_share(book, company, cutoff, scenario.client) if scenario.client else 1.0

        def scenario_delay(sign: int, total: int):
            if sign < 0 or scenario.client_delay_days <= 0:
                return 0
            if scenario.client is None:
                return scenario.client_delay_days
            return np.where(srng.random(total) < client_share, scenario.client_delay_days, 0)

        # Payments the registry cannot show: it is rebuilt from statement payments, so it only knows
        # invoices paid by `known_until`. `gap` = how many days after the cutoff it still sees.
        gap = (book.known_until - cutoff).days
        # issuance rate from a window whose invoices have had time to be paid (and thus be visible)
        rate_end = min(cutoff, book.known_until - pd.Timedelta(days=SETTLE_DAYS))
        for sign in (1, -1):
            amounts = book.issued_recent(company, rate_end, sign)
            lags = np.sort(lm.pool(None, sign, 0))
            if amounts.size == 0 or lags.size == 0:
                continue
            lam_day = amounts.size / 91
            # new sales shrink with revenue; new supplier bills follow purchase prices
            volume = scenario.revenue_factor if sign > 0 else scenario.purchase_factor

            # new invoices issued after the cutoff (Poisson issuance × payment lag)
            counts = rng.poisson(lam_day * H, size=n)
            total = int(counts.sum())
            if total:
                path_idx = np.repeat(np.arange(n), counts)
                issue = rng.integers(1, H + 1, size=total)
                book_payments(path_idx, issue + rng.choice(lags, size=total) + scenario_delay(sign, total),
                              sign * volume * rng.choice(amounts, size=total))

            # backlog: invoices issued before the cutoff and still unpaid after `known_until`.
            # Renewal process: an invoice of age a is unpaid at a+gap with probability S(a+gap).
            if gap < H:
                ages = np.arange(MAX_BACKLOG_AGE)
                lo = np.searchsorted(lags, ages + gap, side="right")
                survival = (lags.size - lo) / lags.size
                counts = rng.poisson(lam_day * survival, size=(n, ages.size))
                total = int(counts.sum())
                if total:
                    path_idx = np.repeat(np.tile(np.arange(n)[:, None], (1, ages.size)).ravel(), counts.ravel())
                    age = np.repeat(np.tile(ages, n), counts.ravel())
                    lag = lags[rng.integers(lo[age], lags.size)]  # lag | lag > age + gap
                    before = paths.sum()
                    book_payments(path_idx, lag - age + scenario_delay(sign, total),
                                  sign * rng.choice(amounts, size=total))
                    expected = (paths.sum() - before) / n
                    if abs(expected) > 0:
                        rows.append(dict(
                            date=cutoff + pd.Timedelta(days=max(gap, 0) + 1), amount=expected, sigma=0.0, slot=-1,
                            category="invoice_in" if sign > 0 else "invoice_out",
                            label=("Оплаты клиентов по ещё не учтённым счетам" if sign > 0
                                   else "Оплаты поставщикам по ещё не учтённым счетам") + " (оценка по истории)",
                            kind="estimate", overdue=False, probability=1.0))
        return inflow, inflow - paths, pd.DataFrame(rows)


    @staticmethod
    def _client_share(book: InvoiceBook, company: str, cutoff: pd.Timestamp, client: str) -> float:
        """Client's share of money received by invoice over the last year."""
        d = book.docs(company)
        d = d[(d["sign"] > 0) & (d["pay_date"] <= cutoff) & (d["pay_date"] > cutoff - pd.Timedelta(days=365))]
        total = d["amount"].sum()
        return float(d.loc[d["cp"] == client, "amount"].sum() / total) if total > 0 else 0.0


class StructuralWithInvoices(StructuralForecaster):
    name, title = "M5_struct_invoices", "Структурная + счета из учётной системы"

    def __init__(self, ops: pd.DataFrame, book: InvoiceBook | None = None, **kw):
        super().__init__(ops, **kw)
        self.book = book or InvoiceBook(ops)
