"""M6: M5 structure + LightGBM level.

M5 knows *what* is going to happen (salary on the 10th, the client's invoice, taxes on the 28th) and how
uncertain it is; LightGBM, trained on all companies, knows the typical *level* of the remaining flow
better. The hybrid keeps M5's paths (dates, lumps, spread, scenarios) and moves their mean towards
a weighted average of both:

    mean_hybrid(h) = w · mean_M5(h) + (1 − w) · LightGBM(h)        for h ≤ the GBM horizon (30 days)
    paths_hybrid   = paths_M5 + (1 − w) · (LightGBM − mean_M5)

Owner-entered events and «what if» scenarios are applied on top at full strength: the shift is
computed from the plain base forecast, so a scenario moves the hybrid exactly as it moves M5.
After the GBM horizon the hybrid is pure M5.
"""
import numpy as np
import pandas as pd

from cashradar.domain.scenario import BASE, ExtraEvent, Scenario
from cashradar.forecast.baselines import FLOW_FEATURES, GlobalGBM
from cashradar.forecast.series import CompanySeries
from cashradar.forecast.structural import Simulation, StructuralWithInvoices

DEFAULT_WEIGHT = 0.6   # weight of M5: chosen on early backtest cutoffs, checked on later ones (reports/backtest/summary.md)


class HybridForecaster(StructuralWithInvoices):
    name, title = "M6_hybrid", "Гибрид: структура M5 + уровень LightGBM"
    needs_training = True

    def __init__(self, ops: pd.DataFrame, gbm: GlobalGBM | None = None, weight: float = DEFAULT_WEIGHT, **kw):
        super().__init__(ops, **kw)
        self.gbm = gbm or GlobalGBM(features=FLOW_FEATURES)
        self.weight = weight

    def fit(self, series, train_end, horizon):
        self.gbm.fit(series, train_end, horizon)

    def simulate(self, cs: CompanySeries, cutoff: pd.Timestamp, horizon: int,
                 scenario: Scenario = BASE, extra_events: tuple[ExtraEvent, ...] = ()) -> Simulation:
        sim = super().simulate(cs, cutoff, horizon, scenario, extra_events)
        if self.gbm.model is None or self.weight >= 1.0:
            return sim
        plain = sim if scenario.is_base and not extra_events else super().simulate(cs, cutoff, horizon)
        h = min(horizon, getattr(self.gbm, "horizon", 30))
        shift = np.zeros(horizon)
        shift[:h] = (1 - self.weight) * (self.gbm.predict(cs, cutoff, h) - plain.paths[:, :h].mean(axis=0))
        sim.paths = sim.paths + shift
        sim.stream_mean = sim.stream_mean + shift
        up, down = np.maximum(shift, 0.0), np.maximum(-shift, 0.0)
        sim.inflow_mean = sim.inflow_mean + up
        if sim.inflow_paths is not None:
            sim.inflow_paths = sim.inflow_paths + up
            sim.outflow_paths = sim.outflow_paths + down
        return sim
