"""Baseline forecasters M0–M3.

Every model predicts the daily *operating* net flow for days cutoff+1..cutoff+horizon,
using only data known at the end of `cutoff`. The balance forecast is then
    B̂(cutoff + h) = B(cutoff) + cumsum(prediction)[h].
"""
import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

from cashradar.forecast.series import CompanySeries


class Forecaster:
    name = "base"
    title = ""
    needs_training = False

    def fit(self, series: dict[str, CompanySeries], train_end: pd.Timestamp, horizon: int) -> None:
        pass

    def predict(self, cs: CompanySeries, cutoff: pd.Timestamp, horizon: int) -> np.ndarray:
        raise NotImplementedError


def future_dates(cutoff: pd.Timestamp, horizon: int) -> pd.DatetimeIndex:
    return pd.date_range(cutoff + pd.Timedelta(days=1), periods=horizon, freq="D")


class NaiveFlat(Forecaster):
    name, title = "M0_naive", "Остаток не меняется"

    def predict(self, cs, cutoff, horizon):
        return np.zeros(horizon)


class WeekdayMean(Forecaster):
    name, title = "M1a_weekday", "Среднее по дню недели за 8 недель"

    def __init__(self, weeks: int = 8):
        self.weeks = weeks

    def predict(self, cs, cutoff, horizon):
        hist = cs.history(cutoff)["net_op"].iloc[-7 * self.weeks:]
        by_dow = hist.groupby(hist.index.day_of_week).mean()
        dates = future_dates(cutoff, horizon)
        return by_dow.reindex(dates.day_of_week).fillna(0.0).to_numpy()


class SameDayOfMonth(Forecaster):
    """Monthly obligations (salary, rent, taxes) repeat by day of month:
    take the average flow of the same date 1..3 months ago."""
    name, title = "M1b_month", "Тот же день месяца (среднее за 3 мес)"

    def __init__(self, months: int = 3):
        self.months = months

    def predict(self, cs, cutoff, horizon):
        hist = cs.history(cutoff)["net_op"]
        dates = future_dates(cutoff, horizon)
        pred = pd.Series(0.0, index=dates)
        for d in dates:
            vals = []
            for k in range(1, self.months + 1):
                src = d - pd.DateOffset(months=k)
                if src <= cutoff:
                    if src >= hist.index[0]:
                        vals.append(hist.at[src])
                else:  # source is in the forecast horizon itself (long months): reuse prediction
                    vals.append(pred.at[src])
            pred.at[d] = np.mean(vals) if vals else 0.0
        return pred.to_numpy()


class ETS(Forecaster):
    """Holt-Winters exponential smoothing with weekly seasonality on the daily net flow."""
    name, title = "M2_ets", "ETS (Хольт-Уинтерс, недельная сезонность)"

    def __init__(self, window_days: int = 364):
        self.window_days = window_days
        self._fallback = WeekdayMean()

    def predict(self, cs, cutoff, horizon):
        from statsmodels.tsa.holtwinters import ExponentialSmoothing

        hist = cs.history(cutoff)["net_op"].iloc[-self.window_days:]
        if len(hist) < 28:
            return self._fallback.predict(cs, cutoff, horizon)
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                model = ExponentialSmoothing(hist.to_numpy(), trend=None, seasonal="add", seasonal_periods=7,
                                             initialization_method="estimated").fit()
            pred = model.forecast(horizon)
        except Exception:
            return self._fallback.predict(cs, cutoff, horizon)
        return np.nan_to_num(pred) if np.isfinite(pred).all() else self._fallback.predict(cs, cutoff, horizon)


# ---------------------------------------------------------------------------
# M3: global gradient boosting, direct multi-horizon
# ---------------------------------------------------------------------------

FEATURES = [
    "h", "dow", "dom", "month", "days_to_eom", "is_weekend",
    "roll7", "roll28", "roll91", "in28", "out28", "wd_mean8",
    "lag_m1", "lag_m2", "lag_m3", "dom_mean3", "yoy_win7",
    "bal_scaled", "history_days", "industry",
]
# features available from flows alone (no account balance): what an embedding service can supply
FLOW_FEATURES = [f for f in FEATURES if f != "bal_scaled"]
TARGET_CLIP = 50.0
MIN_TRAIN_ROWS = 5000  # below this a global model is noise (e.g. 20 companies × 3 months)


def turnover_scale(frame: pd.DataFrame, window: int = 91) -> pd.Series:
    """Average daily turnover ((in + out) / 2) over the trailing window; the unit for scale-free errors."""
    turnover = (frame["inflow_op"] + frame["outflow_op"]) / 2
    return turnover.rolling(window, min_periods=1).mean().clip(lower=1.0)


def company_features(cs: CompanySeries, cutoffs: pd.DatetimeIndex, horizon: int,
                     industry_code: int, with_target: bool) -> pd.DataFrame:
    f = cs.frame
    start = f.index[0]
    net = f["net_op"].to_numpy()
    n = len(net)
    p = ((cutoffs - start).days).to_numpy()

    scale = turnover_scale(f).to_numpy()
    roll = {w: f["net_op"].rolling(w, min_periods=1).mean().to_numpy() for w in (7, 28, 91)}
    in28 = f["inflow_op"].rolling(28, min_periods=1).mean().to_numpy()
    out28 = f["outflow_op"].rolling(28, min_periods=1).mean().to_numpy()
    dow_all = f.index.day_of_week.to_numpy()
    # mean flow per weekday over the trailing 56 days, as known at each day
    wd_roll = np.vstack([
        pd.Series(np.where(dow_all == w, net, np.nan)).rolling(56, min_periods=1).mean().to_numpy()
        for w in range(7)
    ])
    cum = np.concatenate([[0.0], np.cumsum(net)])

    P = np.repeat(p, horizon)
    H = np.tile(np.arange(1, horizon + 1), len(p))
    T = P + H
    target_dates = start + pd.to_timedelta(T, unit="D")
    sc = scale[P]

    def lag_months(k: int) -> np.ndarray:
        src = ((target_dates - pd.DateOffset(months=k)) - start).days.to_numpy()
        ok = (src >= 0) & (src <= P)
        out = np.full(len(P), np.nan)
        out[ok] = net[src[ok]] / sc[ok]
        return out

    lags = [lag_months(k) for k in (1, 2, 3)]
    yoy_c = T - 365
    lo, hi = yoy_c - 3, yoy_c + 4
    ok = (lo >= 0) & (hi - 1 <= P)
    yoy = np.full(len(P), np.nan)
    yoy[ok] = (cum[hi[ok]] - cum[lo[ok]]) / 7 / sc[ok]

    dow = target_dates.day_of_week.to_numpy()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        dom_mean3 = np.nanmean(np.vstack(lags), axis=0)
    X = pd.DataFrame({
        "company_id": cs.company_id,
        "cutoff": start + pd.to_timedelta(P, unit="D"),
        "h": H,
        "dow": dow,
        "dom": target_dates.day.to_numpy(),
        "month": target_dates.month.to_numpy(),
        "days_to_eom": (target_dates.days_in_month - target_dates.day).to_numpy(),
        "is_weekend": (dow >= 5).astype(int),
        "roll7": roll[7][P] / sc, "roll28": roll[28][P] / sc, "roll91": roll[91][P] / sc,
        "in28": in28[P] / sc, "out28": out28[P] / sc,
        "wd_mean8": wd_roll[dow, P] / sc,
        "lag_m1": lags[0], "lag_m2": lags[1], "lag_m3": lags[2],
        "dom_mean3": dom_mean3,
        "yoy_win7": yoy,
        "bal_scaled": f["bal"].to_numpy()[P] / sc,
        "history_days": P + 1,
        "industry": industry_code,
        "scale": sc,
    })
    if with_target:
        valid = T < n
        X = X[valid].copy()
        X["target"] = np.clip(net[T[valid]] / sc[valid], -TARGET_CLIP, TARGET_CLIP)
    return X


class GlobalGBM(Forecaster):
    """One LightGBM for all companies. Rows = (company, cutoff, horizon h);
    target = net flow on cutoff+h divided by the company's turnover scale."""
    name, title = "M3_lgbm", "LightGBM глобальная (direct, 30 горизонтов)"
    needs_training = True

    def __init__(self, train_step_days: int = 7, min_history: int = 60, params: dict | None = None,
                 features: list[str] | None = None, min_train_rows: int | None = None):
        self.min_train_rows = MIN_TRAIN_ROWS if min_train_rows is None else min_train_rows
        self.train_step_days = train_step_days
        self.min_history = min_history
        self.features = list(features or FEATURES)
        self.params = params or dict(
            objective="regression", learning_rate=0.05, n_estimators=400, num_leaves=63,
            min_child_samples=200, subsample=0.8, subsample_freq=1, colsample_bytree=0.8, verbose=-1,
        )
        self.model = None
        self.industry_codes: dict[str, int] = {}

    def _code(self, industry: str) -> int:
        return self.industry_codes.setdefault(industry, len(self.industry_codes))

    def fit(self, series, train_end, horizon):
        import lightgbm as lgb

        parts = []
        # short exports: relax the history requirement rather than train on nothing
        for min_history in dict.fromkeys((self.min_history, 28, 14)):
            for cs in series.values():
                first = cs.first_date + pd.Timedelta(days=min_history)
                last = min(train_end, cs.last_date) - pd.Timedelta(days=horizon)
                if last < first:
                    continue
                cutoffs = pd.date_range(first, last, freq=f"{self.train_step_days}D")
                parts.append(company_features(cs, cutoffs, horizon, self._code(cs.industry), with_target=True))
            if parts and sum(len(p) for p in parts) >= self.min_train_rows:
                break
            parts = []
        if not parts:
            # not enough history anywhere: no model (the hybrid then falls back to M5, M3 to a flat forecast)
            self.model = None
            self.n_train_rows = 0
            return
        data = pd.concat(parts, ignore_index=True)
        self.model = lgb.LGBMRegressor(**self.params)
        self.model.fit(data[self.features], data["target"], categorical_feature=["industry"])
        self.n_train_rows = len(data)
        self.trained_until = f"{pd.Timestamp(train_end):%Y-%m-%d}"
        self.horizon = horizon

    def predict(self, cs, cutoff, horizon):
        if self.model is None:
            return np.zeros(horizon)
        X = company_features(cs, pd.DatetimeIndex([cutoff]), horizon, self._code(cs.industry), with_target=False)
        return self.model.predict(X[self.features]) * X["scale"].to_numpy()

    # -- artifact: a trained model shipped to another service ----------------------------
    def save(self, directory: str | Path) -> None:
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        if self.model is None:
            raise ValueError("the model is not trained (not enough history): nothing to save")
        booster = self.model.booster_ if hasattr(self.model, "booster_") else self.model
        booster.save_model(str(directory / "model.txt"))
        meta = dict(features=self.features, industry_codes=self.industry_codes, horizon=getattr(self, "horizon", 30),
                    trained_until=getattr(self, "trained_until", None), n_train_rows=getattr(self, "n_train_rows", None),
                    target="daily net flow / trailing 91-day turnover", params=self.params)
        (directory / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, directory: str | Path) -> "GlobalGBM":
        import lightgbm as lgb

        directory = Path(directory)
        meta = json.loads((directory / "meta.json").read_text(encoding="utf-8"))
        m = cls(features=meta["features"], params=meta.get("params"))
        m.industry_codes = dict(meta["industry_codes"])
        m.model = lgb.Booster(model_file=str(directory / "model.txt"))  # .predict has the same signature
        m.horizon = int(meta.get("horizon", 30))
        m.trained_until = meta.get("trained_until")
        return m


def all_baselines() -> list[Forecaster]:
    return [NaiveFlat(), WeekdayMean(), SameDayOfMonth(), ETS(), GlobalGBM()]
