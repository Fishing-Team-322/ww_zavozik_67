"""M5 as a library: the forecasting core without our web service.

    pip install ./backend          # numpy, pandas, pyyaml only

    from cashradar.embed import M5Engine
    engine = M5Engine()
    res = engine.forecast(dates, inflow, outflow, missing, horizon=30, n_paths=500, seed=7,
                          categories={"salary": [...], ...}, transactions=[{...}, ...], industry="Опт")
    res.inflow, res.outflow        # (n_paths, horizon), both >= 0
    res.events                     # known future payments behind the forecast (for explanations)

By default the engine is the hybrid M6 (M5 paths, mean pulled towards a LightGBM trained on the case
companies, artifact in cashradar/artifacts/m6_gbm). Without lightgbm or the artifact it falls back to
plain M5 and reports `hybrid_unavailable` in warnings.

Input = daily business flows, one row per calendar day, in the scope of ww_zavozik_67
(«business_without_internal_transfers»: own transfers and founder loans excluded, credits included).

Two modes, chosen automatically:
  full — `transactions` with payment purposes: regular payments per counterparty, the invoice registry
         rebuilt from purposes (Markov model of payment delay), our categorizer;
  lite — only daily sums per category (`categories`): regular payments per category, no invoices.
Money not covered by transactions/categories is added as «uncategorized», so the flows always
add up to the supplied daily inflow/outflow.
"""
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

import numpy as np
import pandas as pd

from cashradar.categorize.engine import Categorizer
from cashradar.domain import schema as s
from cashradar.domain.scenario import BASE, Scenario
from cashradar.forecast.hybrid import DEFAULT_WEIGHT, HybridForecaster
from cashradar.forecast.series import CompanySeries
from cashradar.forecast.structural import StructuralWithInvoices

# categories of ww_zavozik_67 (ml/zavozik_ml/classify/text.py) → ours, by sign of the flow
TEAM_TO_OURS = {
    ("revenue_acquiring", 1): "in.acquiring", ("revenue_sbp", 1): "in.sbp", ("revenue_cash", 1): "in.cash",
    ("revenue_b2b", 1): "in.customer_payment", ("revenue_marketplace", 1): "in.marketplace",
    ("refund", 1): "in.refund", ("loan_payment", 1): "in.credit",
    ("own_transfer", 1): "in.internal_transfer", ("owner_loan", 1): "in.owner_financing",
    ("supplier", -1): "out.purchases", ("salary", -1): "out.salary", ("tax", -1): "out.tax",
    ("rent", -1): "out.rent", ("utilities", -1): "out.utilities", ("loan_payment", -1): "out.loan",
    ("leasing", -1): "out.leasing", ("bank_fee", -1): "out.bank_fee", ("marketing", -1): "out.marketing",
    ("services", -1): "out.services", ("enforcement", -1): "out.writ",
    ("own_transfer", -1): "out.internal_transfer", ("owner_loan", -1): "out.owner_loan_repayment",
}
# internal movements of the owner: excluded from the business flow (credits stay in, as in the team's scope)
INTERNAL = {"in.internal_transfer", "out.internal_transfer", "in.owner_financing", "out.owner_loan_repayment"}
UNCATEGORIZED = "cat:uncategorized"
LOW_CONFIDENCE_DAYS = 28

ARTIFACT_DIR = Path(__file__).resolve().parent / "artifacts" / "m6_gbm"

_categorizer: Categorizer | None = None
_gbm_cache: dict[str, object] = {}


def load_gbm(directory: str | Path = ARTIFACT_DIR):
    """The trained LightGBM of the hybrid, or None when lightgbm or the artifact is missing."""
    key = str(directory)
    if key not in _gbm_cache:
        try:
            from cashradar.forecast.baselines import GlobalGBM
            _gbm_cache[key] = GlobalGBM.load(directory)
        except Exception:  # noqa: BLE001 — any failure means «no hybrid», never a failed forecast
            _gbm_cache[key] = None
    return _gbm_cache[key]


def categorizer() -> Categorizer:
    global _categorizer
    if _categorizer is None:
        _categorizer = Categorizer()
    return _categorizer


@dataclass
class EmbedResult:
    inflow: np.ndarray                 # (n_paths, horizon), >= 0
    outflow: np.ndarray                # (n_paths, horizon), >= 0
    dates: list[date]
    mode: str                          # "full" | "lite", with "+hybrid" when LightGBM is used
    low_confidence: bool
    events: list[dict] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def net(self) -> np.ndarray:
        return self.inflow - self.outflow


class M5Engine:
    """Stateless: every call builds the model from the history it is given."""

    def __init__(self, spread: float = 1.5, pool_weeks: int = 12, seasonal: bool = True, hybrid: bool = True,
                 gbm_dir: str | Path = ARTIFACT_DIR, weight: float = DEFAULT_WEIGHT):
        self.spread = spread
        self.pool_weeks = pool_weeks
        self.seasonal = seasonal
        self.gbm = load_gbm(gbm_dir) if hybrid else None
        self.hybrid_requested = hybrid
        self.weight = weight

    def forecast(self, dates, inflow, outflow, missing=None, *, horizon: int, n_paths: int, seed: int = 0,
                 categories: dict[str, np.ndarray] | None = None, transactions: list[dict] | None = None,
                 industry: str = "", company_id: str = "company", scenario: Scenario = BASE) -> EmbedResult:
        idx = pd.DatetimeIndex(pd.to_datetime(list(dates)))
        n = len(idx)
        if n == 0:
            raise ValueError("history is empty")
        if n > 1 and (np.diff(idx.values).astype("timedelta64[D]").astype(int) != 1).any():
            raise ValueError("history must contain consecutive calendar days")
        inflow = np.asarray(inflow, dtype=float)
        outflow = np.asarray(outflow, dtype=float)
        missing = np.zeros(n, dtype=bool) if missing is None else np.asarray(missing, dtype=bool)
        if not (len(inflow) == len(outflow) == len(missing) == n):
            raise ValueError("dates, inflow, outflow and missing must have the same length")
        if not (np.isfinite(inflow).all() and np.isfinite(outflow).all()) or (inflow < 0).any() or (outflow < 0).any():
            raise ValueError("flows must be finite and >= 0")
        inflow = np.where(missing, 0.0, inflow)
        outflow = np.where(missing, 0.0, outflow)

        warnings = []
        full = bool(transactions) and any((t.get("purpose") or "").strip() for t in transactions)
        ops = self._ops_from_transactions(transactions, company_id) if transactions else \
            self._ops_from_categories(categories or {}, idx, company_id)
        ops = self._add_uncategorized(ops, idx, inflow, outflow, missing, company_id)
        ops = self._categorize(ops, use_rules=full)

        frame = pd.DataFrame({
            "inflow_op": inflow, "outflow_op": outflow, "net": inflow - outflow, "net_fin": 0.0,
            "net_op": inflow - outflow, "adj": 0.0, "bal": np.cumsum(inflow - outflow),  # relative balance
            "has_ops": (inflow + outflow) > 0, "missing": missing,
        }, index=idx)
        cs = CompanySeries(company_id, industry, frame)

        kw = dict(n_paths=n_paths, pool_weeks=self.pool_weeks, seasonal=self.seasonal, seed=int(seed),
                  spread=self.spread)
        # without purposes the invoice registry is simply empty: the same class covers both modes
        if self.gbm is not None:
            model = HybridForecaster(ops, gbm=self.gbm, weight=self.weight, **kw)
        else:
            model = StructuralWithInvoices(ops, **kw)
            if self.hybrid_requested:
                warnings.append("hybrid_unavailable")
        model._slot_cache = {}  # per call: never reuse slots detected for another history
        model.book.known_until = idx[-1]
        sim = model.simulate(cs, idx[-1], horizon, scenario)

        valid = int((~missing).sum())
        if valid < LOW_CONFIDENCE_DAYS:
            warnings.append("insufficient_history")
        if not full:
            warnings.append("lite_mode_no_purposes")
        events = [dict(date=r["date"].date().isoformat(), label=r["label"], amount=float(r["amount"]),
                       kind=r["kind"], probability=float(r["probability"]))
                  for _, r in sim.events.iterrows()]
        return EmbedResult(sim.inflow_paths, sim.outflow_paths, [d.date() for d in sim.dates],
                           ("full" if full else "lite") + ("+hybrid" if self.gbm is not None else ""),
                           valid < LOW_CONFIDENCE_DAYS, events, warnings)

    # -- building operations ----------------------------------------------------------
    @staticmethod
    def _frame(rows: list[dict], company_id: str) -> pd.DataFrame:
        df = pd.DataFrame(rows, columns=["id", "date", "amount", "sign", "team_category", "cp", "purpose"])
        out = pd.DataFrame({
            s.COMPANY: company_id,
            s.OP_ID: df["id"].astype(str),
            s.DATE: pd.to_datetime(df["date"]),
            s.AMOUNT: df["amount"].astype(float),
            s.DIRECTION: np.where(df["sign"] > 0, s.INFLOW, s.OUTFLOW),
            s.INN: df["cp"].astype(object),
            s.CP_NAME: df["cp"].fillna("").astype(str),
            s.PURPOSE: df["purpose"].fillna("").astype(str),
            s.BALANCE: 0.0,
            s.SIGN: df["sign"].astype(int),
        })
        out[s.SIGNED] = out[s.AMOUNT] * out[s.SIGN]
        out["team_category"] = df["team_category"].fillna("").astype(str)
        return out

    def _ops_from_transactions(self, transactions: list[dict], company_id: str) -> pd.DataFrame:
        rows = []
        for i, t in enumerate(transactions):
            amount = float(t["amount"])
            direction = str(t.get("direction", "")).lower()
            sign = 1 if direction in ("in", "inflow", "поступление") else -1 if direction in ("out", "outflow", "списание") \
                else (1 if amount >= 0 else -1)
            if amount == 0:
                continue
            rows.append(dict(id=t.get("id", i), date=t["date"], amount=abs(amount), sign=sign,
                             team_category=t.get("category") or "", cp=t.get("counterparty_id") or None,
                             purpose=t.get("purpose") or ""))
        return self._frame(rows, company_id)

    def _ops_from_categories(self, categories: dict[str, np.ndarray], idx: pd.DatetimeIndex,
                             company_id: str) -> pd.DataFrame:
        rows = []
        for name, values in categories.items():
            values = np.nan_to_num(np.asarray(values, dtype=float))
            for k in np.flatnonzero(values):
                rows.append(dict(id=f"{name}-{k}", date=idx[k], amount=abs(values[k]), sign=1 if values[k] > 0 else -1,
                                 team_category=name, cp=f"cat:{name}", purpose=""))
        return self._frame(rows, company_id)

    def _add_uncategorized(self, ops: pd.DataFrame, idx: pd.DatetimeIndex, inflow: np.ndarray, outflow: np.ndarray,
                           missing: np.ndarray, company_id: str) -> pd.DataFrame:
        """Daily flows not covered by the supplied operations become one «uncategorized» operation."""
        internal_team = ops["team_category"].isin(["own_transfer", "owner_loan"]).to_numpy()
        biz = ops[~internal_team]
        pos = (biz[s.DATE] - idx[0]).dt.days.to_numpy()
        ok = (pos >= 0) & (pos < len(idx))
        covered_in = np.bincount(pos[ok], weights=np.where(biz[s.SIGN] > 0, biz[s.AMOUNT], 0.0)[ok], minlength=len(idx))
        covered_out = np.bincount(pos[ok], weights=np.where(biz[s.SIGN] < 0, biz[s.AMOUNT], 0.0)[ok], minlength=len(idx))
        rows = []
        for k in range(len(idx)):
            if missing[k]:
                continue
            for flow, covered, sign in ((inflow[k], covered_in[k], 1), (outflow[k], covered_out[k], -1)):
                rest = flow - covered
                if rest > max(1.0, 1e-6 * flow):
                    rows.append(dict(id=f"uncat-{sign}-{k}", date=idx[k], amount=rest, sign=sign,
                                     team_category="other", cp=UNCATEGORIZED, purpose=""))
        if not rows:
            return ops.reset_index(drop=True)
        return pd.concat([ops, self._frame(rows, company_id)], ignore_index=True)

    @staticmethod
    def _categorize(ops: pd.DataFrame, use_rules: bool) -> pd.DataFrame:
        cat = categorizer()
        if ops.empty:
            out = ops.assign(category=pd.Series(dtype=str), cat_source=pd.Series(dtype=str))
            return cat.decorate(out).assign(is_financing=False)
        out = cat.categorize(ops.sort_values(s.DATE, kind="stable").reset_index(drop=True))
        team = [TEAM_TO_OURS.get((c, sg)) for c, sg in zip(out["team_category"], out[s.SIGN])]
        team = pd.Series(team, index=out.index)
        # purposes are the strongest signal; otherwise trust the team's categorizer
        use_team = team.notna() & ((out["cat_source"] != "rule:purpose") | (not use_rules))
        out.loc[use_team, "category"] = team[use_team]
        out.loc[use_team, "cat_source"] = "team"
        out = cat.decorate(out)
        out["is_financing"] = out["category"].isin(INTERNAL)
        return out
