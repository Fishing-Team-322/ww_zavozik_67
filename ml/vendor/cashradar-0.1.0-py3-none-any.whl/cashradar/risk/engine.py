"""Risk engine: from a Monte Carlo simulation to a warning a business owner can act on.

    when   — first day the probability of a negative balance becomes material
    how much — shortfall in the median and in the bad (90th percentile) scenario
    how likely — probability of a gap within the horizon (optionally recalibrated on the backtest)
    why    — the large known payments and uncertain inflows before that day
    what to do — rule-based recommendations
"""
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

from cashradar.forecast.structural import Simulation

LEVELS = ((0.4, "red"), (0.1, "yellow"), (0.0, "green"))
LEVEL_TEXT = {"red": "Высокий риск", "yellow": "Есть риск", "green": "Спокойно"}
MATERIAL_P = 0.1
FINANCING_LEAD_BUSINESS_DAYS = 5


def rub(x: float) -> str:
    return f"{abs(x):,.0f}".replace(",", " ") + " ₽"


class ProbabilityCalibrator:
    """Isotonic mapping «simulated probability → observed frequency», fit on past backtest windows."""

    def __init__(self, x: list[float] | None = None, y: list[float] | None = None):
        self.x, self.y = x, y

    def fit(self, p: np.ndarray, outcome: np.ndarray) -> "ProbabilityCalibrator":
        from sklearn.isotonic import IsotonicRegression

        iso = IsotonicRegression(y_min=0.0, y_max=1.0, out_of_bounds="clip").fit(p, outcome.astype(float))
        self.x, self.y = iso.X_thresholds_.tolist(), iso.y_thresholds_.tolist()
        return self

    def __call__(self, p):
        if self.x is None:
            return p
        return np.interp(p, self.x, self.y)

    def save(self, path: Path) -> None:
        path.write_text(json.dumps({"x": self.x, "y": self.y}), encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> "ProbabilityCalibrator":
        d = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls(d["x"], d["y"])


@dataclass
class Driver:
    date: pd.Timestamp
    label: str
    amount: float
    kind: str
    probability: float = 1.0


@dataclass
class RiskAssessment:
    company_id: str
    cutoff: pd.Timestamp
    level: str
    p_gap: float
    p_gap_raw: float
    risk_date: pd.Timestamp | None
    shortfall_p50: float
    shortfall_p90: float
    p_by_day: pd.Series
    drivers: list[Driver] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)
    message: str = ""

    def to_dict(self) -> dict:
        d = asdict(self)
        d["p_by_day"] = {k.strftime("%Y-%m-%d"): float(v) for k, v in self.p_by_day.items()}
        return d


def assess(sim: Simulation, threshold: float = 0.0, calibrator: ProbabilityCalibrator | None = None,
           has_other_bank: bool = False) -> RiskAssessment:
    B = sim.balance_paths()
    mins = B.min(axis=1)
    p_raw = float((mins < threshold).mean())
    p = float(calibrator(p_raw)) if calibrator else p_raw
    p_day = pd.Series((B < threshold).mean(axis=0), index=sim.dates)
    level = next(name for bound, name in LEVELS if p >= bound)

    risk_date = None
    if p_day.max() >= MATERIAL_P:
        risk_date = p_day.index[np.flatnonzero(p_day.to_numpy() >= 0.5 * p_day.max())[0]]
    short = threshold - mins[mins < threshold]
    s50 = float(np.median(short)) if short.size else 0.0
    s90 = float(np.quantile(short, 0.9)) if short.size else 0.0

    drivers = _drivers(sim, risk_date)
    recs = _recommendations(sim, risk_date, s90, has_other_bank) if risk_date is not None else []
    msg = _message(level, p, risk_date, s50, drivers, sim)
    return RiskAssessment(sim.company_id, sim.cutoff, level, p, p_raw, risk_date, s50, s90, p_day, drivers, recs, msg)


def _drivers(sim: Simulation, risk_date: pd.Timestamp | None, top: int = 5) -> list[Driver]:
    ev = sim.events
    if ev.empty:
        return []
    end = risk_date if risk_date is not None else sim.dates[-1]
    ev = ev[ev["date"] <= end]
    out = ev[ev["amount"] < 0]
    big_out = out[out["amount"] <= 0.1 * out["amount"].min()].sort_values("amount").head(top)
    # inflows we count on but that may not arrive in time
    shaky_in = ev[(ev["amount"] > 0) & (ev["probability"] < 0.8)].sort_values("amount", ascending=False).head(2)
    return [Driver(r.date, r.label, float(r.amount), r.kind, float(r.probability))
            for r in pd.concat([big_out, shaky_in]).itertuples()]


def _recommendations(sim: Simulation, risk_date: pd.Timestamp, shortfall_p90: float, has_other_bank: bool) -> list[str]:
    recs = []
    ev = sim.events
    if not ev.empty and "typical_lag" in ev:
        recv = ev[(ev["kind"] == "invoice") & (ev["amount"] > 0)].sort_values("amount", ascending=False).head(3)
        for r in recv.itertuples():
            lag = f", обычно этот клиент платит через {r.typical_lag:.0f} дн." if pd.notna(r.typical_lag) else ""
            recs.append(f"Напомните об оплате: {r.label} — {rub(r.amount)} (вероятность оплаты до конца "
                        f"прогноза {r.probability:.0%}{lag}).")
        payables = ev[(ev["kind"] == "invoice") & (ev["amount"] < 0) & (ev["date"] <= risk_date)]
        if not payables.empty:
            recs.append(f"Договоритесь с поставщиками о переносе оплаты счетов на {rub(payables['amount'].sum())} "
                        f"на дату после {risk_date:%d.%m}.")
    if not ev.empty:
        owner = ev[(ev["category"] == "out.owner_withdrawal") & (ev["date"] <= risk_date)]
        if not owner.empty:
            recs.append(f"Отложите вывод денег владельцу ({rub(owner['amount'].sum())}) до {risk_date:%d.%m}.")
    if has_other_bank:
        recs.append("У вас есть счёт в другом банке: переведите резерв на этот счёт до "
                    f"{risk_date:%d.%m}.")
    deadline = pd.bdate_range(end=risk_date, periods=FINANCING_LEAD_BUSINESS_DAYS + 1)[0]
    if shortfall_p90 > 0:
        when = f"оформите до {deadline:%d.%m}" if deadline > sim.cutoff else "оформите как можно скорее"
        recs.append(f"Подстрахуйтесь овердрафтом или кредитной линией на {rub(_round_up(shortfall_p90))}: {when}.")
    return recs


def _round_up(x: float, step: float = 10_000) -> float:
    return float(np.ceil(x / step) * step)


def _message(level: str, p: float, risk_date, s50: float, drivers: list[Driver], sim: Simulation) -> str:
    horizon = len(sim.dates)
    if risk_date is None or level == "green":
        return f"{LEVEL_TEXT['green']}: на ближайшие {horizon} дней денег на обязательные платежи хватает."
    text = f"{LEVEL_TEXT[level]}: {risk_date:%d.%m} может не хватить ~{rub(_round_up(s50))} (вероятность {p:.0%})."
    outs = [d for d in drivers if d.amount < 0 and d.date <= risk_date][:3]
    if outs:
        text += " К этой дате: " + "; ".join(f"{d.label} {rub(d.amount)} ({d.date:%d.%m})" for d in outs) + "."
    shaky = [d for d in drivers if d.amount > 0]
    if shaky:
        d = shaky[0]
        text += f" Поступление «{d.label}» на {rub(d.amount)} может задержаться (вероятность в срок {d.probability:.0%})."
    return text
