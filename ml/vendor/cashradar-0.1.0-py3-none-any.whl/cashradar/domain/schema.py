"""Column names and constants of the bank statement format."""

COMPANY = "company_id"
OP_ID = "operation_id"
DATE = "operation_date"
AMOUNT = "amount"
DIRECTION = "direction"
INN = "counterparty_inn"
CP_NAME = "counterparty_name"
PURPOSE = "payment_purpose"
BALANCE = "balance_eod"

REQUIRED_COLUMNS = [COMPANY, OP_ID, DATE, AMOUNT, DIRECTION, INN, CP_NAME, PURPOSE, BALANCE]

INFLOW = "Поступление"
OUTFLOW = "Списание"

# Derived columns
SIGN = "sign"            # +1 inflow, -1 outflow
SIGNED = "signed_amount"  # amount * sign
