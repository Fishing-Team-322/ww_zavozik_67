"""User-defined future events and «what if» scenarios — inputs of the simulation."""
from dataclasses import dataclass, field

import pandas as pd


@dataclass(frozen=True)
class ExtraEvent:
    """A one-off future payment the statement cannot know about:
    entered by the owner («client promised 300 000 on the 20th») or part of a scenario."""
    date: pd.Timestamp
    amount: float            # signed: inflow > 0, outflow < 0
    label: str
    source: str = "manual"   # "manual" | "scenario"
    id: int | None = None


@dataclass(frozen=True)
class Scenario:
    """Adverse changes applied on top of the base forecast.

    revenue_factor     future sales: retail flow and invoices issued after the forecast date
    fixed_cost_factor  rent, utilities, services, subscriptions
    purchase_factor    supplier payments: non-recurring outflows and new supplier invoices
    client_delay_days  customers pay this many days later than usual
    client             counterparty key of the delaying customer; None = all customers
    """
    revenue_factor: float = 1.0
    fixed_cost_factor: float = 1.0
    purchase_factor: float = 1.0
    client_delay_days: int = 0
    client: str | None = None
    extra: tuple[ExtraEvent, ...] = field(default_factory=tuple)

    @property
    def is_base(self) -> bool:
        return (self.revenue_factor == 1.0 and self.fixed_cost_factor == 1.0 and self.purchase_factor == 1.0
                and self.client_delay_days == 0 and not self.extra)

    def delays(self, cp: str | None) -> int:
        """Extra payment delay for a customer (None = a customer not known yet)."""
        if self.client_delay_days <= 0:
            return 0
        return self.client_delay_days if self.client is None or self.client == cp else 0


BASE = Scenario()
