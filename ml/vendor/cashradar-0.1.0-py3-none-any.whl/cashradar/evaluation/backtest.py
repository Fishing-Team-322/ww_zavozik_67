"""Rolling-origin backtest of balance forecasts and cash-gap detection.

For each cutoff T (every `step_days`) and each eligible company:
  * a model sees only data up to the end of day T;
  * it predicts the operating net flow for T+1..T+H, giving a balance path B̂;
  * the truth is the *operating* balance: actual balance minus financing that came after T
    (owner money, new credits, transfers between own accounts are reactions to a gap,
    not something we forecast).
Global models are retrained every `retrain_every_days` on data with targets ≤ T.
"""
from dataclasses import asdict, dataclass

import numpy as np
import pandas as pd

from cashradar.core.logging import get_logger
from cashradar.domain import schema as s
from cashradar.evaluation.labels import first_event_in_window, operating_gap
from cashradar.forecast.baselines import Forecaster, turnover_scale
from cashradar.forecast.series import CompanySeries

log = get_logger(__name__)

REPORT_HORIZONS = (7, 14, 30)


@dataclass
class BacktestConfig:
    start: str = "2025-10-01"
    end: str = "2026-08-31"
    step_days: int = 14
    horizon: int = 30
    min_history_days: int = 90
    retrain_every_days: int = 91
    threshold: float = 0.0

    def cutoffs(self) -> pd.DatetimeIndex:
        return pd.date_range(self.start, self.end, freq=f"{self.step_days}D")


def eligible(cs: CompanySeries, cutoff: pd.Timestamp, cfg: BacktestConfig) -> bool:
    return (cs.first_date + pd.Timedelta(days=cfg.min_history_days) <= cutoff
            and cutoff + pd.Timedelta(days=cfg.horizon) <= cs.last_date)


def truth(cs: CompanySeries, cutoff: pd.Timestamp, horizon: int) -> dict:
    f = cs.frame
    p = f.index.get_loc(cutoff)
    fut = f.iloc[p + 1:p + 1 + horizon]
    bal_now = float(f["bal"].iloc[p])
    op_path = fut["bal"].to_numpy() - np.cumsum(fut["net_fin"].to_numpy())
    return dict(
        bal_now=bal_now,
        op_path=op_path,
        actual_path=fut["bal"].to_numpy(),
        data_gap=bool((fut["adj"] != 0).any()),
        scale=float(turnover_scale(f.iloc[:p + 1]).iloc[-1]),
    )


def rub_errors(raw_err: np.ndarray) -> dict:
    """Errors in rubles: absolute at report horizons, mean absolute and mean squared over the horizon."""
    out = {f"ae_h{h}": float(abs(raw_err[h - 1])) for h in REPORT_HORIZONS if h <= len(raw_err)}
    out.update(mae_rub=float(np.abs(raw_err).mean()), mse_rub=float((raw_err ** 2).mean()))
    return out


def evaluate_path(pred_net: np.ndarray, t: dict, threshold: float) -> dict:
    path = t["bal_now"] + np.cumsum(pred_net)
    raw_err = path - t["op_path"]
    err = np.abs(raw_err) / t["scale"]
    gap, first, short = operating_gap(t["bal_now"], np.diff(np.concatenate([[t["bal_now"]], t["op_path"]])), threshold)
    pgap, pfirst, pshort = operating_gap(t["bal_now"], pred_net, threshold)
    row = {f"nae_h{h}": err[h - 1] for h in REPORT_HORIZONS if h <= len(err)}
    row.update(rub_errors(raw_err))
    row.update(
        nmae=float(err.mean()),
        gap=gap, gap_first_day=first, gap_shortfall=short,
        pred_gap=pgap, pred_first_day=pfirst, pred_shortfall=pshort,
        score=float((threshold - path.min()) / t["scale"]),
    )
    return row


def evaluate_paths(paths: np.ndarray, t: dict, threshold: float, decision_p: float = 0.5) -> dict:
    """Probabilistic forecast: point = median balance path, gap probability = share of paths below threshold."""
    B = t["bal_now"] + np.cumsum(paths, axis=1)
    q10, q50, q90 = np.quantile(B, [0.1, 0.5, 0.9], axis=0)
    raw_err = q50 - t["op_path"]
    err = np.abs(raw_err) / t["scale"]
    gap, first, short = operating_gap(t["bal_now"], np.diff(np.concatenate([[t["bal_now"]], t["op_path"]])), threshold)
    mins = B.min(axis=1)
    p_gap = float((mins < threshold).mean())
    p_day = (B < threshold).mean(axis=0)
    pred_gap = p_gap >= decision_p
    pfirst = None
    if pred_gap:
        over = np.flatnonzero(p_day >= decision_p)
        pfirst = int(over[0] if over.size else p_day.argmax()) + 1
    row = {f"nae_h{h}": err[h - 1] for h in REPORT_HORIZONS if h <= len(err)}
    row.update(rub_errors(raw_err))
    row.update(
        nmae=float(err.mean()),
        gap=gap, gap_first_day=first, gap_shortfall=short,
        pred_gap=pred_gap, pred_first_day=pfirst,
        pred_shortfall=float(np.median(threshold - mins[mins < threshold])) if p_gap > 0 else 0.0,
        # tiny tie-breaker by the median path keeps the ranking informative when p_gap == 0 or 1
        score=p_gap + 1e-3 * np.tanh((threshold - np.median(mins)) / t["scale"]),
        p_gap=p_gap,
        coverage80=float(((t["op_path"] >= q10) & (t["op_path"] <= q90)).mean()),
    )
    return row


def run_backtest(series: dict[str, CompanySeries], events: pd.DataFrame, models: list[Forecaster],
                 cfg: BacktestConfig | None = None, progress=None) -> pd.DataFrame:
    """progress(done_cutoffs, total_cutoffs) is called after every cutoff."""
    cfg = cfg or BacktestConfig()
    rows = []
    last_fit: dict[str, pd.Timestamp] = {}
    cutoffs = cfg.cutoffs()
    for i, cutoff in enumerate(cutoffs):
        for m in models:
            if m.needs_training and (m.name not in last_fit
                                     or (cutoff - last_fit[m.name]).days >= cfg.retrain_every_days):
                m.fit(series, cutoff, cfg.horizon)
                last_fit[m.name] = cutoff
                log.info("%s retrained at %s", m.name, cutoff.date())
        n = 0
        for cs in series.values():
            if not eligible(cs, cutoff, cfg):
                continue
            n += 1
            t = truth(cs, cutoff, cfg.horizon)
            end = cutoff + pd.Timedelta(days=cfg.horizon)
            ev_first = first_event_in_window(events, cs.company_id, cutoff, end)
            base = dict(company_id=cs.company_id, industry=cs.industry, cutoff=cutoff,
                        bal_now=t["bal_now"], scale=t["scale"], data_gap=t["data_gap"],
                        event=ev_first is not None,
                        event_day=None if ev_first is None else (ev_first - cutoff).days)
            for m in models:
                if hasattr(m, "predict_paths"):
                    metrics = evaluate_paths(m.predict_paths(cs, cutoff, cfg.horizon), t, cfg.threshold)
                else:
                    metrics = evaluate_path(m.predict(cs, cutoff, cfg.horizon), t, cfg.threshold)
                rows.append(base | {"model": m.name} | metrics)
        log.info("cutoff %s: %d companies", cutoff.date(), n)
        if progress:
            progress(i + 1, len(cutoffs))
    return pd.DataFrame(rows)


def config_dict(cfg: BacktestConfig) -> dict:
    return asdict(cfg)
