"""Ground-truth labels of cash gaps for evaluating the gap detector.

The bank statement rarely shows a gap directly: owners cover shortfalls with their
own money or with transfers from another bank. So besides a negative balance we
use the traces such gaps leave:

    overdraft        end-of-day balance < 0
    hidden_gap       financing came in on a day when without it the balance would be < 0
    salary_delay     salary paid with compensation for delay (art. 236 of the Labour Code)
    enforcement      tax authority collection order or writ of execution
"""
import numpy as np
import pandas as pd

from cashradar.domain import schema as s

EVENT_TYPES = ("overdraft", "hidden_gap", "salary_delay", "enforcement")
SALARY_DELAY_MARKER = "компенсации за задержку"


def stress_events(ops: pd.DataFrame, days: pd.DataFrame) -> pd.DataFrame:
    """ops: categorized operations; days: CleanResult.days.
    Returns one row per (company, date, type) with the shortfall size in `amount`."""
    frames = []

    neg = days[days["bal_eod"] < 0]
    frames.append(pd.DataFrame({s.COMPANY: neg[s.COMPANY], "date": neg[s.DATE],
                                "type": "overdraft", "amount": -neg["bal_eod"]}))

    fin_in = (ops[ops["is_financing"] & (ops[s.SIGN] > 0)]
              .groupby([s.COMPANY, s.DATE])[s.AMOUNT].sum().rename("fin_in").reset_index())
    x = fin_in.merge(days[[s.COMPANY, s.DATE, "bal_eod"]], on=[s.COMPANY, s.DATE])
    x["counterfactual"] = x["bal_eod"] - x["fin_in"]
    x = x[x["counterfactual"] < 0]
    frames.append(pd.DataFrame({s.COMPANY: x[s.COMPANY], "date": x[s.DATE],
                                "type": "hidden_gap", "amount": -x["counterfactual"]}))

    delay = ops[ops[s.PURPOSE].str.lower().str.contains(SALARY_DELAY_MARKER)]
    frames.append(pd.DataFrame({s.COMPANY: delay[s.COMPANY], "date": delay[s.DATE],
                                "type": "salary_delay", "amount": delay[s.AMOUNT]}))

    enf = ops[ops["category"].isin(["out.tax_enforcement", "out.writ"])]
    frames.append(pd.DataFrame({s.COMPANY: enf[s.COMPANY], "date": enf[s.DATE],
                                "type": "enforcement", "amount": enf[s.AMOUNT]}))

    events = pd.concat(frames, ignore_index=True)
    events = events.groupby([s.COMPANY, "date", "type"], as_index=False)["amount"].sum()
    return events.sort_values([s.COMPANY, "date", "type"]).reset_index(drop=True)


def first_event_in_window(events: pd.DataFrame, company: str, start: pd.Timestamp, end: pd.Timestamp,
                          types: tuple[str, ...] = EVENT_TYPES) -> pd.Timestamp | None:
    """First stress event date in (start, end]."""
    e = events[(events[s.COMPANY] == company) & events["type"].isin(types)
               & (events["date"] > start) & (events["date"] <= end)]
    return None if e.empty else e["date"].min()


def operating_gap(balance_now: float, net_op_future: np.ndarray, threshold: float = 0.0) -> tuple[bool, int | None, float]:
    """Would the balance cross `threshold` if no financing came in?
    Returns (gap, first day offset 1..H or None, max shortfall)."""
    path = balance_now + np.cumsum(net_op_future)
    below = np.flatnonzero(path < threshold)
    if below.size == 0:
        return False, None, 0.0
    return True, int(below[0]) + 1, float(threshold - path.min())
