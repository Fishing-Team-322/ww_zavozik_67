"""Aggregate backtest rows into report tables."""
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score

from cashradar.evaluation.backtest import REPORT_HORIZONS

PROB_THRESHOLDS = (0.3, 0.5)


def accuracy_table(rows: pd.DataFrame) -> pd.DataFrame:
    """Balance error in units of average daily turnover (nMAE). Windows with missing data are excluded."""
    r = rows[~rows["data_gap"]]
    cols = [f"nae_h{h}" for h in REPORT_HORIZONS] + ["nmae"]
    agg = r.groupby("model")[cols].agg(["median", "mean"])
    agg.columns = [f"{c}_{a}" for c, a in agg.columns]
    if "coverage80" in r:
        agg["coverage80"] = r.groupby("model")["coverage80"].mean()
    agg["n"] = r.groupby("model").size()
    return agg.sort_values("nmae_median")


def _detection(y: np.ndarray, pred: np.ndarray, score: np.ndarray) -> dict:
    tp = int((y & pred).sum())
    fp = int((~y & pred).sum())
    fn = int((y & ~pred).sum())
    precision = tp / (tp + fp) if tp + fp else np.nan
    recall = tp / (tp + fn) if tp + fn else np.nan
    f1 = 2 * precision * recall / (precision + recall) if precision and recall else np.nan
    both = len(np.unique(y)) == 2
    return dict(
        positives=int(y.sum()), n=len(y), precision=precision, recall=recall, f1=f1,
        roc_auc=roc_auc_score(y, score) if both else np.nan,
        pr_auc=average_precision_score(y, score) if both else np.nan,
    )


def _scope(rows: pd.DataFrame, threshold: float) -> pd.DataFrame:
    return rows[~rows["data_gap"] & (rows["bal_now"] >= threshold)]


def gap_table(rows: pd.DataFrame, threshold: float = 0.0, label: str = "gap") -> pd.DataFrame:
    """Detection of gaps within the horizon, for windows that start with a non-negative balance.
    label="gap": operating balance below threshold; label="event": stress events (hidden gaps etc.)."""
    r = _scope(rows, threshold)
    out = {}
    for model, g in r.groupby("model"):
        y = g[label].to_numpy(bool)
        pred = g["pred_gap"].to_numpy(bool)
        d = _detection(y, pred, g["score"].to_numpy())
        if "p_gap" in g and g["p_gap"].notna().all():
            p = g["p_gap"].to_numpy()
            d["brier"] = float(np.mean((p - y) ** 2))
            for th in PROB_THRESHOLDS:
                dd = _detection(y, p >= th, p)
                d[f"precision@{th}"], d[f"recall@{th}"] = dd["precision"], dd["recall"]
        if label == "gap":
            tp = g[y & pred]
            d["lead_days_median"] = tp["gap_first_day"].median()
            d["date_err_days_median"] = (tp["pred_first_day"] - tp["gap_first_day"]).abs().median()
            d["shortfall_rel_err_median"] = ((tp["pred_shortfall"] - tp["gap_shortfall"]).abs()
                                             / tp["gap_shortfall"].clip(lower=1)).median()
        out[model] = d
    return pd.DataFrame(out).T.sort_values("pr_auc", ascending=False)


def event_table(rows: pd.DataFrame, threshold: float = 0.0) -> pd.DataFrame:
    """Same detection scored against stress events (hidden gaps, overdraft, salary delays, enforcement)."""
    return gap_table(rows, threshold, label="event")


def recalibration_check(rows: pd.DataFrame, split: pd.Timestamp, threshold: float = 0.0) -> pd.DataFrame:
    """Fit isotonic recalibration of p_gap on cutoffs before `split`, measure Brier on later cutoffs."""
    from cashradar.risk.engine import ProbabilityCalibrator

    r = _scope(rows, threshold)
    out = {}
    for model, g in r[r["p_gap"].notna()].groupby("model") if "p_gap" in r else []:
        train, test = g[g["cutoff"] < split], g[g["cutoff"] >= split]
        cal = ProbabilityCalibrator().fit(train["p_gap"].to_numpy(), train["gap"].to_numpy())
        y = test["gap"].to_numpy(float)
        out[model] = dict(n_test=len(test), brier_raw=float(np.mean((test["p_gap"] - y) ** 2)),
                          brier_calibrated=float(np.mean((cal(test["p_gap"].to_numpy()) - y) ** 2)),
                          base_rate=float(y.mean()))
    return pd.DataFrame(out).T


def calibration_table(rows: pd.DataFrame, threshold: float = 0.0,
                      bins=(0, 0.05, 0.2, 0.4, 0.6, 0.8, 0.95, 1.0001)) -> pd.DataFrame:
    """Predicted gap probability vs observed frequency, per model with probabilistic output."""
    r = _scope(rows, threshold)
    r = r[r["p_gap"].notna()] if "p_gap" in r else r.iloc[0:0]
    r = r.assign(bin=pd.cut(r["p_gap"], bins, right=False))
    return (r.groupby(["model", "bin"], observed=True)
            .agg(n=("gap", "size"), predicted=("p_gap", "mean"), observed=("gap", "mean"))
            .reset_index())
