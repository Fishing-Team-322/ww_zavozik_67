"""CLI: run the backtest of all baselines and write report tables.

    uv run python -m cashradar.evaluation.run_backtest [--data ../data/raw] [--out ../reports/backtest] [--quick]
"""
import argparse
import json
import time
from pathlib import Path

import pandas as pd

from cashradar.core.config import DATA_DIR, REPORTS_DIR
from cashradar.core.logging import get_logger
from cashradar.evaluation.backtest import BacktestConfig, config_dict, run_backtest
from cashradar.evaluation.metrics import accuracy_table, calibration_table, event_table, gap_table, recalibration_check
from cashradar.forecast.baselines import all_baselines
from cashradar.forecast.hybrid import HybridForecaster
from cashradar.forecast.structural import StructuralForecaster, StructuralWithInvoices
from cashradar.pipeline import prepare
from cashradar.risk.engine import ProbabilityCalibrator

log = get_logger("backtest")
ARTIFACTS = Path(__file__).resolve().parents[1] / "artifacts"


def statement_only(ops: pd.DataFrame, m5: StructuralWithInvoices, m6: HybridForecaster) -> list:
    """M5/M6 without the accounting-system stand-in: at a past cutoff the invoice registry knows
    only invoices already paid by then, as a service fed by the statement alone would."""
    m5s = StructuralWithInvoices(ops, book=m5.book, point_in_time=True, name="M5_statement")
    m6s = HybridForecaster(ops, book=m5.book, gbm=m6.gbm, point_in_time=True, name="M6_statement")
    m5s.title = "M5 только по выписке (реестр счетов на дату прогноза)"
    m6s.title = "M6 только по выписке (реестр счетов на дату прогноза)"
    m6s.needs_training = False  # shares M6's LightGBM, which M6 retrains
    return [m5s, m6s]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=str(DATA_DIR))
    ap.add_argument("--out", default=str(REPORTS_DIR / "backtest"))
    ap.add_argument("--quick", action="store_true", help="every 4th cutoff, for a smoke run")
    ap.add_argument("--models", default="", help="comma-separated model names; default = all")
    ap.add_argument("--update-artifacts", action="store_true",
                    help="also refresh the calibrators packaged with the model (cashradar/artifacts)")
    args = ap.parse_args()

    t0 = time.time()
    ds = prepare(args.data)
    cfg = BacktestConfig(step_days=56 if args.quick else 14)
    m5 = StructuralWithInvoices(ds.ops)
    m6 = HybridForecaster(ds.ops, book=m5.book)
    models = all_baselines() + [StructuralForecaster(ds.ops), m5, m6] + statement_only(ds.ops, m5, m6)
    if args.models:
        wanted = set(args.models.split(","))
        models = [m for m in models if m.name in wanted]

    rows = run_backtest(ds.series, ds.events, models, cfg)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    rows.to_csv(out / "rows.csv.gz", index=False)
    acc, gaps, ev = accuracy_table(rows), gap_table(rows, cfg.threshold), event_table(rows, cfg.threshold)
    acc.to_csv(out / "accuracy.csv")
    gaps.to_csv(out / "gaps.csv")
    ev.to_csv(out / "events.csv")
    calibration_table(rows, cfg.threshold).to_csv(out / "calibration.csv", index=False)
    if "p_gap" in rows:
        split = rows["cutoff"].sort_values().unique()[len(rows["cutoff"].unique()) // 2]
        recal = recalibration_check(rows, pd.Timestamp(split), cfg.threshold)
        recal.to_csv(out / "recalibration.csv")
        print(recal.round(4).to_string())
        # production calibrators for the main models: fit on all windows
        for name, file in (("M5_struct_invoices", "calibrator_M5.json"), ("M6_hybrid", "calibrator_M6.json"),
                           ("M6_statement", "calibrator_M6_statement.json")):
            scope = rows[(rows["model"] == name) & ~rows["data_gap"] & (rows["bal_now"] >= cfg.threshold)]
            if not scope.empty:
                cal = ProbabilityCalibrator().fit(scope["p_gap"].to_numpy(), scope["gap"].to_numpy())
                cal.save(out / file)
                if args.update_artifacts:
                    cal.save(ARTIFACTS / file)
    titles = {m.name: m.title for m in models}
    meta = dict(config=config_dict(cfg), models=titles, rows=len(rows),
                windows=int(rows[["company_id", "cutoff"]].drop_duplicates().shape[0]),
                cleaning=ds.cleaning.as_dict(), seconds=round(time.time() - t0, 1))
    (out / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    log.info("done in %.0fs", time.time() - t0)
    print(acc.round(2).to_string())
    print(gaps.round(3).to_string())
    print(ev.round(3).to_string())


if __name__ == "__main__":
    main()
