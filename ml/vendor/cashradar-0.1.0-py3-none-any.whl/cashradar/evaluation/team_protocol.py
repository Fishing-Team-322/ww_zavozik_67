"""Head-to-head with the team's transformer: the protocol of ww_zavozik_67/ml/zavozik_ml/trx/evaluate.py.

    uv run python -m cashradar.evaluation.team_protocol [--data ../data/raw]

Reproduced exactly:
  * companies: the 30 «audit» companies of ml/eval/split_v2.json (never used to fit the team's models);
  * origins: for each company o = n−1−30−30k (k = 0..5) over calendar days of its history,
    origin ≥ 2026-07-01, o ≥ 56, no export gap inside the 31-day window;
  * target: «business balance» = balance at the origin + cumsum(business inflow − outflow), where
    business excludes own transfers (purpose «собственн… средств») and founder loans («займ … учредител»);
  * metrics: WAPE of the median path at 7/14/30 days, p10–p90 coverage, gap = target < 0 at any day,
    precision/recall at probability ≥ 0.3, Brier, rank AUC; seasonal naive = weekday bootstrap over 8 weeks.
M5 is run on the same business definition (its «financing» set is replaced by the team's internal set),
so both models forecast the same quantity. M5 is not fitted on any company, so «unseen» holds by construction.
M6 (hybrid) uses a LightGBM trained without the 30 audit companies and on targets up to 2026-06-30 only
(the team's development boundary), so it is out-of-sample in both companies and time.
"""
import argparse
import re

import numpy as np
import pandas as pd

from cashradar.core.config import DATA_DIR
from cashradar.forecast.series import build_series
from cashradar.forecast.hybrid import HybridForecaster
from cashradar.forecast.structural import StructuralWithInvoices
from cashradar.forecast.train_gbm import train as train_gbm
from cashradar.pipeline import prepare
from cashradar.sources.calendar import is_business_day

# ml/eval/split_v2.json, «audit_companies»
AUDIT = ["C003", "C013", "C028", "C038", "C043", "C047", "C055", "C058", "C071", "C073", "C074", "C078", "C084",
         "C090", "C091", "C092", "C094", "C097", "C113", "C115", "C116", "C124", "C128", "C130", "C134", "C137",
         "C139", "C141", "C145", "C149"]
INTERNAL_RE = r"займ.*учредител|учредител.*займ|собственн\S* средств"
MIN_ORIGIN = pd.Timestamp("2026-07-01")
HORIZON, STEP, ORIGINS, PATHS, GAP_THRESHOLD = 30, 30, 6, 200, 0.3
REPORT_HORIZONS = (7, 14, 30)

# printed by the team's trx/evaluate.py (screenshot of runs/finetune-v2), for the side-by-side table
TEAM_RESULTS = [
    dict(model="trx (команда)", runs=86, wape_7=0.150, wape_14=0.273, wape_30=1.315, coverage=0.758, gap_events=9,
         gap_precision=0.164, gap_recall=1.0, gap_brier=0.295, gap_auc=0.958),
    dict(model="naive (команда)", runs=86, wape_7=0.180, wape_14=0.356, wape_30=0.478, coverage=0.807, gap_events=9,
         gap_precision=0.290, gap_recall=1.0, gap_brier=0.096, gap_auc=0.987),
]


def team_view(ds):
    """Same operations, but «financing» = the team's internal set: series then carry business flows."""
    ops = ds.ops.copy()
    ops["is_financing"] = ops["payment_purpose"].str.lower().str.contains(INTERNAL_RE, regex=True).to_numpy()
    series = build_series(ops, ds.days, dict(zip(ds.companies["company_id"], ds.companies["industry"])))
    return ops, series


def origins(frame: pd.DataFrame) -> list[int]:
    n, out = len(frame), []
    for k in range(ORIGINS):
        o = n - 1 - HORIZON - k * STEP
        if o < 56 or frame.index[o] < MIN_ORIGIN:
            continue
        if frame["missing"].iloc[o:o + HORIZON + 1].any() or np.isnan(frame["bal"].iloc[o]):
            continue
        out.append(o)
    return out


def naive_paths(frame: pd.DataFrame, o: int, rng: np.random.Generator) -> np.ndarray:
    """Port of trx/evaluate.py naive_paths: weekday bootstrap of business net flow over 8 weeks."""
    hist = frame.iloc[max(0, o - 55):o + 1]
    hist = hist[~hist["missing"]]
    days = hist.index
    work_hist = np.array([is_business_day(d) for d in days])
    flow = (hist["inflow_op"] + hist["outflow_op"]).to_numpy()
    use_cal = not bool((~work_hist & (flow > 0)).any())
    net = hist["net_op"].to_numpy()
    wd = days.day_of_week.to_numpy()
    out = np.zeros((PATHS, HORIZON))
    for d in range(HORIZON):
        day = frame.index[o] + pd.Timedelta(days=d + 1)
        if use_cal and not is_business_day(day):
            continue
        pool = np.flatnonzero((wd == day.day_of_week) & (work_hist if use_cal else True))
        if len(pool):
            out[:, d] = net[rng.choice(pool, size=PATHS)]
    return out


def metrics(rows: list[dict], name: str) -> dict:
    """Port of trx/evaluate.py metrics."""
    act = np.stack([r["actual"] for r in rows])
    q = np.stack([r[f"{name}_q"] for r in rows])
    m = {"model": name, "runs": len(rows)}
    for h in REPORT_HORIZONS:
        err = np.abs(act[:, h - 1] - q[:, 1, h - 1])
        m[f"wape_{h}"] = err.sum() / max(np.abs(act[:, h - 1]).sum(), 1.0)
    m["coverage"] = float(((act >= q[:, 0]) & (act <= q[:, 2])).mean())
    true = np.array([r["gap_true"] for r in rows])
    prob = np.array([r[f"{name}_gap_prob"] for r in rows])
    pred = prob >= GAP_THRESHOLD
    m["gap_events"] = int(true.sum())
    m["gap_precision"] = float((pred & true).sum() / pred.sum()) if pred.sum() else float("nan")
    m["gap_recall"] = float((pred & true).sum() / true.sum()) if true.sum() else float("nan")
    m["gap_brier"] = float(np.mean((prob - true) ** 2))
    if 0 < true.sum() < len(true):
        ranks = pd.Series(prob).rank().to_numpy()
        m["gap_auc"] = float((ranks[true].sum() - true.sum() * (true.sum() + 1) / 2) / (true.sum() * (~true).sum()))
    return m


def wape_ratio(rows: list[dict], model: str, ref: str = "naive", h: int = 30, n_boot: int = 2000,
               seed: int = 0) -> tuple[float, float, float]:
    """WAPE(model) / WAPE(ref) at horizon h with a 90% interval from resampling companies."""
    comp = np.array([r["company_id"] for r in rows])
    act = np.array([r["actual"][h - 1] for r in rows])
    err_m = np.abs(act - np.array([r[f"{model}_q"][1, h - 1] for r in rows]))
    err_r = np.abs(act - np.array([r[f"{ref}_q"][1, h - 1] for r in rows]))
    groups = [np.flatnonzero(comp == c) for c in np.unique(comp)]
    rng = np.random.default_rng(seed)
    boot = []
    for _ in range(n_boot):
        take = np.concatenate([groups[i] for i in rng.integers(0, len(groups), len(groups))])
        boot.append(err_m[take].sum() / max(err_r[take].sum(), 1.0))
    return float(err_m.sum() / err_r.sum()), float(np.quantile(boot, 0.05)), float(np.quantile(boot, 0.95))


def run(data_dir=DATA_DIR) -> tuple[pd.DataFrame, list[dict]]:
    ds = prepare(data_dir)
    ops, series = team_view(ds)
    m5 = StructuralWithInvoices(ops, n_paths=1000)
    gbm = train_gbm(ds, pd.Timestamp("2026-06-30"), exclude=set(AUDIT))
    m6 = HybridForecaster(ops, gbm=gbm, book=m5.book, n_paths=1000)
    # the same models without the accounting-system stand-in: the registry knows only invoices paid by the date
    m5p = StructuralWithInvoices(ops, book=m5.book, n_paths=1000, point_in_time=True)
    m6p = HybridForecaster(ops, gbm=gbm, book=m5.book, n_paths=1000, point_in_time=True)
    rng = np.random.default_rng(0)
    rows = []
    for cid in AUDIT:
        cs = series.get(cid)
        if cs is None:
            continue
        f = cs.frame
        for o in origins(f):
            start = float(f["bal"].iloc[o])
            fut = f.iloc[o + 1:o + 1 + HORIZON]
            actual = start + np.cumsum(fut["net_op"].to_numpy())
            row = dict(company_id=cid, as_of=f.index[o], actual=actual, gap_true=bool((actual < 0).any()))
            for name, net in (("naive", naive_paths(f, o, rng)), ("M5", m5.predict_paths(cs, f.index[o], HORIZON)),
                              ("M6", m6.predict_paths(cs, f.index[o], HORIZON)),
                              ("M5p", m5p.predict_paths(cs, f.index[o], HORIZON)),
                              ("M6p", m6p.predict_paths(cs, f.index[o], HORIZON))):
                bal = start + np.cumsum(net, axis=1)
                row[f"{name}_q"] = np.quantile(bal, [0.1, 0.5, 0.9], axis=0)
                row[f"{name}_gap_prob"] = float((bal.min(axis=1) < 0).mean())
            rows.append(row)
    ours = [metrics(rows, n) for n in ("naive", "M5", "M6", "M5p", "M6p")]
    ours[0]["model"] = "naive (наш порт)"
    ours[1]["model"] = "M5 структурная + реестр счетов (наша)"
    ours[2]["model"] = "M6 гибрид M5 + LightGBM, + реестр счетов (наша)"
    ours[3]["model"] = "M5 только выписка (наша)"
    ours[4]["model"] = "M6 только выписка (наша)"
    return pd.DataFrame(TEAM_RESULTS + ours), rows


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=str(DATA_DIR))
    args = ap.parse_args()
    table, rows = run(args.data)
    pd.set_option("display.width", 220)
    print(table.round(3).to_string(index=False))
    print("\nWAPE модели / WAPE naive (наш порт), 90% интервал по компаниям:")
    for name, title in (("M6", "M6 + реестр счетов"), ("M6p", "M6 только выписка"), ("M5p", "M5 только выписка")):
        cells = [f"{h} дн. {r:.2f} [{lo:.2f}…{hi:.2f}]" for h in REPORT_HORIZONS for r, lo, hi in [wape_ratio(rows, name, h=h)]]
        print(f"  {title:<20} " + "; ".join(cells))
    print(f"\nточек старта: {len(rows)}, компаний: {len({r['company_id'] for r in rows})}, "
          f"даты: {sorted({r['as_of'].strftime('%Y-%m-%d') for r in rows})[:3]} … "
          f"{sorted({r['as_of'].strftime('%Y-%m-%d') for r in rows})[-3:]}")


if __name__ == "__main__":
    main()
