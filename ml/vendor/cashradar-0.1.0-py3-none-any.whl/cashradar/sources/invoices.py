"""Invoices: receivables (issued to customers) and payables (received from suppliers).

The dataset has no invoice registry, but ~54% of incoming money references the
invoice/UPD number and date in the payment purpose. That lets us reconstruct, for any
date T, what an accounting system (1C) would have known *at T*:
    open invoice at T  = invoice dated ≤ T with payments after T;
    its open amount    = sum of those later payments.
Limitation: invoices that were never paid are invisible in a statement, so the
reconstructed registry is slightly optimistic. And it stands in for an accounting system: at a
past date T it knows invoices that get paid after T. `as_of(T)` gives the registry a service
fed by the statement alone would have had at T (only invoices paid by T).

Payment timing is modelled as a Markov chain over invoice age (a discrete-time
survival / hazard model): an invoice unpaid at age a gets paid at age a+k with the
empirical probability P(lag = a+k | lag > a) of this client, smoothed to company
and global levels when the client has little history.
"""
import copy
import re
from dataclasses import dataclass

import numpy as np
import pandas as pd

from cashradar.categorize.engine import counterparty_key
from cashradar.domain import schema as s

# "счёт № 15 от 01.06.2025", "сч. N 15 от 01.06.25", "УПД No 77 от 1.06.2025", "счету #15 от ..."
DOC_RE = re.compile(r"(?:сч[её]т\w*|\bсч\.|упд)\s*(?:(?:№|no\.?|n|#)\s*)?([\w\-/]+)\s+от\s+"
                    r"(\d{1,2}\.\d{1,2}\.(?:\d{4}|\d{2}))(?!\d)", re.IGNORECASE)
INVOICE_CATEGORIES = {
    1: {"in.customer_payment", "in.customer_prepayment"},
    -1: {"out.purchases", "out.subcontract"},
}
MIN_CLIENT_LAGS = 5
LAG_WINDOW_DAYS = 365


def parse_documents(ops: pd.DataFrame) -> pd.DataFrame:
    """Invoice-linked payments: one row per operation that references an invoice/UPD with a date."""
    eligible = np.zeros(len(ops), dtype=bool)
    for sign, cats in INVOICE_CATEGORIES.items():
        eligible |= (ops[s.SIGN].to_numpy() == sign) & ops["category"].isin(cats).to_numpy()
    sub = ops[eligible]
    m = sub[s.PURPOSE].str.extract(DOC_RE)
    doc_date = pd.to_datetime(m[1], format="%d.%m.%Y", errors="coerce")
    short = doc_date.isna() & m[1].notna()
    if short.any():  # two-digit year
        doc_date[short] = pd.to_datetime(m.loc[short, 1], format="%d.%m.%y", errors="coerce")
    ok = m[0].notna() & doc_date.notna() & (doc_date <= sub[s.DATE])
    sub, m, doc_date = sub[ok], m[ok], doc_date[ok]
    cp = counterparty_key(sub)
    return pd.DataFrame({
        "op_index": sub.index,
        s.COMPANY: sub[s.COMPANY].to_numpy(),
        "cp": cp.to_numpy(),
        "cp_name": sub[s.CP_NAME].to_numpy(),
        "sign": sub[s.SIGN].to_numpy(),
        "doc_no": m[0].str.lower().to_numpy(),
        "doc_date": doc_date.to_numpy(),
        "pay_date": sub[s.DATE].to_numpy(),
        "amount": sub[s.AMOUNT].to_numpy(),
    })


@dataclass
class OpenInvoice:
    cp: str
    cp_name: str
    sign: int
    doc_no: str
    doc_date: pd.Timestamp
    open_amount: float


class InvoiceBook:
    def __init__(self, ops: pd.DataFrame):
        docs = parse_documents(ops)
        self.linked_op_index = set(docs["op_index"])
        self._by_company = {c: g.sort_values("pay_date").reset_index(drop=True) for c, g in docs.groupby(s.COMPANY)}
        self._empty = docs.iloc[0:0]
        # the reconstructed registry only knows invoices paid by the end of the statement
        self.known_until = ops[s.DATE].max()
        self._docs = docs
        self._global_lags = self._lags_by_sign(docs)
        self._paid_by: pd.Timestamp | None = None  # set on as_of() views
        self._views: dict[pd.Timestamp, "InvoiceBook"] = {}

    @staticmethod
    def _lags_by_sign(docs: pd.DataFrame) -> dict[int, np.ndarray]:
        lags = (docs["pay_date"] - docs["doc_date"]).dt.days
        return {sign: lags[docs["sign"] == sign].to_numpy() for sign in (1, -1)}

    def as_of(self, cutoff: pd.Timestamp) -> "InvoiceBook":
        """The registry as the statement alone shows it at `cutoff`: invoices paid by then, nothing later."""
        if cutoff >= self.known_until:
            return self
        view = self._views.get(cutoff)
        if view is None:
            view = copy.copy(self)
            view._paid_by = cutoff
            view._docs = self._docs[self._docs["pay_date"] <= cutoff]
            view._global_lags = self._lags_by_sign(view._docs)
            view.known_until = cutoff
            view._views = {}
            if len(self._views) >= 64:
                self._views.clear()
            self._views[cutoff] = view
        return view

    def docs(self, company: str) -> pd.DataFrame:
        d = self._by_company.get(company, self._empty)
        return d if self._paid_by is None else d[d["pay_date"] <= self._paid_by]

    def open_at(self, company: str, cutoff: pd.Timestamp) -> list[OpenInvoice]:
        d = self.docs(company)
        d = d[(d["doc_date"] <= cutoff) & (d["pay_date"] > cutoff)]
        out = []
        for (cp, sign, no, date), g in d.groupby(["cp", "sign", "doc_no", "doc_date"]):
            out.append(OpenInvoice(cp, g["cp_name"].iloc[0], int(sign), no, pd.Timestamp(date), float(g["amount"].sum())))
        return out

    def issued_recent(self, company: str, cutoff: pd.Timestamp, sign: int, days: int = 91) -> np.ndarray:
        """Amounts of invoices issued in (cutoff - days, cutoff]: the registry knows them at cutoff."""
        d = self.docs(company)
        d = d[(d["sign"] == sign) & (d["doc_date"] > cutoff - pd.Timedelta(days=days)) & (d["doc_date"] <= cutoff)]
        return d.groupby(["cp", "doc_no", "doc_date"])["amount"].sum().to_numpy()

    def lag_model(self, company: str, cutoff: pd.Timestamp) -> "LagModel":
        d = self.docs(company)
        d = d[(d["pay_date"] <= cutoff) & (d["pay_date"] > cutoff - pd.Timedelta(days=LAG_WINDOW_DAYS))]
        lags = (d["pay_date"] - d["doc_date"]).dt.days.to_numpy()
        return LagModel(
            by_client={(cp, sign): lags[idx] for (cp, sign), idx in d.groupby(["cp", "sign"]).indices.items()},
            by_company={sign: lags[(d["sign"] == sign).to_numpy()] for sign in (1, -1)},
            global_lags=self._global_lags,
        )


@dataclass
class LagModel:
    by_client: dict[tuple[str, int], np.ndarray]
    by_company: dict[int, np.ndarray]
    global_lags: dict[int, np.ndarray]

    def pool(self, cp: str | None, sign: int, age: int = 0) -> np.ndarray:
        """Lags longer than `age` (Markov step: condition on «not paid yet»), most specific level first."""
        for lags in (self.by_client.get((cp, sign)) if cp else None, self.by_company.get(sign), self.global_lags.get(sign)):
            if lags is None:
                continue
            tail = lags[lags > age]
            if len(tail) >= MIN_CLIENT_LAGS:
                return tail
        return np.array([])

    def sample_remaining(self, rng: np.random.Generator, cp: str | None, sign: int, age: int, n: int) -> np.ndarray:
        """Days from now until payment for an invoice of the given age (≥ 1)."""
        tail = self.pool(cp, sign, age)
        if tail.size == 0:  # older than anything we've seen: pays within a month, uniformly
            return rng.integers(1, 31, size=n)
        return np.maximum(rng.choice(tail, size=n) - age, 1)

    def typical_lag(self, cp: str | None, sign: int) -> float | None:
        p = self.pool(cp, sign, 0)
        return float(np.median(p)) if p.size else None
