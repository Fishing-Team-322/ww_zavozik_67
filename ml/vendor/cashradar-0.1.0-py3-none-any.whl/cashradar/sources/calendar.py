"""Russian production calendar: business days and payment-date shifting.

Official calendars 2020–2027 (open data xmlcalendar.ru, files shared with ww_zavozik_67:
calendar_data/ru_<year>.json, `months[].days` lists non-working days; «*» = shortened working
day, «+» = transferred day off). For the case period they match, day for day, the calendar seen
in the data (no operations on holidays, operations on working Saturdays). Years without a file:
Monday–Friday minus fixed public holidays (art. 112 of the Labour Code).
"""
import datetime as dt
import json
from functools import lru_cache
from pathlib import Path

import pandas as pd

DATA = Path(__file__).with_name("calendar_data")
# Fixed public holidays + Dec 31 (non-working in recent years): fallback for years without a file.
_FIXED = {(1, d) for d in range(1, 9)} | {(2, 23), (3, 8), (5, 1), (5, 9), (6, 12), (11, 4), (12, 31)}


@lru_cache(maxsize=1)
def _official() -> tuple[frozenset[int], frozenset[dt.date]]:
    """(years covered, non-working days in them)."""
    years, nonwork = set(), set()
    for f in sorted(DATA.glob("ru_*.json")):
        d = json.loads(f.read_text(encoding="utf-8"))
        years.add(int(d["year"]))
        for m in d["months"]:
            for tok in str(m["days"]).split(","):
                tok = tok.strip()
                if not tok or tok.endswith("*"):
                    continue
                nonwork.add(dt.date(int(d["year"]), int(m["month"]), int(tok.rstrip("+"))))
    return frozenset(years), frozenset(nonwork)


def is_business_day(day) -> bool:
    d = pd.Timestamp(day).date()
    years, nonwork = _official()
    if d.year in years:
        return d not in nonwork
    return d.weekday() < 5 and (d.month, d.day) not in _FIXED


def next_business_day(day) -> pd.Timestamp:
    """The day itself if it is a business day, otherwise the next one (payments shift forward)."""
    d = pd.Timestamp(day).normalize()
    while not is_business_day(d):
        d += pd.Timedelta(days=1)
    return d


def business_shift_index(dates: pd.DatetimeIndex) -> list[int | None]:
    """For each date in a contiguous daily index: position of the business day a payment
    falling on it would actually be booked (None if that is beyond the index)."""
    pos = [None] * len(dates)
    nxt = None
    for i in range(len(dates) - 1, -1, -1):
        if is_business_day(dates[i]):
            nxt = i
        pos[i] = nxt
    return pos
