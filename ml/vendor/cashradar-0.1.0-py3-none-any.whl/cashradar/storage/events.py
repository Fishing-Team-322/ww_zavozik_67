"""Planned events entered by the owner, stored in SQLite.

«Client promised to pay 300 000 on the 20th», «in December I'll buy equipment for 1 mln».
They go into every forecast for the company as known payments, with source «manual».
"""
import os
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime
from dataclasses import asdict, dataclass
from pathlib import Path

import pandas as pd

from cashradar.core.config import REPO_ROOT
from cashradar.domain.scenario import ExtraEvent

DB_PATH = Path(os.environ.get("CASHRADAR_DB", REPO_ROOT / "data" / "cashradar.sqlite"))
MAX_LABEL = 200
MAX_AMOUNT = 1e11

SCHEMA = """
CREATE TABLE IF NOT EXISTS manual_events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id  TEXT NOT NULL,
    date        TEXT NOT NULL,
    amount      REAL NOT NULL,
    label       TEXT NOT NULL,
    created_by  TEXT NOT NULL,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS ix_manual_events_company ON manual_events(company_id);
"""


@dataclass
class ManualEvent:
    id: int
    company_id: str
    date: str
    amount: float
    label: str
    created_by: str
    created_at: str

    def to_extra(self) -> ExtraEvent:
        return ExtraEvent(pd.Timestamp(self.date), self.amount, self.label, source="manual", id=self.id)

    def as_dict(self) -> dict:
        return asdict(self)


class EventValidationError(ValueError):
    pass


class EventStore:
    def __init__(self, path: str | Path = DB_PATH):
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(SCHEMA)
        self._version: dict[str, int] = {}

    @contextmanager
    def _tx(self):
        with self._lock, self._conn:
            yield self._conn

    def version(self, company_id: str) -> int:
        """Bumped on every change: part of the forecast cache key."""
        return self._version.get(company_id, 0)

    def list(self, company_id: str) -> list[ManualEvent]:
        with self._tx() as c:
            rows = c.execute("SELECT * FROM manual_events WHERE company_id = ? ORDER BY date, id", (company_id,))
            return [ManualEvent(**dict(r)) for r in rows.fetchall()]

    def add(self, company_id: str, date: str, amount: float, label: str, user: str) -> ManualEvent:
        try:
            day = datetime.strptime(str(date), "%Y-%m-%d").strftime("%Y-%m-%d")
        except (ValueError, TypeError):
            raise EventValidationError("Дата должна быть в формате ГГГГ-ММ-ДД")
        label = (label or "").strip()
        if not label:
            raise EventValidationError("Опишите событие, например «Клиент обещал оплатить счёт»")
        if len(label) > MAX_LABEL:
            raise EventValidationError(f"Описание длиннее {MAX_LABEL} символов")
        if not amount or abs(amount) > MAX_AMOUNT:
            raise EventValidationError("Укажите ненулевую сумму")
        with self._tx() as c:
            cur = c.execute("INSERT INTO manual_events(company_id, date, amount, label, created_by) VALUES (?,?,?,?,?)",
                            (company_id, day, float(amount), label, user))
            row = c.execute("SELECT * FROM manual_events WHERE id = ?", (cur.lastrowid,)).fetchone()
        self._version[company_id] = self.version(company_id) + 1
        return ManualEvent(**dict(row))

    def delete(self, company_id: str, event_id: int) -> bool:
        with self._tx() as c:
            n = c.execute("DELETE FROM manual_events WHERE id = ? AND company_id = ?", (event_id, company_id)).rowcount
        if n:
            self._version[company_id] = self.version(company_id) + 1
        return bool(n)
