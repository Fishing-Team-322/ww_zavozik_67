"""Plan vs fact: compare a forecast made at date P with what happened in (P, now].

    weekly plan (mean and 80% band of simulated flows) vs actual inflows / outflows;
    each expected payment → paid (when, how much) / late / still within grace;
    large actual payments the plan did not expect.
A late customer payment is the key alert: the forecast made today already accounts
for it (the invoice is still open), and the risk is re-checked.
"""
import numpy as np
import pandas as pd

from cashradar.categorize.engine import counterparty_key
from cashradar.domain import schema as s
from cashradar.forecast.series import CompanySeries
from cashradar.forecast.structural import Simulation
from cashradar.risk.engine import rub
from cashradar.sources.invoices import InvoiceBook

RECURRING_AMOUNT_TOL = 0.35
MANUAL_AMOUNT_TOL = 0.10
MANUAL_DATE_WINDOW = 7
ALERT_OUT_CATEGORIES = {"out.salary", "out.tax", "out.rent", "out.loan", "out.leasing"}
UNPLANNED_MIN_SCALE = 3.0    # an unplanned payment ≥ this many average daily turnovers is worth showing


def _status(matched: bool, now: pd.Timestamp, date_late: pd.Timestamp) -> str:
    if matched:
        return "done"
    return "late" if now > date_late else "pending"


def plan_fact(plan: Simulation, cs: CompanySeries, ops: pd.DataFrame, now: pd.Timestamp,
              book: InvoiceBook | None = None) -> dict:
    """ops: categorized operations of the company (any period)."""
    P = plan.cutoff
    k = (now - P).days
    if not 1 <= k <= len(plan.dates):
        raise ValueError("now must be within the plan horizon")
    f = cs.frame.loc[P + pd.Timedelta(days=1):now]
    window = ops[(ops[s.DATE] > P) & (ops[s.DATE] <= now) & ~ops["is_financing"]].copy()
    window["cp"] = counterparty_key(window) if len(window) else pd.Series(dtype=str)
    used: set[int] = set()

    # -- expected payments → matched / late / pending -------------------------
    rows = []
    paid_docs = pd.DataFrame()
    if book is not None:
        d = book.docs(cs.company_id)
        paid_docs = d[(d["pay_date"] > P) & (d["pay_date"] <= now)]
    ev = plan.events
    ev = ev[ev["kind"].isin(["recurring", "invoice", "manual"])]
    for e in ev.itertuples():
        due_by_now = e.date <= now
        match_date, match_amount = None, None
        if e.kind == "invoice" and not paid_docs.empty:
            p = paid_docs[(paid_docs["cp"] == e.cp_key) & (paid_docs["doc_no"] == e.doc_no)]
            if not p.empty:
                match_date, match_amount = p["pay_date"].max(), float(np.sign(e.amount) * p["amount"].sum())
                used.update(p["op_index"])
        elif e.kind in ("recurring", "manual"):
            sign = 1 if e.amount > 0 else -1
            cand = window[(window[s.SIGN] == sign) & ~window.index.isin(list(used))]
            if e.kind == "recurring":
                cand = cand[(cand["category"] == e.category) & (cand["cp"] == e.cp_key)]
                tol = RECURRING_AMOUNT_TOL
            else:
                cand = cand[(cand[s.DATE] - e.date).abs() <= pd.Timedelta(days=MANUAL_DATE_WINDOW)]
                tol = MANUAL_AMOUNT_TOL
            cand = cand[(cand[s.AMOUNT] - abs(e.amount)).abs() <= tol * abs(e.amount)]
            if not cand.empty:
                best = cand.loc[(cand[s.DATE] - e.date).abs().idxmin()]
                match_date, match_amount = best[s.DATE], float(sign * best[s.AMOUNT])
                used.add(best.name)
        if not due_by_now and match_date is None:
            continue  # not expected yet and not paid early: belongs to the future, not to plan-vs-fact
        matched = match_date is not None
        rows.append(dict(
            date=e.date, label=e.label, kind=e.kind, category=e.category, amount=float(e.amount),
            status=_status(matched, now, e.date_late),
            fact_date=match_date, fact_amount=match_amount,
            delay_days=int((match_date - e.date).days) if matched else int(max((now - e.date).days, 0)),
            date_late=e.date_late,
        ))
    items = pd.DataFrame(rows)

    # -- weekly plan (mean, 80% band) vs fact -----------------------------------
    net = plan.paths[:, :k]
    plan_in = plan.inflow_mean[:k]
    weeks = []
    for w0 in range(0, k, 7):
        sl = slice(w0, min(w0 + 7, k))
        wk_net = net[:, sl].sum(axis=1)
        fact = f.iloc[sl]
        p_in = float(plan_in[sl].sum())
        p_net = float(wk_net.mean())
        lo, hi = np.quantile(wk_net, [0.1, 0.9])
        fact_net = float(fact["net_op"].sum() + fact["adj"].sum())
        weeks.append(dict(
            start=plan.dates[sl.start], end=plan.dates[sl.stop - 1],
            plan_in=p_in, plan_out=p_in - p_net, plan_net=p_net, plan_net_p10=float(lo), plan_net_p90=float(hi),
            fact_in=float(fact["inflow_op"].sum()), fact_out=float(fact["outflow_op"].sum()), fact_net=fact_net,
            outside=bool(fact_net < lo or fact_net > hi),
        ))

    # -- payments nobody planned ------------------------------------------------
    scale = float(((cs.frame["inflow_op"] + cs.frame["outflow_op"]) / 2).loc[:P].tail(91).mean() or 1.0)
    unplanned = window[~window.index.isin(list(used))]
    unplanned = unplanned[unplanned[s.AMOUNT] >= UNPLANNED_MIN_SCALE * scale].nlargest(5, s.AMOUNT)

    late_in = items[(items["status"] == "late") & (items["amount"] > 0)] if not items.empty else items
    late_out = items[(items["status"] == "late") & (items["amount"] < 0)] if not items.empty else items
    alerts = [f"Не пришло: {r.label} — {rub(r.amount)}, ожидалось {r.date:%d.%m}, "
              f"обычно поступает до {r.date_late:%d.%m}." for r in late_in.itertuples()]
    # a missing obligation is worth an alert only for the ones that hurt when skipped
    late_out = late_out[late_out["category"].isin(ALERT_OUT_CATEGORIES)] if not late_out.empty else late_out
    alerts += [f"Не прошёл обязательный платёж: {r.label} — {rub(r.amount)} (ожидался {r.date:%d.%m})."
               for r in late_out.itertuples()]

    plan_bal = plan.bal_now + np.cumsum(plan.paths[:, :k], axis=1)
    return dict(
        plan_date=P, now=now, days=k,
        totals=dict(plan_in=float(plan_in.sum()), plan_out=float(plan_in.sum() - net.mean(axis=0).sum()),
                    fact_in=float(f["inflow_op"].sum()), fact_out=float(f["outflow_op"].sum()),
                    plan_balance=float(np.median(plan_bal[:, -1])), fact_balance=float(f["bal"].iloc[-1]),
                    fact_operating_balance=float(f["bal"].iloc[-1] - f["net_fin"].sum())),
        weeks=weeks,
        items=items.to_dict("records"),
        unplanned=[dict(date=r[s.DATE], label=r[s.PURPOSE][:120] or r[s.CP_NAME], counterparty=r[s.CP_NAME],
                        amount=float(r[s.SIGNED]), category=r["category_name"]) for _, r in unplanned.iterrows()],
        alerts=alerts,
        counts=dict(done=int((items["status"] == "done").sum()) if not items.empty else 0,
                    late=int((items["status"] == "late").sum()) if not items.empty else 0,
                    pending=int((items["status"] == "pending").sum()) if not items.empty else 0),
    )
