"""End-to-end data preparation: statement files → clean categorized operations → daily series.

`prepare` writes a step-by-step log (what was read, what was fixed, what was found),
so a run on an unknown dataset can be followed and audited.
"""
import time
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

from cashradar.categorize.engine import Categorizer
from cashradar.core.config import DATA_DIR
from cashradar.core.logging import get_logger
from cashradar.evaluation.labels import stress_events
from cashradar.forecast.series import CompanySeries, build_series
from cashradar.ingest.cleaning import CleaningReport, clean
from cashradar.ingest.loader import LoadResult, load_dataset

log = get_logger(__name__)


@dataclass
class Dataset:
    ops: pd.DataFrame
    days: pd.DataFrame
    companies: pd.DataFrame
    series: dict[str, CompanySeries]
    events: pd.DataFrame
    cleaning: CleaningReport
    load: LoadResult | None = None
    steps: list[dict] = field(default_factory=list)


def prepare(data_dir: str | Path = DATA_DIR, on_step=None) -> Dataset:
    """on_step(dict) is called after every step (for live progress in the API)."""
    steps: list[dict] = []
    t0 = time.time()

    def step(title: str, **details):
        rec = dict(n=len(steps) + 1, title=title, seconds=round(time.time() - t0, 2), details=details)
        steps.append(rec)
        log.info("step %d. %s %s", rec["n"], title, details)
        if on_step:
            on_step(rec)

    loaded, companies = load_dataset(data_dir)
    step("Загрузка и проверка формата", operations=len(loaded.ops), companies=int(loaded.ops["company_id"].nunique()),
         rejected_rows=loaded.n_rejected, rejected_reasons=loaded.issue_summary(), notes=loaded.notes,
         period=f"{loaded.ops['operation_date'].min():%Y-%m-%d} — {loaded.ops['operation_date'].max():%Y-%m-%d}")

    cleaned = clean(loaded.ops)
    step("Очистка: дубли и пропуски", **cleaned.report.as_dict())

    ops = Categorizer().categorize(cleaned.ops)
    src = ops["cat_source"].value_counts()
    step("Категоризация операций", categories_used=int(ops["category"].nunique()),
         by_rules=round(float(src.filter(like="rule").sum() / len(ops)), 4),
         by_counterparty_memory=round(float(src.filter(like="memory").sum() / len(ops)), 4),
         uncategorized=int(src.get("fallback", 0)),
         top_groups={k: round(v / 1e6, 1) for k, v in ops.groupby("category_group")["amount"].sum().nlargest(6).items()})

    series = build_series(ops, cleaned.days, dict(zip(companies["company_id"], companies["industry"])))
    step("Дневные ряды остатка и потоков", companies=len(series),
         days_total=int(sum(len(c.frame) for c in series.values())),
         short_history_companies=sum(len(c.frame) < 90 for c in series.values()))

    events = stress_events(ops, cleaned.days)
    step("Разметка кассовых разрывов в истории", events=len(events),
         by_type=events["type"].value_counts().to_dict(), companies_with_events=int(events["company_id"].nunique()))

    return Dataset(ops, cleaned.days, companies, series, events, cleaned.report, loaded, steps)
