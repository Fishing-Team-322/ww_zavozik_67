"""Detector of regular payments (salary, rent, taxes, loans, utilities, subscriptions...).

A series = operations of one obligation category to one counterparty.
Inside a series, payments are grouped into *slots* by day of month (circular, so
«28th shifted to the 1st» stays one slot). A slot is regular when it shows up
in most recent months (monthly) or in the same month of most recent quarters
(quarterly). Each regular slot is projected forward as an expected payment:
nominal day → next business day, amount from recent months (or from the same
quarter phase when amounts follow a quarterly pattern, like taxes).
"""
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from cashradar.categorize.engine import counterparty_key
from cashradar.domain import schema as s
from cashradar.sources.calendar import next_business_day

CANDIDATE_EXTRA = {"out.services", "out.owner_withdrawal"}
SLOT_GAP_DAYS = 4          # payments closer than this in day-of-month belong to one slot
LOOKBACK_MONTHS = 12
OVERDUE_DAYS = 10          # a monthly payment not made yet and late by ≤ this is expected right away
# Wording-independent fallback: any other outgoing counterparty paid once a month, at least
# GENERIC_MIN_MONTHS of the last 6 months, with nearly the same amount, is a regular payment too.
# Keeps the model working when purposes are worded differently or missing.
GENERIC_MIN_MONTHS = 5
GENERIC_MAX_CV = 0.2


def is_candidate(ops: pd.DataFrame) -> pd.Series:
    return (ops["is_mandatory"] | ops["category"].isin(CANDIDATE_EXTRA)) & ~ops["is_financing"] & (ops[s.SIGN] < 0)


@dataclass
class RecurringSlot:
    category: str
    category_name: str
    counterparty: str
    cp_key: str
    period: str                      # "monthly" | "quarterly"
    day: int                         # nominal day of month; > days in month spills into the next month
    month_amounts: dict[pd.Period, float]
    op_index: list[int] = field(default_factory=list)
    phase: int | None = None         # month % 3 for quarterly slots

    @property
    def label(self) -> str:
        return f"{self.category_name}: {self.counterparty}"

    def amount_for(self, month: pd.Period) -> tuple[float, float]:
        """Expected amount and its standard deviation for a future month."""
        hist = pd.Series(self.month_amounts).sort_index()
        recent = hist.iloc[-3:]
        base, spread = float(recent.median()), hist.iloc[-6:]
        if self.period == "monthly" and len(hist) >= 7 and hist.std() / max(hist.mean(), 1) > 0.25:
            phase = [hist[m] for m in (month - 3, month - 6, month - 9, month - 12) if m in hist.index]
            if len(phase) >= 2:
                base, spread = float(np.median(phase)), pd.Series(phase)
        if self.period == "quarterly":
            base = float(hist.iloc[-2:].median())
        mad = float(np.median(np.abs(spread - spread.median()))) * 1.4826 if len(spread) > 1 else 0.0
        return base, max(mad, 0.03 * base)


def _circular_slots(doms: np.ndarray) -> list[np.ndarray]:
    """Group days of month into slots; returns arrays of positions into `doms`."""
    order = np.argsort(doms)
    d = doms[order]
    groups, start = [], 0
    for i in range(1, len(d)):
        if d[i] - d[i - 1] > SLOT_GAP_DAYS:
            groups.append(order[start:i])
            start = i
    groups.append(order[start:])
    if len(groups) > 1 and d[0] + 31 - d[-1] <= SLOT_GAP_DAYS:  # wrap: 28..31 and 1..3 are one slot
        groups[0] = np.concatenate([groups[-1], groups[0]])
        groups.pop()
    return groups


def detect(ops: pd.DataFrame, cutoff: pd.Timestamp) -> list[RecurringSlot]:
    """ops: categorized operations of ONE company; only data ≤ cutoff is used."""
    start = (cutoff.to_period("M") - LOOKBACK_MONTHS).to_timestamp()
    h = ops[(ops[s.DATE] <= cutoff) & (ops[s.DATE] >= start)]
    known = is_candidate(h)
    generic = ~h["is_financing"] & (h[s.SIGN] < 0) & ~known
    h = h[known | generic]
    if h.empty:
        return []
    strict_rows = generic[known | generic].to_numpy()
    cp = counterparty_key(h)
    cur = cutoff.to_period("M")
    slots = []
    h = h.assign(_strict=strict_rows)
    for (cat, key), g in h.groupby([h["category"], cp], sort=False):
        strict = bool(g["_strict"].iloc[0])  # not an obligation category: only clear monthly patterns
        doms = g[s.DATE].dt.day.to_numpy()
        per_month = g.groupby(g[s.DATE].dt.to_period("M")).size()
        recent = per_month[per_month.index >= cur - 6]
        drifting = len(recent) >= 3 and recent.median() <= 1
        if strict and not drifting:
            continue
        # one payment a month on a drifting day (paid by invoice): one slot, not several
        groups = [np.arange(len(g))] if drifting else _circular_slots(doms)
        for pos in groups:
            sg = g.iloc[pos]
            dd = sg[s.DATE].dt.day.to_numpy()
            # month boundary: a late-month payment shifted to the 1st–7th (e.g. tax due on the 28th)
            wraps = dd.max() - dd.min() > 15 and bool(((dd >= 22) | (dd <= 7)).all())
            months = sg[s.DATE].dt.to_period("M")
            if wraps:  # early-month payments of a late-month slot belong to the previous month
                early = dd <= 15
                months = months.where(~early, months - 1)
                dd = np.where(early, dd + 31, dd)
            amounts = sg[s.AMOUNT].groupby(months.to_numpy()).sum()
            recent6 = {cur - k for k in range(1, 7)}
            seen6 = len(recent6 & set(amounts.index))
            first_month = amounts.index.min()
            available = min(6, max(1, (cur - first_month).n))
            last_gap = (cur - amounts.index.max()).n
            period, phase = None, None
            if strict:
                last6 = amounts[amounts.index >= cur - 6]
                stable = len(last6) >= 2 and last6.std() / max(last6.mean(), 1.0) <= GENERIC_MAX_CV
                if seen6 >= GENERIC_MIN_MONTHS and last_gap <= 1 and stable:
                    period = "monthly"
            elif seen6 >= max(3, round(0.67 * available)) and last_gap <= 2:
                period = "monthly"
            if period is None and not strict:
                last12 = [m for m in amounts.index if m >= cur - 12]
                by_phase = pd.Series([m.month % 3 for m in last12]).value_counts()
                if len(last12) >= 3 and by_phase.iloc[0] >= 3 and by_phase.iloc[0] / len(last12) >= 0.8 \
                        and len(last12) <= 5 and last_gap <= 4:
                    period, phase = "quarterly", int(by_phase.index[0])
            if period is None:
                continue
            slots.append(RecurringSlot(
                category=cat, category_name=sg["category_name"].iloc[0], counterparty=sg[s.CP_NAME].iloc[-1],
                cp_key=key, period=period, day=int(round(np.median(dd))),
                month_amounts=amounts.to_dict(), op_index=list(sg.index), phase=phase,
            ))
    return slots


def schedule(slots: list[RecurringSlot], cutoff: pd.Timestamp, horizon: int) -> pd.DataFrame:
    """Expected payments in (cutoff, cutoff + horizon]. Signed amounts (outflows negative)."""
    end = cutoff + pd.Timedelta(days=horizon)
    cur = cutoff.to_period("M")
    rows = []
    for i, slot in enumerate(slots):
        for k in range(0, horizon // 28 + 2):
            month = cur + k
            if slot.period == "quarterly" and month.month % 3 != slot.phase:
                continue
            nominal = month.to_timestamp() + pd.Timedelta(days=slot.day - 1)
            date = next_business_day(nominal)
            if date <= cutoff:
                paid = month in slot.month_amounts
                if paid or slot.period != "monthly" or (cutoff - date).days > OVERDUE_DAYS:
                    continue
                date = next_business_day(cutoff + pd.Timedelta(days=1))  # overdue obligation
            if date > end:
                continue
            amount, sigma = slot.amount_for(month)
            rows.append(dict(date=date, amount=-amount, sigma=sigma, slot=i, category=slot.category,
                             label=slot.label, kind="recurring", overdue=nominal < cutoff, cp_key=slot.cp_key))
    return pd.DataFrame(rows, columns=["date", "amount", "sigma", "slot", "category", "label", "kind", "overdue", "cp_key"])
